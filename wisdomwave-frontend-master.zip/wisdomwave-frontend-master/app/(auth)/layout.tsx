import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Authentication - WisdomWave',
  description: 'Sign in or create your WisdomWave account to start learning with expert instructors.',
}

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="auth-layout">
      {children}
    </div>
  )
}