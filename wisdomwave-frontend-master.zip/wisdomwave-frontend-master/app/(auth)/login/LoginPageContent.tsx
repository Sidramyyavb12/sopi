'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Head from 'next/head' // ✅ Added for SEO
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { 
  BookOpen, 
  Eye, 
  EyeOff, 
  Loader2, 
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Bug
} from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ValidationUtils } from '@/lib/validations'
import { extractUserFromResponse } from '@/types/auth'
import { getAllCategories } from '@/lib/courseData' // ✅ Added import for SEO keyword generation

export default function LoginPage() {
  const { login, isAuthenticating, user } = useAuth()
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [debugMode, setDebugMode] = useState(false)
  const [lastResponse, setLastResponse] = useState<any>(null)
  const router = useRouter()
  const searchParams = useSearchParams()

  const redirectTo = searchParams.get('from') || '/'

  // ✅ Generate SEO keywords based on course titles and skills
  const categories = getAllCategories()
  const seoKeywords = useMemo(() => {
    const keywords: string[] = []
    categories.forEach(category => {
      category.courses.forEach(course => {
        const skills = (course.skills || []).join(', ')
        keywords.push(
          `${course.title} one-to-one tutorial`,
          `${course.title} personalized mentorship`,
          `${course.title} live online training`,
          `${course.title} certification course`,
          `${course.title} beginner to advanced program`,
          `learn ${skills}`,
          `${category.name} certification program`,
          `best ${category.name} course 2025`,
          `${course.title} course by SOPHIRAY`,
          `${category.name} one-to-one coaching`,
          `${course.title} interactive online class`,
          `${course.title} practical projects course`,
          `${course.title} expert-led sessions`,
          `SOPHIRAY ${category.name} training`
        )
      })
    })
    return [...new Set(keywords)].join(', ')
  }, [categories])

  // ✅ Existing login logic untouched
  useEffect(() => {
    if (user) {
      const dashboardRoute =
        user.role === 'INSTRUCTOR'
          ? '/dashboard/instructor'
          : '/dashboard/learner'
      router.push(dashboardRoute)
    }
  }, [user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setErrors({})
    const validation = ValidationUtils.validateLoginForm(formData)
    if (!validation.isValid) {
      setErrors(validation.errors)
      return
    }
    try {
      const response = await login(formData)
      setLastResponse(response)
      const userData = extractUserFromResponse(response)
      if (userData && userData.role) {
        const redirectPath =
          userData.role === 'INSTRUCTOR'
            ? '/dashboard/instructor'
            : userData.role === 'LEARNER'
            ? '/dashboard/learner'
            : redirectTo
        router.push(redirectPath)
      } else {
        router.push(redirectTo)
      }
    } catch (error: any) {
      let errorMessage = 'Login failed. Please try again.'
      setErrors({ submit: errorMessage })
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }))
    if (errors.submit) setErrors(prev => ({ ...prev, submit: '' }))
  }

  const debugLocalStorage = () => {
    console.log('🔑 Token:', localStorage.getItem('wisdomwave_token'))
    console.log('👤 User:', localStorage.getItem('wisdomwave_user'))
  }

  const clearLocalStorage = () => {
    localStorage.removeItem('wisdomwave_token')
    localStorage.removeItem('wisdomwave_user')
  }

  return (
    <>
      {/* ✅ SEO meta tags added */}
      <Head>
        <title>Login | SOPHIRAY One-on-One Learning</title>
        <meta
          name="description"
          content="Login to SOPHIRAY to continue your personalized one-on-one learning journey with expert mentors and live classes."
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content="Login | SOPHIRAY One-on-One Tutorials" />
        <meta
          property="og:description"
          content="Access your SOPHIRAY account to learn interactively with expert mentors and gain certification in your chosen field."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://yourdomain.com/auth/login" />
        <meta property="og:site_name" content="SOPHIRAY" />
      </Head>
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Debug Panel */}
        {debugMode && (
          <div className="mb-6 p-4 bg-gray-800 text-white rounded-lg text-xs font-mono">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold flex items-center">
                <Bug className="w-4 h-4 mr-1" />
                Debug Panel
              </h3>
              <button
                onClick={() => setDebugMode(false)}
                className="text-red-400 hover:text-red-300"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-2">
              <div>
                <strong>Current User:</strong> {user ? JSON.stringify(user, null, 2) : 'None'}
              </div>
              <div>
                <strong>Is Authenticating:</strong> {isAuthenticating ? 'Yes' : 'No'}
              </div>
              <div>
                <strong>Last API Response:</strong>
                <pre className="mt-1 text-xs bg-gray-900 p-2 rounded overflow-auto max-h-32">
                  {lastResponse ? JSON.stringify(lastResponse, null, 2) : 'None'}
                </pre>
              </div>
              <div className="flex gap-2 mt-3">
                <button
                  onClick={debugLocalStorage}
                  className="px-2 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs"
                >
                  Check Storage
                </button>
                <button
                  onClick={clearLocalStorage}
                  className="px-2 py-1 bg-red-600 hover:bg-red-700 rounded text-xs"
                >
                  Clear Storage
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center justify-center mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mr-3">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900 dark:text-white">Sophiray</span>
          </Link>
          
          <div className="flex items-center justify-center gap-2 mb-4">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Welcome Back
            </h1>
            <button
              onClick={() => setDebugMode(!debugMode)}
              className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              title="Toggle Debug Mode"
            >
              <Bug className="w-4 h-4" />
            </button>
          </div>
          
          <p className="text-gray-600 dark:text-gray-300">
            Sign in to continue your learning journey
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
          <form 
            onSubmit={handleSubmit} 
            className="space-y-6"
            noValidate
          >
            <Input
              label="Email Address"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              error={errors.email}
              placeholder="Enter your email"
              required
            />
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className={`w-full px-3 py-2 pr-10 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white ${
                    errors.password ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.password}</p>
              )}
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <label htmlFor="remember-me" className="ml-2 text-sm text-gray-600 dark:text-gray-300">
                  Remember me
                </label>
              </div>
              
              <Link
                href="/auth/forgot-password"
                className="text-sm text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
              >
                Forgot password?
              </Link>
            </div>

            {/* Submit Error */}
            {errors.submit && (
              <div className="p-4 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded-lg">
                <p className="text-sm text-red-600 dark:text-red-400 flex items-start">
                  <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{errors.submit}</span>
                </p>
              </div>
            )}
            
            <Button
              type="submit"
              loading={isAuthenticating}
              className="w-full"
              size="lg"
            >
              Sign In
            </Button>
          </form>
          
          {/* Sign Up Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-600 dark:text-gray-300">
              Don't have an account?{' '}
              <Link
                href="/register"
                className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 font-medium"
              >
                Sign up for free
              </Link>
            </p>
          </div>
        </div>

        {/* Back to Home */}
        <div className="mt-6 text-center">
          <Link
            href="/"
            className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sophiray
          </Link>
        </div>

        {/* Features */}
        <div className="mt-8 text-center">
          <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              <span>Expert Instructors</span>
            </div>
            <div className="flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              <span>1-on-1 Sessions</span>
            </div>
            <div className="flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              <span>Certificates</span>
            </div>
            <div className="flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              <span>Job referral Support</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}