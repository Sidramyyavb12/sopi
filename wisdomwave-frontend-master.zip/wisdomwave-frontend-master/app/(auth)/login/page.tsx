import { Suspense } from 'react'
import LoginPageContent from './LoginPageContent'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Login | One-on-One Learning Platform | Sophiray',
  description: 'Sign in to Sophiray to access personalized 1-on-1 tutorials, live mentorship, and your learning dashboard.',
  keywords: 'login, sophiray, one on one tutorial, 1-on-1 mentoring, personalized learning'
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    }>
      <LoginPageContent />
    </Suspense>
  )
}