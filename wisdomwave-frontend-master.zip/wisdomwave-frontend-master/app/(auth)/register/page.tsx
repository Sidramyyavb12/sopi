'use client'

import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { 
  BookOpen, 
  Eye, 
  EyeOff, 
  User, 
  Users, 
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Zap,
  Shield,
  Star,
  Clock
} from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ValidationUtils } from '@/lib/validations'
import { RegisterData } from '@/types/auth'

export default function RegisterPage() {
  const { register, isAuthenticating, user } = useAuth()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  })
  const [role, setRole] = useState<'LEARNER' | 'INSTRUCTOR'>('LEARNER')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState({ score: 0, feedback: [] as string[] })
  const router = useRouter()

  // Redirect if already authenticated
  useEffect(() => {
    if (user) {
      const dashboardRoute = user.role === 'INSTRUCTOR' 
        ? '/dashboard/instructor' 
        : '/dashboard/learner'
      router.push(dashboardRoute)
    }
  }, [user, router])

  // Calculate password strength when password changes
  useEffect(() => {
    if (formData.password) {
      const strength = ValidationUtils.getPasswordStrength(formData.password)
      setPasswordStrength(strength)
    } else {
      setPasswordStrength({ score: 0, feedback: [] })
    }
  }, [formData.password])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Check terms acceptance
    if (!acceptTerms) {
      setErrors({ terms: 'Please accept the Terms of Service and Privacy Policy' })
      return
    }

    // Validate form
    const validation = ValidationUtils.validateRegisterForm({
      ...formData,
      role
    })
    if (!validation.isValid) {
      setErrors(validation.errors)
      return
    }

    try {
      const registerData: RegisterData = {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        role
      }
      
      await register(registerData)
      
      // Redirect based on user role
      const dashboardRoute = role === 'INSTRUCTOR' 
        ? '/dashboard/instructor' 
        : '/dashboard/learner'
      router.push(dashboardRoute)
    } catch (error) {
      setErrors({ 
        submit: error instanceof Error ? error.message : 'Registration failed. Please try again.'
      })
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    // Clear field-specific error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }))
    }
  }

  const getPasswordStrengthColor = (score: number) => {
    if (score <= 2) return 'bg-red-500'
    if (score <= 4) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  const getPasswordStrengthText = (score: number) => {
    if (score <= 2) return 'Weak'
    if (score <= 4) return 'Medium'
    return 'Strong'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <Head>
        <title>Register | Join 1-on-1 Tutorials & Mentorship | Sophiray</title>
        <meta
          name="description"
          content="Create your Sophiray account to access personalized one-on-one tutorials, mentorship, certifications, and interview preparation."
        />
        <meta
          name="keywords"
          content="register, signup, sophiray, one on one tutorial, 1-on-1 mentoring, personalized learning"
        />
      </Head>
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center justify-center mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mr-3">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900 dark:text-white">Sophiray</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Join Sophiray
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Create your account and start learning today
          </p>
        </div>

        {/* Registration Form */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Role Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                I want to:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('LEARNER')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    role === 'LEARNER' 
                      ? 'border-green-600 bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-400' 
                      : 'border-gray-300 dark:border-gray-600 hover:border-green-300 dark:hover:border-green-700'
                  }`}
                >
                  <Users className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-sm font-medium">Learn</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Take courses</div>
                </button>
                
                <button
                  type="button"
                  onClick={() => setRole('INSTRUCTOR')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    role === 'INSTRUCTOR' 
                      ? 'border-green-600 bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-400' 
                      : 'border-gray-300 dark:border-gray-600 hover:border-green-300 dark:hover:border-green-700'
                  }`}
                >
                  <User className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-sm font-medium">Teach</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Create courses</div>
                </button>
              </div>
            </div>

            <Input
              label="Full Name"
              type="text"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              error={errors.name}
              placeholder="Enter your full name"
              required
            />
            
            <Input
              label="Email Address"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              error={errors.email}
              placeholder="Enter your email"
              required
            />
            
            {/* Password with Strength Indicator */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className={`w-full px-3 py-2 pr-10 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white ${
                    errors.password ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="Create a strong password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              
              {/* Password Strength */}
              {formData.password && (
                <div className="mt-2">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-gray-600 dark:text-gray-400">Password strength:</span>
                    <span className={`font-medium ${
                      passwordStrength.score <= 2 ? 'text-red-600' : 
                      passwordStrength.score <= 4 ? 'text-yellow-600' : 'text-green-600'
                    }`}>
                      {getPasswordStrengthText(passwordStrength.score)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${getPasswordStrengthColor(passwordStrength.score)}`}
                      style={{ width: `${(passwordStrength.score / 6) * 100}%` }}
                    />
                  </div>
                  {passwordStrength.feedback.length > 0 && (
                    <div className="mt-1 text-xs text-gray-600 dark:text-gray-400">
                      {passwordStrength.feedback[0]}
                    </div>
                  )}
                </div>
              )}
              
              {errors.password && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.password}</p>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  className={`w-full px-3 py-2 pr-10 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white ${
                    errors.confirmPassword ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="Confirm your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.confirmPassword}</p>
              )}
            </div>

            {/* Terms and Conditions */}
            <div>
              <div className="flex items-start">
                <input
                  id="accept-terms"
                  type="checkbox"
                  checked={acceptTerms}
                  onChange={(e) => {
                    setAcceptTerms(e.target.checked)
                    if (errors.terms) {
                      setErrors(prev => ({ ...prev, terms: '' }))
                    }
                  }}
                  className="h-4 w-4 mt-1 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <label htmlFor="accept-terms" className="ml-2 text-sm text-gray-600 dark:text-gray-300">
                  I agree to the{' '}
                  <Link href="/terms" className="text-green-600 hover:text-green-700 dark:text-green-400">
                    Terms of Service
                  </Link>
                  {' '}and{' '}
                  <Link href="/privacy" className="text-green-600 hover:text-green-700 dark:text-green-400">
                    Privacy Policy
                  </Link>
                </label>
              </div>
              {errors.terms && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.terms}</p>
              )}
            </div>

            {/* Submit Error */}
            {errors.submit && (
              <div className="p-3 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded-lg">
                <p className="text-sm text-red-600 dark:text-red-400 flex items-center">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  {errors.submit}
                </p>
              </div>
            )}
            
            <Button
              type="submit"
              loading={isAuthenticating}
              className="w-full"
              size="lg"
            >
              Create Account
            </Button>
          </form>
          
          {/* Sign In Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-600 dark:text-gray-300">
              Already have an account?{' '}
              <Link
                href="/login"
                className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 font-medium"
              >
                Sign in
              </Link>
            </p>
          </div>
        </div>

        {/* Back to Home */}
        <div className="mt-6 text-center">
          <Link
            href="/"
            className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sophiray
          </Link>
        </div>

        {/* Benefits */}
        <div className="mt-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Zap className="w-5 h-5 text-green-500 mr-2" />
              Why Join Sohpiray?
            </h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Learn from industry experts at Google, Meta, and Tesla
                </span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Get personalized 1-on-1 instruction tailored to your goals
                </span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Earn industry-recognized certificates and job placement support
                </span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  Join 50,000+ successful learners with 95% completion rate
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Social Proof */}
        {/* <div className="mt-6">
          <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900 dark:to-blue-900 rounded-lg p-6">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-5 h-5 text-yellow-500 mr-1" />
                  <span className="text-lg font-bold text-gray-900 dark:text-white">4.9</span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">Average Rating</p>
              </div>
              
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Users className="w-5 h-5 text-blue-500 mr-1" />
                  <span className="text-lg font-bold text-gray-900 dark:text-white">50K+</span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">Happy Students</p>
              </div>
              
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Shield className="w-5 h-5 text-green-500 mr-1" />
                  <span className="text-lg font-bold text-gray-900 dark:text-white">87%</span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">Job Success</p>
              </div>
            </div>
          </div>
        </div> */}

        {/* Quick Stats */}
        <div className="mt-6 text-center">
          <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center">
              <Clock className="w-4 h-4 text-green-500 mr-1" />
              <span>Setup in 2 minutes</span>
            </div>
            <div className="flex items-center">
              <Shield className="w-4 h-4 text-green-500 mr-1" />
              <span>Secure & Private</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}