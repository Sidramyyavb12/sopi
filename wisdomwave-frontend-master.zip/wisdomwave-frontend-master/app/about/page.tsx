'use client'

import React, { useState, useMemo } from 'react'
import Head from 'next/head'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import AuthModal from '@/components/auth/AuthModal'
import { getAllCategories } from '@/lib/courseData' // ✅ Import for SEO keyword generation

export default function AboutPage() {
  const [showAuthModal, setShowAuthModal] = useState(false)

  const handleAuthSuccess = () => {
    setShowAuthModal(false)
  }

  // ✅ Generate SEO keywords dynamically from all course titles and skills
  const categories = getAllCategories()

  const seoKeywords = useMemo(() => {
    const keywords: string[] = []
    categories.forEach(category => {
      category.courses.forEach(course => {
        const skills = (course.skills || []).join(', ')
        keywords.push(
          `${course.title} one-to-one tutorial`,
          `${course.title} personalized mentorship`,
          `${course.title} live online training`,
          `${course.title} certification course`,
          `${course.title} beginner to advanced program`,
          `learn ${skills}`,
          `${category.name} certification program`,
          `best ${category.name} course 2025`,
          `${course.title} course by SOPHIRAY`,
          `${category.name} one-to-one coaching`,
          `${course.title} interactive online class`,
          `${course.title} practical projects course`,
          `${course.title} expert-led sessions`,
          `SOPHIRAY ${category.name} training`
        )
      })
    })
    return [...new Set(keywords)].join(', ')
  }, [categories])

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* ✅ SEO META TAGS (no UI change) */}
      <Head>
        <title>About WisdomWave | SOPHIRAY One-to-One Learning</title>
        <meta
          name="description"
          content="Learn more about WisdomWave by SOPHIRAY — our mission, vision, and story behind personalized one-on-one learning programs."
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content="About WisdomWave | SOPHIRAY One-on-One Tutorials" />
        <meta
          property="og:description"
          content="WisdomWave by SOPHIRAY brings one-on-one, expert-led learning experiences to students worldwide. Discover our mission, vision, and values."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://yourdomain.com/about" />
        <meta property="og:site_name" content="SOPHIRAY" />
      </Head>

      <Navigation onAuthClick={() => setShowAuthModal(true)} />

      {/* ✅ Your entire UI remains unchanged below */}
      <main className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">About WisdomWave</h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              We're on a mission to democratize quality education through personalized learning experiences.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Our Story</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Founded in 2024, WisdomWave emerged from a simple belief: everyone deserves access to world-class education,
              regardless of their location or background. Our platform connects learners with expert instructors for
              personalized 1-on-1 sessions that adapt to individual learning styles and goals.
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              In the coming years, we aim to empower learners across the globe with transformative courses in technology, business, creative arts, and more — creating a community where every learner experiences career growth, personal development, and lasting impact.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Our Mission</h3>
              <p className="text-gray-600 dark:text-gray-300">
                To make high-quality, personalized education accessible to everyone, everywhere,
                fostering a global community of lifelong learners.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Our Vision</h3>
              <p className="text-gray-600 dark:text-gray-300">
                A world where learning has no boundaries, where every individual can unlock their
                potential through expert guidance and personalized instruction.
              </p>
            </div>
          </div>

          {/* Values Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🎯</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Excellence</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  We strive for excellence in everything we do, from course content to student support.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🤝</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Community</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  We believe in the power of community and collaborative learning experiences.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🚀</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Innovation</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  We continuously innovate to provide cutting-edge learning solutions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  )
}
