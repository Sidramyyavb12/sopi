'use client'

import React, { useState, useMemo } from 'react'
import Head from 'next/head'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { CheckCircle, Mail } from 'lucide-react'
import { ApiService } from '@/lib/api'
import { ValidationUtils } from '@/lib/validations'
import { getAllCategories } from '@/lib/courseData' // ✅ use named export

interface ExtendedContactFormData {
  name: string
  email: string
  interestType: string
  course: string
  message: string
}

export default function ContactPage() {
  const [formData, setFormData] = useState<ExtendedContactFormData>({
    name: '',
    email: '',
    interestType: '',
    course: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  // ✅ Gather categories and courses once
  const categories = getAllCategories()

  // ✅ Generate SEO keywords dynamically from all course titles and skills
  const seoKeywords = useMemo(() => {
    const titles = categories.flatMap(cat => cat.courses.map(c => c.title.toLowerCase()))
    const skills = categories.flatMap(cat => cat.courses.flatMap(c => (c.skills || []).map(s => s.toLowerCase())))
    const base = Array.from(new Set([...titles, ...skills]))
    const variants = ['one-to-one tutorial', '1-on-1 mentoring', 'personalized mentorship', 'live online training', 'certification']
    const expanded = [
      ...base,
      ...base.slice(0, 80).flatMap(k => variants.map(v => `${k} ${v}`))
    ]
    return Array.from(new Set(expanded)).join(', ')
  }, [categories])


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) newErrors.name = 'Name is required'
    if (!formData.email.trim()) newErrors.email = 'Email is required'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Invalid email format'
    if (!formData.interestType) newErrors.interestType = 'Please select your interest type'
    if (!formData.course) newErrors.course = 'Please select a course'

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsSubmitting(true)
    setErrors({})
    setSubmitted(true)
    setFormData({ name: '', email: '', interestType: '', course: '', message: '' })
    setIsSubmitting(false)

    try {
      const apiData = {
        name: formData.name,
        email: formData.email,
        course: formData.course,
        message: formData.message
      }
      ApiService.submitContactForm(apiData)
    } catch (error) {
      console.error('Failed to send contact form:', error)
    }
  }

  const handleInterestTypeChange = (type: string) => {
    setFormData({ ...formData, interestType: type, course: '' })
  }

  return (
    <>
      {/* ✅ SEO META SECTION */}
      <Head>
        <title>Contact SOPHIRAY | Book 1-on-1 Demo & Mentorship</title>
        <meta
          name="description"
          content="Contact SOPHIRAY to book personalized demo classes or one-to-one mentorship sessions. Learn top skills like React, Node.js, Python, Machine Learning, and UI/UX Design with experts."
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content="Contact SOPHIRAY | Book 1-on-1 Demo & Mentorship" />
        <meta
          property="og:description"
          content="Get in touch with SOPHIRAY for personalized learning, mentorship, and interview preparation. Expert-led 1-on-1 courses for developers, designers, and analysts."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://yourdomain.com/contact" />
        <meta property="og:site_name" content="SOPHIRAY" />
      </Head>

      {/* ✅ Main Layout */}
      <div className="min-h-screen bg-white dark:bg-gray-900">
        <Navigation />

        {submitted ? (
          <main className="py-16">
            <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
                <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Thank You!
                </h1>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  Your demo booking request has been submitted successfully. We'll contact you soon to schedule your session.
                </p>
                <Button onClick={() => setSubmitted(false)}>Submit Another Request</Button>
              </div>
            </div>
          </main>
        ) : (
          <main className="py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
                  Get in Touch
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300">
                  Ready to start your learning journey? Book a demo or reach out to us.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                {/* ✅ Contact Form */}
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
                    Book a Demo Class
                  </h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <Input
                      label="Full Name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      error={errors.name}
                      required
                    />
                    <Input
                      label="Email Address"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      error={errors.email}
                      required
                    />

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        I'm interested in
                      </label>
                      <select
                        value={formData.interestType}
                        onChange={(e) => handleInterestTypeChange(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        required
                      >
                        <option value="">Select interest type</option>
                        <option value="course">Course Learning</option>
                        <option value="interview">Interview Preparation</option>
                      </select>
                      {errors.interestType && (
                        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.interestType}</p>
                      )}
                    </div>

                    {formData.interestType && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          {formData.interestType === 'course' ? 'Course Interest' : 'Interview Type'}
                        </label>
                        <select
                          value={formData.course}
                          onChange={(e) => setFormData({ ...formData, course: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          required
                        >
                          <option value="">Select an option</option>
                          {categories.flatMap(cat => cat.courses).map((c, i) => (
                            <option key={i} value={c.title}>{c.title}</option>
                          ))}
                          <option value="other">Other</option>
                        </select>
                        {errors.course && (
                          <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.course}</p>
                        )}
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Message
                      </label>
                      <textarea
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                        placeholder="Tell us about your learning or interview goals..."
                      />
                    </div>

                    <Button type="submit" loading={isSubmitting} className="w-full" size="lg">
                      {formData.interestType === 'interview' ? 'Book Interview Prep Session' : 'Book Demo Class'}
                    </Button>
                  </form>
                </div>

                {/* ✅ Right Side */}
                <div className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
                      Contact Information
                    </h2>
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mr-4">
                        <Mail className="w-6 h-6 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Email</p>
                        <p className="text-gray-600 dark:text-gray-300">support@charvitos.com</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      Why Choose Us?
                    </h3>
                    {[
                      'Expert instructors from top companies',
                      'Personalized 1-on-1 learning sessions',
                      'Industry-recognized certificates',
                      'Interview preparation guidance',
                      '24/7 student support'
                    ].map((item, i) => (
                      <div key={i} className="flex items-center mb-2">
                        <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                        <span className="text-gray-700 dark:text-gray-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </main>
        )}

        <Footer />
      </div>
    </>
  )
}
