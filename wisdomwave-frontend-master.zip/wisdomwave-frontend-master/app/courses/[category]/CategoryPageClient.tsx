'use client'

import React, { useState, useMemo } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import AuthModal from '@/components/auth/AuthModal'
import { useAuth } from '@/hooks/useAuth'
import {
  ChevronRight, BookOpen, Clock, TrendingUp, Award, Code2, Globe, BarChart3,
  Shield, Smartphone, Brain, Cloud, Link as LinkIcon, Gamepad2, Palette, Filter,
  CheckCircle, Target, Download, Heart, Share2, Zap, Rocket, Cpu, Server, Database,
  Lock, Sparkles, Trophy, Briefcase, ArrowRight, Eye, Grid3X3, List, Headphones, Calendar, ChevronDown, Users
} from 'lucide-react'

// --- Icon & Color Configurations ---
const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  '💻': Code2, '🌐': Globe, '📊': BarChart3, '🔐': Shield, '📱': Smartphone,
  '🤖': Brain, '☁️': Cloud, '🔗': LinkIcon, '🎮': Gamepad2, '🎨': Palette,
  '🚀': Rocket, '🏆': Trophy, '💼': Briefcase
}

const colorGradients = {
  'bg-blue-500': { from: 'from-blue-600', to: 'to-blue-800', accent: 'blue-600', light: 'blue-100' },
  'bg-emerald-500': { from: 'from-emerald-600', to: 'to-emerald-800', accent: 'emerald-600', light: 'emerald-100' },
  'bg-purple-500': { from: 'from-purple-600', to: 'to-purple-800', accent: 'purple-600', light: 'purple-100' },
  'bg-orange-500': { from: 'from-orange-600', to: 'to-orange-800', accent: 'orange-600', light: 'orange-100' },
  'bg-yellow-500': { from: 'from-yellow-600', to: 'to-yellow-800', accent: 'yellow-600', light: 'yellow-100' },
  'bg-indigo-500': { from: 'from-indigo-600', to: 'to-indigo-800', accent: 'indigo-600', light: 'indigo-100' },
  'bg-red-500': { from: 'from-red-600', to: 'to-red-800', accent: 'red-600', light: 'red-100' },
  'bg-cyan-500': { from: 'from-cyan-600', to: 'to-cyan-800', accent: 'cyan-600', light: 'cyan-100' },
  'bg-pink-500': { from: 'from-pink-600', to: 'to-pink-800', accent: 'pink-600', light: 'pink-100' },
  'bg-teal-500': { from: 'from-teal-600', to: 'to-teal-800', accent: 'teal-600', light: 'teal-100' }
}

// --- Type Definitions ---
interface Course {
  id: string
  title: string
  level: string
  duration: string
  teacherSessions: number
  totalSessions: number
  lectures: number
  students: number
  price: number
  originalPrice: number
  rating: number
  reviews: number
  lastUpdated: string
  description: string
  skills: string[]
}

interface Category {
  name: string
  slug: string
  icon: string
  color: string
  description: string
  students: string
  avgRating: number
  courses: Course[]
}

interface Props {
  categoryData: Category
  params: { category: string }
}

export default function CategoryPageClient({ categoryData, params }: Props) {
  const [selectedLevel, setSelectedLevel] = useState('all')
  const [selectedSort, setSelectedSort] = useState('popular')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [savedCourses, setSavedCourses] = useState<string[]>([])
  const { user } = useAuth()

  const color = colorGradients[categoryData.color] || colorGradients['bg-blue-500']
  const Icon = iconMap[categoryData.icon] || Code2

  // ✅ Dynamic SEO Keyword Generation
  const seoKeywords = useMemo(() => {
    const keywords: string[] = []

    categoryData.courses.forEach((course) => {
      const skills = course.skills.join(', ')
      keywords.push(
        `${course.title} one-to-one tutorial`,
        `${course.title} personalized mentorship`,
        `${course.title} live online training`,
        `${course.title} certification course`,
        `${course.title} beginner to advanced program`,
        `learn ${skills}`,
        `${categoryData.name} certification program`,
        `best ${categoryData.name} course 2025`,
        `${course.title} course by SOPHIRAY`,
        `${categoryData.name} one-to-one coaching`,
        `${course.title} interactive online class`,
        `${course.title} practical projects course`,
        `${course.title} expert-led sessions`,
        `SOPHIRAY ${categoryData.name} training`
      )
    })

    return [...new Set(keywords)].join(', ')
  }, [categoryData])

  const filteredCourses = useMemo(() => {
    let filtered = categoryData.courses
    if (selectedLevel !== 'all') filtered = filtered.filter(c => c.level === selectedLevel)
    return filtered.sort((a, b) => {
      if (selectedSort === 'newest') return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime()
      if (selectedSort === 'duration') return parseInt(a.duration) - parseInt(b.duration)
      return b.students - a.students
    })
  }, [categoryData.courses, selectedLevel, selectedSort])

  const toggleSave = (id: string) => {
    setSavedCourses(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* ✅ SEO Head Section */}
      <Head>
        <title>{`${categoryData.name} Courses | SOPHIRAY One-to-One Tutorials`}</title>
        <meta
          name="description"
          content={`Master ${categoryData.name} with SOPHIRAY’s one-on-one tutorials. Learn through personalized mentorship, practical projects, and live expert-led classes.`}
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content={`${categoryData.name} | SOPHIRAY Courses`} />
        <meta
          property="og:description"
          content={`SOPHIRAY offers ${categoryData.name} certification programs, personalized mentorship, and hands-on ${categoryData.name.toLowerCase()} training.`}
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`https://yourdomain.com/courses/${params.category}`} />
        <meta property="og:site_name" content="SOPHIRAY" />
      </Head>
      <Navigation />

      {/* --- Hero --- */}
      <div className={`bg-gradient-to-br ${color.from} ${color.to} text-white py-20`}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-6 mb-8">
            <div className="bg-white/20 p-4 rounded-2xl">
              <Icon className="w-12 h-12" />
            </div>
            <div>
              <h1 className="text-5xl font-bold">{categoryData.name}</h1>
              <p className="opacity-90 mt-2">{categoryData.courses.length} Expert Courses Available</p>
            </div>
          </div>
          <p className="text-lg opacity-90 max-w-3xl">
            {categoryData.description}. Learn from experts and gain in-demand {categoryData.name.toLowerCase()} skills.
          </p>
        </div>
      </div>

      {/* --- Filters --- */}
      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="flex flex-wrap justify-between items-center mb-6">
          <div className="flex gap-4">
            <select
              className="border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 bg-white dark:bg-gray-800"
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
            >
              <option value="all">All Levels</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>

            <select
              className="border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 bg-white dark:bg-gray-800"
              value={selectedSort}
              onChange={(e) => setSelectedSort(e.target.value)}
            >
              <option value="popular">Most Popular</option>
              <option value="newest">Recently Updated</option>
              <option value="duration">Shortest Duration</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg ${viewMode === 'grid' ? `bg-${color.accent} text-white` : 'text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
            >
              <Grid3X3 className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg ${viewMode === 'list' ? `bg-${color.accent} text-white` : 'text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* --- Course Cards --- */}
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8' : 'space-y-6'}>
          {filteredCourses.map((course) => {
            const isSaved = savedCourses.includes(course.id);
            const courseLink = `/courses/${params.category}/${course.id}`;

            return (
              <Link
                key={course.id}
                href={courseLink}
                className={`block bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 group`}
              >
                {/* Header */}
                <div className={`bg-gradient-to-r ${color.from} ${color.to} text-white p-6 relative`}>
                  <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-10 -mt-10"></div>
                  <div className="relative z-10 flex justify-between items-start">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        course.level === 'Beginner'
                          ? 'bg-green-100 text-green-800'
                          : course.level === 'Intermediate'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {course.level}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        toggleSave(course.id);
                      }}
                      className={`p-2 rounded-full ${
                        isSaved
                          ? 'bg-white/20 text-red-400'
                          : 'text-white/70 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                  <h3 className="text-xl font-bold mt-4 group-hover:text-yellow-200 transition">{course.title}</h3>
                  <p className="text-sm opacity-90 mt-1 line-clamp-2">{course.description}</p>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">You'll learn:</h4>
                    <div className="flex flex-wrap gap-2">
                      {course.skills.slice(0, 3).map((skill, i) => (
                        <span
                          key={i}
                          className={`text-xs bg-${color.light} dark:bg-gray-700 text-${color.accent} px-2 py-1 rounded font-medium`}
                        >
                          {skill}
                        </span>
                      ))}
                      {course.skills.length > 3 && (
                        <span className="text-xs text-gray-500">+{course.skills.length - 3}</span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1 text-xs text-gray-600 dark:text-gray-300">
                    <div className="flex items-center">
                      <CheckCircle className={`w-3 h-3 mr-2 text-${color.accent}`} /> Certificate included
                    </div>
                    <div className="flex items-center">
                      <Download className={`w-3 h-3 mr-2 text-${color.accent}`} /> Lifetime access
                    </div>
                    <div className="flex items-center">
                      <Headphones className={`w-3 h-3 mr-2 text-${color.accent}`} /> 24/7 support
                    </div>
                  </div>

                  <div className="mt-6 flex justify-between items-center">
                    <span className="text-sm text-gray-500">Updated {course.lastUpdated}</span>
                    <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-gray-600 transition" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      <Footer />

      <AuthModal isOpen={false} onClose={() => {}} onSuccess={() => {}} />
    </div>
  );
}