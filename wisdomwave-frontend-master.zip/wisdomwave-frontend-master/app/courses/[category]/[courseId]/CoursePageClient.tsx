// app/courses/[category]/[courseId]/CoursePageClient.tsx
'use client'

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Navigation from '@/components/layout/Navigation';
import Footer from '@/components/layout/Footer';
import AuthModal from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/useAuth';
import { getEnhancedCourseData } from '@/lib/enhancedCourseData';
import PaymentSuccessModal from '@/components/payment/PaymentSuccessModal';
import { handleCoursePayment } from '@/lib/helpers/paymentHelpers';
import { 
  checkEnrollment, 
  fetchCourseInfo, 
  handleEnrollmentAction,
  calculatePricing,
  validateEnrollmentData 
} from '@/lib/helpers/enrollmentHelpers';

// Import new components
import CourseOverview from '@/components/course/CourseOverview';
import CourseProjects from '@/components/course/CourseProjects';
import CourseSyllabus from '@/components/course/CourseSyllabus';
import LearningPath from '@/components/course/LearningPath';
import CourseReviews from '@/components/course/CourseReviews';
import CertificatePreview from '@/components/course/CertificatePreview';

import { 
  Star, Clock, Users, Award, CheckCircle, PlayCircle, Video,
  Heart, ChevronRight, Shield, Share2, Code
} from 'lucide-react';

// Type definitions
interface Course {
  id: string;
  title: string;
  level: string;
  duration: string;
  teacherSessions: number;
  totalSessions: number;
  lectures: number;
  students: number;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  lastUpdated: string;
  language: string;
  captions: string[];
  certificate: boolean;
  lifetimeAccess: boolean;
  mobileAccess: boolean;
  description: string;
  prerequisites: string[];
  skills: string[];
}

interface Category {
  name: string;
  slug: string;
  icon: string;
  color: string;
  description: string;
  students: string;
  avgRating: number;
  courses: Course[];
}

interface CoursePageClientProps {
  courseData: Course;
  categoryData: Category;
  relatedCourses: Course[];
  params: {
    category: string;
    courseId: string;
  };
}

interface TabButtonProps {
  id: string;
  label: string;
  isActive: boolean;
  onClick: (id: string) => void;
}

const TabButton: React.FC<TabButtonProps> = ({ id, label, isActive, onClick }) => (
  <button
    onClick={() => onClick(id)}
    className={`px-6 py-3 font-medium rounded-lg transition-colors ${
      isActive 
        ? 'bg-green-600 text-white' 
        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
    }`}
  >
    {label}
  </button>
);

const CoursePageClient: React.FC<CoursePageClientProps> = ({ 
  courseData, 
  categoryData, 
  relatedCourses, 
  params 
}) => {
  const router = useRouter();
  const { user } = useAuth();
  
  // State Management
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [isWishlisted, setIsWishlisted] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  
  // Enrollment State
  const [isEnrolled, setIsEnrolled] = useState<boolean>(false);
  const [enrollmentId, setEnrollmentId] = useState<number | null>(null);
  const [isCheckingEnrollment, setIsCheckingEnrollment] = useState<boolean>(true);
  
  // Backend Course Info State
  const [backendCourseInfo, setBackendCourseInfo] = useState<any>(null);
  const [isPriceLoading, setIsPriceLoading] = useState<boolean>(true);
  
  // Payment Success Modal State
  const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
  const [paymentResult, setPaymentResult] = useState<any>(null);

  // Get enhanced course data
  const enhancedData = getEnhancedCourseData(courseData.id);
  
  // Sample Reviews Data
  const sampleReviews = [
    {
      name: "Arjun Patel",
      rating: 5,
      date: "2 weeks ago",
      review: "Excellent course! The teacher sessions are incredibly helpful and the homework assignments really reinforce the learning.",
      helpful: 24
    },
    {
      name: "Priya Sharma",
      rating: 5,
      date: "1 month ago",
      review: "The structured approach with alternating teacher and homework sessions works perfectly. Love the hands-on projects!",
      helpful: 18
    },
    {
      name: "Rahul Singh",
      rating: 4,
      date: "2 months ago",
      review: "Great content and well-organized curriculum. The live sessions are engaging and the projects are challenging.",
      helpful: 12
    }
  ];

  const ratingBreakdown = [
    { rating: 5, percentage: 75 },
    { rating: 4, percentage: 20 },
    { rating: 3, percentage: 3 },
    { rating: 2, percentage: 1 },
    { rating: 1, percentage: 1 }
  ];
  
  // Effects
  useEffect(() => {
    const loadCourseInfo = async () => {
      const info = await fetchCourseInfo(courseData.id);
      setBackendCourseInfo(info);
      setIsPriceLoading(false);
    };
    loadCourseInfo();
  }, [courseData.id]);
  
  useEffect(() => {
    const checkUserEnrollment = async () => {
      const result = await checkEnrollment(courseData.id, user);
      setIsEnrolled(result.isEnrolled);
      setEnrollmentId(result.enrollmentId);
      setIsCheckingEnrollment(false);
    };
    checkUserEnrollment();
  }, [user, courseData.id]);
  
  useEffect(() => {
    try {
      const wishlist: string[] = JSON.parse(localStorage.getItem('wishlist') || '[]');
      setIsWishlisted(wishlist.includes(courseData.id));
    } catch (error) {
      console.error('Error parsing wishlist:', error);
      setIsWishlisted(false);
    }
  }, [courseData.id]);

  // Handlers
  const handleWishlist = (): void => {
    try {
      const wishlist: string[] = JSON.parse(localStorage.getItem('wishlist') || '[]');
      if (isWishlisted) {
        const updated = wishlist.filter((id: string) => id !== courseData.id);
        localStorage.setItem('wishlist', JSON.stringify(updated));
        setIsWishlisted(false);
      } else {
        wishlist.push(courseData.id);
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        setIsWishlisted(true);
      }
    } catch (error) {
      console.error('Error handling wishlist:', error);
    }
  };

  const pricing = calculatePricing(backendCourseInfo, courseData.price);

  const handleEnrollClick = async (): Promise<void> => {
    const action = handleEnrollmentAction(
      isEnrolled,
      enrollmentId,
      router,
      () => setShowAuthModal(true),
      user
    );

    if (action !== 'enroll') return;

    setIsProcessing(true);

    try {
      let courseInfo = backendCourseInfo;
      if (!courseInfo) {
        courseInfo = await fetchCourseInfo(courseData.id);
        if (!courseInfo) {
          alert('❌ Failed to load course information. Please refresh and try again.');
          setIsProcessing(false);
          return;
        }
      }

      const validation = validateEnrollmentData(courseInfo, courseData);
      if (!validation.isValid) {
        alert(`❌ ${validation.error}`);
        setIsProcessing(false);
        return;
      }

      await handleCoursePayment(
        {
          courseId: courseData.id,
          categorySlug: params.category,
          courseTitle: courseData.title,
          amount: validation.data!.priceInPaise,
          totalWeeks: validation.data!.totalWeeks,
          totalSessions: validation.data!.totalSessions,
          user
        },
        (result) => {
          setPaymentResult({
            title: courseData.title,
            enrollmentId: result.enrollmentId,
            paymentId: result.paymentId,
            status: result.status,
            redirectPath: '/dashboard/learner'
          });
          
          setShowSuccessModal(true);
          setIsEnrolled(true);
          setEnrollmentId(result.enrollmentId);
          setIsProcessing(false);
        },
        (error) => {
          if (error !== 'Payment cancelled') {
            alert(`❌ Payment Error\n\n${error}`);
          }
          setIsProcessing(false);
        }
      );

    } catch (error: any) {
      console.error('❌ Enrollment error:', error);
      alert(`❌ Error\n\n${error.message || 'Please try again'}`);
      setIsProcessing(false);
    }
  };

  return (
    <>
      <Head>
        <title>{courseData.title} | {categoryData.name} Course | Sophiray</title>
        <meta name="description" content={`${courseData.description}. ${courseData.lectures} lectures, ${courseData.teacherSessions} live sessions. ${pricing.discountPercentage}% OFF - ₹${Math.round(pricing.displayPrice).toLocaleString()} only.`} />
      </Head>
      
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <Navigation />
        
        {/* Breadcrumb */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <nav className="flex items-center space-x-2 text-sm">
              <Link href="/" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors">
                Home
              </Link>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <Link href="/courses" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors">
                Courses
              </Link>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <Link href={`/courses/${params.category}`} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors">
                {categoryData.name}
              </Link>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <span className="text-gray-900 dark:text-white font-medium">
                {courseData.title}
              </span>
            </nav>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="mb-4">
                  <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {courseData.level}
                  </span>
                  <span className="ml-3 text-green-100">Updated {courseData.lastUpdated}</span>
                </div>
                
                <h1 className="text-4xl lg:text-5xl font-bold mb-4">
                  {courseData.title}
                </h1>
                
                {enhancedData?.subtitle && (
                  <p className="text-xl text-green-100 mb-6">
                    {enhancedData.subtitle}
                  </p>
                )}
                
                <div className="flex flex-wrap items-center gap-6 mb-6">
                  {/* <div className="flex items-center">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <span className="ml-2 font-semibold">{courseData.rating}</span>
                    <span className="ml-1 text-green-100">({courseData.reviews.toLocaleString()} reviews)</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="w-5 h-5 text-green-200" />
                    <span className="ml-2">{courseData.students.toLocaleString()} students</span>
                  </div> */}
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 text-green-200" />
                    <span className="ml-2">{courseData.duration} total</span>
                  </div>
                  <div className="flex items-center">
                    <Video className="w-5 h-5 text-green-200" />
                    <span className="ml-2">{courseData.lectures} lectures</span>
                  </div>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold mb-4">Course Structure</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold">{courseData.teacherSessions}</div>
                      <div className="text-green-200 text-sm">Live Teacher Sessions</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{courseData.totalSessions - courseData.teacherSessions}</div>
                      <div className="text-green-200 text-sm">Homework Sessions</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{courseData.totalSessions}</div>
                      <div className="text-green-200 text-sm">Total Sessions</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{Math.ceil(courseData.totalSessions / 4)}</div>
                      <div className="text-green-200 text-sm">Weeks Duration</div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {courseData.skills.slice(0, 6).map((skill: string, index: number) => (
                    <span key={index} className="bg-green-500/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                  {courseData.skills.length > 6 && (
                    <span className="bg-green-500/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm">
                      +{courseData.skills.length - 6} more
                    </span>
                  )}
                </div>
              </div>
              
              {/* Enrollment Card */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-xl sticky top-8">
                {isCheckingEnrollment ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-2"></div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Checking enrollment...</p>
                  </div>
                ) : isEnrolled ? (
                  <div>
                    <div className="mb-6 text-center">
                      <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
                      </div>
                      <h3 className="text-xl font-bold text-green-600 dark:text-green-400 mb-2">
                        Already Enrolled!
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm">
                        Continue your learning journey.
                      </p>
                    </div>
                    
                    <button 
                      onClick={handleEnrollClick}
                      className="w-full bg-green-600 text-white py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors mb-3 flex items-center justify-center text-lg"
                    >
                      <PlayCircle className="w-5 h-5 mr-2" />
                      Continue Learning
                    </button>
                    
                    <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mb-2">
                        <Award className="w-4 h-4 text-green-600 mr-2" />
                        <span>Track your progress</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                        <Shield className="w-4 h-4 text-green-600 mr-2" />
                        <span>Access all materials</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="mb-6">
                      {isPriceLoading ? (
                        <div className="animate-pulse">
                          <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-2"></div>
                          <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center justify-between mb-2">
                            <div className="text-3xl font-bold text-green-600">
                              ₹{Math.round(pricing.displayPrice).toLocaleString()}
                            </div>
                            <div className="text-lg text-gray-500 line-through">
                              ₹{pricing.originalPrice.toLocaleString()}
                            </div>
                          </div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="text-sm text-red-600 font-medium">
                              {pricing.discountPercentage}% OFF - Limited Time
                            </div>
                            <div className="text-sm text-green-600 font-medium">
                              Save ₹{pricing.savings.toLocaleString()}
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                    
                    <button 
                      onClick={handleEnrollClick}
                      disabled={isProcessing || isPriceLoading}
                      className="w-full bg-green-600 text-white py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mb-3 flex items-center justify-center text-lg"
                    >
                      {isProcessing ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Processing...
                        </>
                      ) : isPriceLoading ? (
                        'Loading...'
                      ) : (
                        <>
                          <PlayCircle className="w-5 h-5 mr-2" />
                          Enroll Now
                        </>
                      )}
                    </button>
                    
                    <button 
                      onClick={handleWishlist}
                      className={`w-full border py-3 rounded-lg font-semibold transition-colors mb-6 flex items-center justify-center ${
                        isWishlisted 
                          ? 'border-red-500 text-red-600 bg-red-50 dark:bg-red-900/20' 
                          : 'border-green-600 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20'
                      }`}
                    >
                      <Heart className={`w-5 h-5 mr-2 ${isWishlisted ? 'fill-current' : ''}`} />
                      {isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                    </button>

                    <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mb-3">
                        <Shield className="w-4 h-4 text-green-600 mr-2" />
                        <span>Money-back guarantee</span>
                      </div>
                      <button className="w-full flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white transition-colors">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share this course
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Course Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              {/* Navigation Tabs */}
              <div className="flex flex-wrap gap-2 mb-8 border-b border-gray-200 dark:border-gray-700">
                <TabButton 
                  id="overview" 
                  label="Overview" 
                  isActive={activeTab === 'overview'} 
                  onClick={setActiveTab} 
                />
                <TabButton 
                  id="syllabus" 
                  label="Syllabus" 
                  isActive={activeTab === 'syllabus'} 
                  onClick={setActiveTab} 
                />
                {enhancedData?.learningPath && (
                  <TabButton 
                    id="roadmap" 
                    label="Learning Path" 
                    isActive={activeTab === 'roadmap'} 
                    onClick={setActiveTab} 
                  />
                )}
                <TabButton 
                  id="reviews" 
                  label="Reviews" 
                  isActive={activeTab === 'reviews'} 
                  onClick={setActiveTab} 
                />
              </div>
              
              {/* Tab Content Using Components */}
              {activeTab === 'overview' && (
                <div className="space-y-8">
                  <CourseOverview
                    description={courseData.description}
                    teacherSessions={courseData.teacherSessions}
                    totalSessions={courseData.totalSessions}
                    prerequisites={enhancedData?.requirements || courseData.prerequisites}
                    whatYoullLearn={enhancedData?.whatYoullLearn || courseData.skills}
                  />
                  
                  {enhancedData?.projects && (
                    <CourseProjects projects={enhancedData.projects} />
                  )}
                </div>
              )}
              
              {activeTab === 'syllabus' && enhancedData?.syllabus && (
                <CourseSyllabus syllabus={enhancedData.syllabus} />
              )}
              
              {activeTab === 'roadmap' && enhancedData?.learningPath && (
                <LearningPath
                  learningPath={enhancedData.learningPath}
                  teacherSessions={courseData.teacherSessions}
                  totalSessions={courseData.totalSessions}
                />
              )}

              {activeTab === 'reviews' && (
                <CourseReviews
                  rating={courseData.rating}
                  totalReviews={courseData.reviews}
                  reviews={sampleReviews}
                  ratingBreakdown={ratingBreakdown}
                />
              )}
            </div>
            
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-8 space-y-6">
                {/* Certificate Preview - ONLY show if certificate is available */}
                {courseData.certificate && (
                  <CertificatePreview courseTitle={courseData.title} />
                )}
              </div>
            </div>
          </div>
        </div>

        <Footer />
        
        <AuthModal 
          isOpen={showAuthModal} 
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => setShowAuthModal(false)}
        />
        
        {paymentResult && (
          <PaymentSuccessModal
            isOpen={showSuccessModal}
            onClose={() => setShowSuccessModal(false)}
            type="course"
            data={paymentResult}
          />
        )}
      </div>
    </>
  );
};

export default CoursePageClient;