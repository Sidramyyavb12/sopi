// app/courses/[category]/[courseId]/page.tsx - Dynamic Course Page (Server Component)
import React from 'react';
import { notFound } from 'next/navigation';
import { getAllCategories, getCourseData, getAllCourseParams } from '@/lib/courseData';
import CoursePageClient from './CoursePageClient';

// Type definitions
interface Course {
  id: string;
  title: string;
  level: string;
  duration: string;
  teacherSessions: number;
  totalSessions: number;
  lectures: number;
  students: number;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  lastUpdated: string;
  language: string;
  captions: string[];
  certificate: boolean;
  lifetimeAccess: boolean;
  mobileAccess: boolean;
  description: string;
  prerequisites: string[];
  skills: string[];
}

interface Category {
  name: string;
  slug: string;
  icon: string;
  color: string;
  description: string;
  students: string;
  avgRating: number;
  courses: Course[];
}

interface CoursePageProps {
  params: {
    category: string;
    courseId: string;
  };
}

// Utility function to convert category name to slug
const getCategorySlug = (categoryName: string) => {
  return categoryName.toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/&/g, '')
    .replace(/[^a-z0-9-]/g, '');
};

// Generate static params for all courses
export async function generateStaticParams() {
  const categories: Category[] = getAllCategories();
  const params: Array<{ category: string; courseId: string }> = [];
  
  categories.forEach((category) => {
    const categorySlug = getCategorySlug(category.name);
    category.courses.forEach((course) => {
      params.push({
        category: categorySlug,
        courseId: course.id
      });
    });
  });
  
  return params;
}

// Generate metadata for SEO
export async function generateMetadata({ params }: CoursePageProps) {
  const categories: Category[] = getAllCategories();
  const categoryData = categories.find((cat: Category) => 
    getCategorySlug(cat.name) === params.category
  );
  
  if (!categoryData) {
    return {
      title: 'Course Not Found',
      description: 'The requested course could not be found.'
    };
  }

  const courseData = categoryData.courses.find(course => course.id === params.courseId);
  
  if (!courseData) {
    return {
      title: 'Course Not Found',
      description: 'The requested course could not be found.'
    };
  }

  const discountPercentage = Math.round(((courseData.originalPrice - courseData.price) / courseData.originalPrice) * 100);

  return {
    title: `${courseData.title} | ${categoryData.name} Course | Sophiray`,
    description: `${courseData.description}. ${courseData.lectures} lectures, ${courseData.teacherSessions} live sessions. ${discountPercentage}% OFF - ₹${courseData.price.toLocaleString()} only.`,
    keywords: [
      courseData.title.toLowerCase(),
      categoryData.name.toLowerCase(),
      ...courseData.skills.map(skill => skill.toLowerCase()),
      `${courseData.title.toLowerCase()} one-on-one tutorial`,
      `${courseData.title.toLowerCase()} 1-on-1 mentoring`,
      `${courseData.title.toLowerCase()} personalized coaching`,
      `${courseData.title.toLowerCase()} certification`,
      `${courseData.title.toLowerCase()} live online training`,
      'online course',
      'programming',
      'tutorial',
      'certification',
      'one on one tutorial',
      '1-on-1 tutorial'
    ].join(', '),
    openGraph: {
      title: `${courseData.title} | Learn ${categoryData.name}`,
      description: courseData.description,
      type: 'website',
    },
  };
}

export default function CoursePage({ params }: CoursePageProps) {
  const categories: Category[] = getAllCategories();
  const categoryData = categories.find((cat: Category) => 
    getCategorySlug(cat.name) === params.category
  );
  
  if (!categoryData) {
    notFound();
  }

  const courseData = categoryData.courses.find(course => course.id === params.courseId);
  
  if (!courseData) {
    notFound();
  }

  // Get related courses from the same category
  const relatedCourses = categoryData.courses
    .filter(course => course.id !== params.courseId)
    .slice(0, 3);

  // NOTE: We're NOT fetching backend price here in the server component
  // The client component will fetch it directly using useEffect
  // This keeps the component simple and avoids SSR complications

  return (
    <CoursePageClient 
      courseData={courseData} 
      categoryData={categoryData}
      relatedCourses={relatedCourses}
      params={params} 
    />
  );
}