// app/courses/[category]/page.tsx - Dynamic Category Page (Server Component)
import React from 'react';
import { notFound } from 'next/navigation';
import { getAllCategories } from '@/lib/courseData';
import CategoryPageClient from './CategoryPageClient';

// Type definitions
interface Course {
  id: string;
  title: string;
  level: string;
  duration: string;
  teacherSessions: number;
  totalSessions: number;
  lectures: number;
  students: number;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  lastUpdated: string;
  language: string;
  captions: string[];
  certificate: boolean;
  lifetimeAccess: boolean;
  mobileAccess: boolean;
  description: string;
  prerequisites: string[];
  skills: string[];
}

interface Category {
  name: string;
  slug: string;
  icon: string;
  color: string;
  description: string;
  students: string;
  avgRating: number;
  courses: Course[];
}

interface CategoryPageProps {
  params: {
    category: string;
  };
}

// Utility function to convert category name to slug
const getCategorySlug = (categoryName: string) => {
  return categoryName.toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/&/g, '')
    .replace(/[^a-z0-9-]/g, '');
};

// Generate static params for all categories
export async function generateStaticParams() {
  const categories: Category[] = getAllCategories();
  
  return categories.map((category) => ({
    category: getCategorySlug(category.name)
  }));
}

// Generate metadata for SEO
export async function generateMetadata({ params }: CategoryPageProps) {
  const categories: Category[] = getAllCategories();
  const categoryData = categories.find((cat: Category) => 
    getCategorySlug(cat.name) === params.category
  );
  
  if (!categoryData) {
    return {
      title: 'Category Not Found',
      description: 'The requested category could not be found.'
    };
  }

  const topSkills = Array.from(new Set(categoryData.courses.flatMap((c: Course) => c.skills || [])))
    .slice(0, 10)
    .map(s => s.toLowerCase());

  return {
    title: `${categoryData.name} Courses | Learn ${categoryData.name} Online | Sophiray`,
    description: `${categoryData.description}. ${categoryData.students} students enrolled. ${categoryData.courses.length} courses available.`,
    keywords: [
      categoryData.name.toLowerCase(),
      ...categoryData.courses.slice(0, 5).map((course: Course) => course.title.toLowerCase()),
      ...topSkills,
      `${categoryData.name.toLowerCase()} one-on-one tutorial`,
      `${categoryData.name.toLowerCase()} 1-on-1 mentoring`,
      `${categoryData.name.toLowerCase()} personalized coaching`,
      `${categoryData.name.toLowerCase()} live online training`,
      `${categoryData.name.toLowerCase()} certificate course`,
      'online courses',
      'sophiray',
      'programming',
      'tutorial',
      'one on one tutorial',
      '1-on-1 tutorial'
    ].join(', '),
  };
}

export default function CategoryPage({ params }: CategoryPageProps) {
  // Find category data by slug with better error handling
  const categories: Category[] = getAllCategories();
  const categoryData = categories.find((cat: Category) => 
    getCategorySlug(cat.name) === params.category
  );
  
  if (!categoryData) {
    notFound();
  }

  return <CategoryPageClient categoryData={categoryData} params={params} />;
}