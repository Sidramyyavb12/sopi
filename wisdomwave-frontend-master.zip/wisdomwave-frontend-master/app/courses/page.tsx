// app/courses/page.tsx - Enhanced with clickable category cards and course links
'use client'

import React, { useState, useMemo } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import AuthModal from '@/components/auth/AuthModal'
import { useAuth } from '@/hooks/useAuth'
import { getAllCategories, getCourseStatistics } from '@/lib/courseData'
import {
  Code2, Globe, BarChart3, Brain, Cloud, Shield, Smartphone, Palette, TrendingUp,
  ChevronRight, Star, Users, BookOpen, Search, Zap, Target, Award,
  Sparkles, Rocket, Trophy, Briefcase
} from 'lucide-react'

// Enhanced icon mapping
const iconMap: { [key: string]: React.ComponentType<{ className?: string }> } = {
  '💻': Code2, '🌐': Globe, '📊': BarChart3, '🔐': Shield, '📱': Smartphone,
  '🤖': Brain, '☁️': Cloud, '🎨': Palette, '📈': TrendingUp,
  '🚀': Rocket, '🏆': Trophy, '💼': Briefcase
}

// Gradient color variants
const colorVariants: { [key: string]: string } = {
  'bg-blue-500': 'from-blue-500 to-blue-600',
  'bg-emerald-500': 'from-emerald-500 to-emerald-600',
  'bg-purple-500': 'from-purple-500 to-purple-600',
  'bg-orange-500': 'from-orange-500 to-orange-600',
  'bg-yellow-500': 'from-yellow-500 to-yellow-600',
  'bg-indigo-500': 'from-indigo-500 to-indigo-600',
  'bg-red-500': 'from-red-500 to-red-600',
  'bg-cyan-500': 'from-cyan-500 to-cyan-600',
  'bg-pink-500': 'from-pink-500 to-pink-600',
  'bg-teal-500': 'from-teal-500 to-teal-600'
}

interface Course {
  id: string
  title: string
  level: string
  duration: string
  students: number
  price: number
  originalPrice: number
  rating: number
  reviews: number
  skills: string[]
  description: string
}

interface Category {
  name: string
  slug: string
  icon: string
  color: string
  description: string
  students: string
  avgRating: number
  courses: Course[]
}

const learningStats = [
  { icon: Users, value: '2K+', label: 'Active Learners', color: 'text-blue-600' },
  { icon: BookOpen, value: '50+', label: 'Expert Courses', color: 'text-green-600' },
  { icon: Trophy, value: '4.8', label: 'Avg Rating', color: 'text-yellow-600' },
  { icon: Award, value: '95%', label: 'Success Rate', color: 'text-purple-600' }
]

export default function CoursesPage() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('all')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const { user } = useAuth()
  const router = useRouter()

  const categories: Category[] = getAllCategories()
  const stats = getCourseStatistics()

  // SEO keywords from course titles and skills + one-on-one tutorial variants
  const seoKeywords = useMemo(() => {
    const titles = categories.flatMap(c => c.courses.map(course => course.title.toLowerCase()))
    const skills = categories.flatMap(c => c.courses.flatMap(course => (course.skills || []).map(s => s.toLowerCase())))
    const base = Array.from(new Set([...titles, ...skills]))

    const variants = [
      'one on one tutorial',
      '1-on-1 tutorial',
      'personalized mentoring',
      'live online training',
      'certificate course'
    ]

    const expanded = [
      ...base,
      ...base.slice(0, 50).flatMap(k => variants.map(v => `${k} ${v}`))
    ]

    return Array.from(new Set(expanded)).join(', ')
  }, [categories])

  const handleAuthSuccess = () => {
    setShowAuthModal(false)
    if (user?.role === 'INSTRUCTOR') window.location.href = '/dashboard/instructor'
    else if (user?.role === 'LEARNER') window.location.href = '/dashboard/learner'
  }

  const filteredCategories = useMemo(() => {
    return categories.filter((category) => {
      const searchLower = searchQuery.toLowerCase().trim()
      if (searchLower) {
        const categoryMatch =
          category.name.toLowerCase().includes(searchLower) ||
          category.description.toLowerCase().includes(searchLower)
        const courseMatch = category.courses.some(
          (course) =>
            course.title.toLowerCase().includes(searchLower) ||
            course.description.toLowerCase().includes(searchLower) ||
            course.skills.some((s) => s.toLowerCase().includes(searchLower))
        )
        if (!categoryMatch && !courseMatch) return false
      }
      const matchesFilter =
        selectedFilter === 'all' ||
        (selectedFilter === 'popular' && parseInt(category.students.replace('K+', '')) > 100) ||
        (selectedFilter === 'trending' && category.avgRating > 4.7) ||
        (selectedFilter === 'new' &&
          (category.name.includes('AI') ||
            category.name.includes('Edge') ||
            category.name.includes('Web3')))
      return matchesFilter
    })
  }, [categories, searchQuery, selectedFilter])

  const totalMatchingCourses = useMemo(
    () => filteredCategories.reduce((t, c) => t + c.courses.length, 0),
    [filteredCategories]
  )

  const getCategorySlug = (name: string) =>
    name.toLowerCase().replace(/\s+/g, '-').replace(/&/g, '').replace(/[^a-z0-9-]/g, '')

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Head>
        <title>All Courses | One-on-One Tutorials & Mentorship | Sophiray</title>
        <meta
          name="description"
          content="Browse all Sophiray courses with personalized one-on-one tutorials and mentorship. Learn React, Next.js, Node.js, Python, Data Science, AI/ML, DevOps, Mobile, and more with live expert guidance."
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content="All Courses | One-on-One Tutorials & Mentorship | Sophiray" />
        <meta
          property="og:description"
          content="Personalized 1-on-1 learning across 50+ tech courses. Hands-on projects, interview prep, and certificates."
        />
        <meta property="og:type" content="website" />
      </Head>
      <Navigation />

      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-green-600 via-green-700 to-green-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-grid-pattern"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-green-800/50 to-transparent"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-green-500/20 border border-green-400/30 text-green-100 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4 mr-2" />
            2025 Updated Curriculum • New AI & Edge Computing Courses
          </div>
          <h1 className="text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-green-100 bg-clip-text text-transparent">
            Master Any Technology
          </h1>
          <p className="text-xl lg:text-2xl text-green-100 mb-8 max-w-4xl mx-auto leading-relaxed">
            Choose from <span className="font-bold text-yellow-300">{stats.totalCourses}+ expert-designed courses</span> across {stats.totalCategories} categories.
            Learn with AI-powered mentorship, hands-on projects, and lifetime access.
          </p>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {filteredCategories.map((category, i) => {
            const gradientClass = colorVariants[category.color] || 'from-gray-500 to-gray-600'
            const slug = getCategorySlug(category.name)

            return (
              <Link
                key={i}
                href={`/courses/${slug}`}
                className="group block bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-gray-200 dark:border-gray-700 hover:-translate-y-3 cursor-pointer"
              >
                {/* Header */}
                <div className={`bg-gradient-to-r ${gradientClass} p-8 text-white relative overflow-hidden`}>
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-5xl">{category.icon}</div>
                      <div className="text-right">
                        <div className="text-3xl font-bold">{category.courses.length}</div>
                        <div className="text-sm opacity-90">courses</div>
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold mb-3">{category.name}</h3>
                    <p className="text-sm opacity-90 leading-relaxed">{category.description}</p>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-3">Featured Courses:</h4>

                  {category.courses.slice(0, 2).map((course, idx) => (
                    <div
                      key={idx}
                      role="link"
                      tabIndex={0}
                      onClick={(e) => {
                        e.stopPropagation()
                        router.push(`/courses/${slug}/${course.id}`)
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault()
                          e.stopPropagation()
                          router.push(`/courses/${slug}/${course.id}`)
                        }
                      }}
                      className="block bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-3 hover:bg-gray-100 dark:hover:bg-gray-600 transition cursor-pointer"
                    >
                      <div className="font-semibold text-gray-900 dark:text-white text-sm mb-1">
                        {course.title}
                      </div>
                      <div className="inline-flex items-center px-2 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-full text-xs font-medium">
                        {course.level}
                      </div>
                    </div>
                  ))}

                  {category.courses.length > 2 && (
                    <div className="text-sm text-gray-500 text-center">
                      +{category.courses.length - 2} more courses available
                    </div>
                  )}

                  {/* CTA */}
                  <div className={`group/btn mt-6 w-full flex items-center justify-center py-4 px-6 rounded-xl font-semibold transition-all duration-300 bg-gradient-to-r ${gradientClass} hover:shadow-lg hover:shadow-green-500/25 text-white transform hover:scale-[1.02]`}>
                    <span>Explore {category.name}</span>
                    <ChevronRight className="w-5 h-5 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>

      <Footer />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  )
}