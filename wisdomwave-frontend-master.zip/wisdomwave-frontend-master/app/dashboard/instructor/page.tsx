'use client'

import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { useAuth } from '@/hooks/useAuth'
import { ApiService } from '@/lib/api'
import { InstructorDashboard } from '@/types/user'
import { 
  Users, 
  BookOpen, 
  DollarSign, 
  Star,
  Loader2,
  Phone,
  Mail,
  MessageCircle,
  Clock
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function InstructorDashboardPage() {
  const { user, isLoading: authLoading } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [dashboardData, setDashboardData] = useState<InstructorDashboard | null>(null)
  const [isLoadingData, setIsLoadingData] = useState(true)
  const [hasCheckedAuth, setHasCheckedAuth] = useState(false)
  const router = useRouter()

  // Auth check - RUNS ONLY ONCE after auth loads
  useEffect(() => {
    console.group('🔍 Instructor Dashboard - Auth Check')
    console.log('Auth Loading:', authLoading)
    console.log('User:', user ? `${user.name} (${user.role})` : 'None')
    console.log('Has Checked:', hasCheckedAuth)
    
    // Wait for auth to finish loading
    if (authLoading) {
      console.log('⏳ Still loading auth state...')
      console.groupEnd()
      return
    }
    
    // Only check once after auth has loaded
    if (!hasCheckedAuth) {
      setHasCheckedAuth(true)
      
      if (!user) {
        console.log('❌ No user found, redirecting to login')
        console.groupEnd()
        router.push('/login?from=/dashboard/instructor')
        return
      }

      if (user.role !== 'INSTRUCTOR') {
        console.log(`❌ Wrong role (${user.role}), redirecting to learner dashboard`)
        console.groupEnd()
        router.push('/dashboard/learner')
        return
      }
      
      console.log('✅ Auth check passed - user is INSTRUCTOR')
    }
    
    console.groupEnd()
  }, [authLoading, user, hasCheckedAuth, router])

  // Fetch dashboard data - runs when we have valid user
  useEffect(() => {
    if (!user || authLoading || user.role !== 'INSTRUCTOR') {
      return
    }

    const fetchDashboardData = async () => {
      console.log('📊 Fetching instructor dashboard data...')
      
      try {
        setIsLoadingData(true)
        const data = await ApiService.getInstructorDashboard()
        console.log('✅ Dashboard data loaded')
        setDashboardData(data)
      } catch (error) {
        console.error('❌ Failed to fetch dashboard data:', error)
        // Fallback data for demo
        setDashboardData({
          user,
          stats: [
            { title: "Active Students", value: "324", icon: "Users", color: "blue" },
            { title: "Total Courses", value: "12", icon: "BookOpen", color: "green" },
            { title: "Monthly Revenue", value: "$8,940", icon: "DollarSign", color: "purple" },
            { title: "Avg Rating", value: "4.8", icon: "Star", color: "yellow" }
          ],
          courses: [
            { 
              id: '1',
              title: "Full Stack Web Development Bootcamp", 
              students: 156, 
              rating: 4.9, 
              status: "Active" as const,
              revenue: 5400,
              lastUpdated: "2024-01-15"
            }
          ],
          recentEnrollments: [
            { 
              id: '1',
              studentName: "Alex Rivera", 
              studentAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=alex",
              courseName: "Full Stack Web Development", 
              enrolledAt: "2 hours ago",
              amount: 299
            }
          ],
          upcomingSessions: [
            { 
              id: '1',
              courseId: '1',
              courseName: "Full Stack Web Development", 
              instructorName: user.name,
              scheduledTime: "Today, 2:00 PM", 
              duration: 60,
              type: "live" as const,
              meetingLink: "https://meet.google.com/abc-def-ghi"
            }
          ],
          earnings: {
            totalEarnings: 25400,
            thisMonth: 8940,
            lastMonth: 7200,
            pendingPayouts: 2500,
            nextPayoutDate: "2024-02-01"
          }
        })
      } finally {
        setIsLoadingData(false)
      }
    }

    fetchDashboardData()
  }, [user, authLoading])

  const getIconComponent = (iconName: string) => {
    const icons = {
      Users,
      BookOpen,
      DollarSign,
      Star
    }
    return icons[iconName as keyof typeof icons] || Users
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  // Show loading while auth is loading
  if (authLoading || !hasCheckedAuth) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-green-600" />
          <p className="text-gray-600 dark:text-gray-300">Loading...</p>
        </div>
      </div>
    )
  }

  // Don't render if wrong role (redirect will happen in useEffect)
  if (!user || user.role !== 'INSTRUCTOR') {
    return null
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Head>
        <title>Instructor Dashboard | 1-on-1 Teaching Platform | Sophiray</title>
        <meta
          name="description"
          content="Manage courses, sessions, and students on Sophiray. Deliver personalized one-on-one tutorials with seamless scheduling and feedback."
        />
        <meta name="keywords" content="instructor dashboard, sophiray, one on one tutorial, 1-on-1 teaching" />
        <meta name="robots" content="noindex, follow" />
      </Head>
      <Navigation />
      
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Welcome Header */}
          <div className="mb-8">
            <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-xl p-6 text-white">
              <h1 className="text-3xl font-bold mb-2">
                Welcome back, {user.name}! 👨‍🏫
              </h1>
              <p className="text-green-100 text-lg">Manage your courses and inspire students with Sophiray</p>
            </div>
          </div>

          {/* Contact Support Section */}
          <div className="mb-8">
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-blue-900 dark:text-blue-100 mb-4 flex items-center">
                <MessageCircle className="w-6 h-6 mr-2" />
                Instructor Support & Assistance
              </h2>
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  href="tel:+919502666078" 
                  className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Call: +91 95026 66078
                </a>
                <a 
                  href="https://wa.me/919502666078" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp Support
                </a>
                <a 
                  href="mailto:instructor@sophiray.com" 
                  className="flex items-center bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Instructor Portal
                </a>
              </div>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex space-x-1 mb-8 bg-white dark:bg-gray-800 p-1 rounded-lg shadow overflow-x-auto">
            {['overview', 'courses', 'students', 'earnings', 'schedule'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-3 px-4 rounded-md capitalize transition-colors font-medium whitespace-nowrap ${
                  activeTab === tab
                    ? 'bg-green-600 text-white shadow-sm'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          
          {/* Loading State for Dashboard Data */}
          {isLoadingData ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-green-600" />
                <p className="text-gray-600 dark:text-gray-300">Loading dashboard data...</p>
              </div>
            </div>
          ) : (
            <>
              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="space-y-8">
                  {/* Stats Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {dashboardData?.stats?.map((stat, index) => {
                      const IconComponent = getIconComponent(stat.icon)
                      return (
                        <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-300">{stat.title}</p>
                              <p className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                            </div>
                            <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                              <IconComponent className="w-6 h-6 text-green-600" />
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  
                  {/* Recent Activity */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Recent Enrollments */}
                    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                        Recent Enrollments
                      </h3>
                      <div className="space-y-4">
                        {dashboardData?.recentEnrollments?.slice(0, 4).map((enrollment) => (
                          <div key={enrollment.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                            <div className="flex items-center">
                              <img 
                                src={enrollment.studentAvatar}
                                alt={enrollment.studentName}
                                className="w-10 h-10 rounded-full mr-3"
                              />
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{enrollment.studentName}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-300">{enrollment.courseName}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-green-600 dark:text-green-400">{formatCurrency(enrollment.amount)}</p>
                              <p className="text-sm text-gray-500 dark:text-gray-400">{enrollment.enrolledAt}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* Upcoming Sessions */}
                    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                        Today's Sessions
                      </h3>
                      <div className="space-y-4">
                        {dashboardData?.upcomingSessions?.slice(0, 4).map((session) => (
                          <div key={session.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                            <div className="flex items-center">
                              <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mr-3">
                                <Clock className="w-5 h-5 text-green-600 dark:text-green-400" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{session.courseName}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-300">{session.scheduledTime}</p>
                              </div>
                            </div>
                            <Button size="sm" className="bg-green-600 hover:bg-green-700">
                              Start
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  )
}