'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { useAuth } from '@/hooks/useAuth'
import { ApiService } from '@/lib/api'
import { 
  CheckCircle,
  Circle,
  Clock,
  Play,
  Loader2,
  BookOpen,
  User,
  Calendar,
  Award,
  TrendingUp,
  Upload,
  ChevronDown,
  ChevronUp,
  ArrowLeft
} from 'lucide-react'
import { Button } from '@/components/ui/button'

interface SessionProgress {
  sessionProgressId: number
  weekNumber: number
  sessionNumber: number
  sessionTitle: string
  sessionType: string
  status: string
  startedAt?: string
  completedAt?: string
  homeworkSubmitted: boolean
  homeworkFileUrl?: string
  attendanceStatus?: string
}

interface WeekProgress {
  weekNumber: number
  weekTitle: string
  sessions: SessionProgress[]
}

interface CourseProgress {
  enrollmentId: number
  courseId: string
  courseTitle: string
  categoryName: string
  instructorName: string
  level: string
  totalSessions: number
  completedSessions: number
  progressPercentage: number
  enrolledAt: string
  weeks: WeekProgress[]
}

export default function CourseProgressPage({ params }: { params: { enrollmentId: string } }) {
  const { user, isLoading: authLoading } = useAuth()
  const [progress, setProgress] = useState<CourseProgress | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [expandedWeek, setExpandedWeek] = useState<number | null>(null)
  const router = useRouter()

  useEffect(() => {
    if (authLoading) return
    if (!user) {
      router.push('/login')
      return
    }
    if (user.role !== 'LEARNER') {
      router.push('/')
      return
    }

    fetchProgress()
  }, [authLoading, user, params.enrollmentId])

  const fetchProgress = async () => {
    try {
      setIsLoading(true)
      const data = await ApiService.getCourseProgress(parseInt(params.enrollmentId))
      console.log('📊 Course progress:', data)
      setProgress(data)
      
      // Auto-expand first incomplete week
      const firstIncompleteWeek = data.weeks.find((week: WeekProgress) => 
        week.sessions.some((s: SessionProgress) => s.status !== 'COMPLETED')
      )
      if (firstIncompleteWeek) {
        setExpandedWeek(firstIncompleteWeek.weekNumber)
      } else if (data.weeks.length > 0) {
        // If all weeks complete, expand the last one
        setExpandedWeek(data.weeks[data.weeks.length - 1].weekNumber)
      }
    } catch (error) {
      console.error('❌ Failed to fetch progress:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleStartSession = async (session: SessionProgress) => {
    try {
      await ApiService.startSession(
        progress!.enrollmentId,
        session.weekNumber,
        session.sessionNumber
      )
      await fetchProgress()
    } catch (error) {
      console.error('❌ Failed to start session:', error)
      alert('Failed to start session')
    }
  }

  const handleCompleteSession = async (session: SessionProgress) => {
    try {
      await ApiService.completeSession(
        progress!.enrollmentId,
        session.weekNumber,
        session.sessionNumber
      )
      await fetchProgress()
    } catch (error) {
      console.error('❌ Failed to complete session:', error)
      alert('Failed to complete session')
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="w-6 h-6 text-green-600" />
      case 'IN_PROGRESS':
        return <Play className="w-6 h-6 text-blue-600" />
      default:
        return <Circle className="w-6 h-6 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-50 border-green-500'
      case 'IN_PROGRESS':
        return 'bg-blue-50 border-blue-500'
      default:
        return 'bg-white border-gray-300'
    }
  }

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-green-600" />
          <p className="text-gray-600">Loading course progress...</p>
        </div>
      </div>
    )
  }

  if (!progress) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-600">Course not found</p>
          <Button 
            onClick={() => router.push('/dashboard/learner')}
            className="mt-4"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Button
            variant="outline"
            onClick={() => router.push('/dashboard/learner')}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>

          {/* Course Header */}
          <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-8 text-white mb-8">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">{progress.courseTitle}</h1>
                <p className="text-green-100 text-lg mb-4">{progress.categoryName}</p>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-2" />
                    {progress.instructorName}
                  </div>
                  <div className="flex items-center">
                    <Award className="w-4 h-4 mr-2" />
                    {progress.level}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    Enrolled {new Date(progress.enrolledAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
                <div className="text-4xl font-bold mb-1">{progress.progressPercentage}%</div>
                <div className="text-green-100 text-sm">Complete</div>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-green-100">Overall Progress</span>
                <span className="text-sm text-green-100">
                  {progress.completedSessions} / {progress.totalSessions} sessions
                </span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-4">
                <div 
                  className="bg-white h-4 rounded-full transition-all duration-300"
                  style={{ width: `${progress.progressPercentage}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Learning Path Roadmap */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Learning Path Roadmap
            </h2>
            
            {progress.weeks.map((week) => {
              const weekProgress = Math.round(
                (week.sessions.filter((s: SessionProgress) => s.status === 'COMPLETED').length / week.sessions.length) * 100
              )
              const isExpanded = expandedWeek === week.weekNumber
              
              return (
                <div 
                  key={week.weekNumber}
                  className="bg-white rounded-xl shadow-lg border-2 border-gray-200 overflow-hidden"
                >
                  {/* Week Header */}
                  <button
                    onClick={() => setExpandedWeek(isExpanded ? null : week.weekNumber)}
                    className="w-full p-6 bg-gradient-to-r from-gray-50 to-gray-100 hover:from-gray-100 hover:to-gray-200 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                          {week.weekNumber}
                        </div>
                        <div className="text-left">
                          <h3 className="text-xl font-semibold text-gray-900">
                            {week.weekTitle}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {week.sessions.length} sessions • {weekProgress}% complete
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-2xl font-bold text-green-600">{weekProgress}%</div>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-6 h-6 text-gray-600" />
                        ) : (
                          <ChevronDown className="w-6 h-6 text-gray-600" />
                        )}
                      </div>
                    </div>
                    
                    {/* Mini Progress Bar */}
                    <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full transition-all"
                        style={{ width: `${weekProgress}%` }}
                      ></div>
                    </div>
                  </button>
                  
                  {/* Week Sessions */}
                  {isExpanded && (
                    <div className="p-6 space-y-4">
                      {week.sessions.map((session) => (
                        <div 
                          key={session.sessionProgressId}
                          className={`border-2 rounded-lg p-6 transition-all ${getStatusColor(session.status)}`}
                        >
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-start space-x-4 flex-1">
                              {getStatusIcon(session.status)}
                              <div className="flex-1">
                                <div className="flex items-center mb-2">
                                  <span className={`px-3 py-1 rounded-full text-xs font-medium mr-3 ${
                                    session.sessionType === 'TEACHER' 
                                      ? 'bg-green-100 text-green-800'
                                      : 'bg-blue-100 text-blue-800'
                                  }`}>
                                    {session.sessionType === 'TEACHER' ? (
                                      <span className="flex items-center">
                                        <User className="w-3 h-3 mr-1" />
                                        LIVE SESSION
                                      </span>
                                    ) : (
                                      <span className="flex items-center">
                                        <BookOpen className="w-3 h-3 mr-1" />
                                        HOMEWORK
                                      </span>
                                    )}
                                  </span>
                                </div>
                                <h4 className="text-lg font-semibold text-gray-900 mb-2">
                                  Session {session.sessionNumber}: {session.sessionTitle}
                                </h4>
                                {session.startedAt && (
                                  <p className="text-sm text-gray-600">
                                    Started: {new Date(session.startedAt).toLocaleString()}
                                  </p>
                                )}
                                {session.completedAt && (
                                  <p className="text-sm text-green-600">
                                    Completed: {new Date(session.completedAt).toLocaleString()}
                                  </p>
                                )}
                              </div>
                            </div>
                            
                            {/* Action Buttons */}
                            <div className="flex flex-col space-y-2">
                              {session.status === 'NOT_STARTED' && (
                                <Button 
                                  onClick={() => handleStartSession(session)}
                                  className="bg-blue-600 hover:bg-blue-700"
                                  size="sm"
                                >
                                  <Play className="w-4 h-4 mr-2" />
                                  Start Session
                                </Button>
                              )}
                              {session.status === 'IN_PROGRESS' && (
                                <Button 
                                  onClick={() => handleCompleteSession(session)}
                                  className="bg-green-600 hover:bg-green-700"
                                  size="sm"
                                >
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Mark Complete
                                </Button>
                              )}
                              {session.sessionType === 'HOMEWORK' && session.status === 'IN_PROGRESS' && (
                                <Button 
                                  variant="outline"
                                  size="sm"
                                >
                                  <Upload className="w-4 h-4 mr-2" />
                                  Upload Homework
                                </Button>
                              )}
                            </div>
                          </div>
                          
                          {/* Homework Status */}
                          {session.sessionType === 'HOMEWORK' && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">
                                  Homework Status:
                                </span>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  session.homeworkSubmitted 
                                    ? 'bg-green-100 text-green-800'
                                    : 'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {session.homeworkSubmitted ? 'Submitted' : 'Pending'}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}