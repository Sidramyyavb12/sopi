'use client'

import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { useAuth } from '@/hooks/useAuth'
import { ApiService } from '@/lib/api'
import { 
  BookOpen, 
  Video, 
  Calendar, 
  Clock, 
  CheckCircle, 
  TrendingUp,
  Award,
  Play,
  MessageCircle,
  Phone,
  Mail,
  ChevronRight,
  MapPin,
  BarChart3,
  Zap,
  Loader2,
  Circle,
  Code
} from 'lucide-react'
import { Button } from '@/components/ui/button'

// TypeScript Interfaces
interface EnrolledCourse {
  enrollmentId: number
  courseId: string
  courseTitle: string
  categoryName: string
  instructorName?: string
  level: string
  enrolledAt: string
  progressPercentage: number
  completedSessions: number
  totalSessions: number
  nextSessionWeek?: number
  nextSessionNumber?: number
  nextSessionTitle?: string
  nextSessionType?: string
  totalWeeks: number
  currentWeek: number
}

interface MockInterview {
  bookingId: number
  interviewTypeId: string
  interviewTypeName: string
  scheduledDateTime: string
  status: string
  programmingLanguage?: string
  amount: number
  feedbackReceived?: boolean
}

interface Stats {
  totalCourses: number
  completedSessions: number
  averageProgress: number
  upcomingInterviews: number
  completedInterviews: number
  totalInterviews: number
}

export default function LearnerDashboardPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()
  const [selectedTab, setSelectedTab] = useState<string>('overview')
  const [enrolledCourses, setEnrolledCourses] = useState<EnrolledCourse[]>([])
  const [mockInterviews, setMockInterviews] = useState<MockInterview[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [hasCheckedAuth, setHasCheckedAuth] = useState(false)

  // Auth check
  useEffect(() => {
    if (authLoading) return
    
    if (!hasCheckedAuth) {
      setHasCheckedAuth(true)
      
      if (!user) {
        router.push('/login?from=/dashboard/learner')
        return
      }

      if (user.role !== 'LEARNER') {
        router.push('/dashboard/instructor')
        return
      }
    }
  }, [authLoading, user, hasCheckedAuth, router])

  // Fetch data
  useEffect(() => {
    if (!user || authLoading || user.role !== 'LEARNER') return
    fetchData()
  }, [user, authLoading])

  const fetchData = async () => {
    try {
      setIsLoading(true)
      
      // Fetch enrolled courses
      const coursesData = await ApiService.getMyEnrollments()
      console.log('📚 Courses data:', coursesData)
      
      // Transform the data to match our interface
      const transformedCourses: EnrolledCourse[] = coursesData.map((course: any) => ({
        enrollmentId: course.enrollmentId || course.id,
        courseId: course.courseId,
        courseTitle: course.courseTitle,
        categoryName: course.categoryName,
        instructorName: course.instructorName,
        level: course.level,
        enrolledAt: course.enrolledAt,
        progressPercentage: course.progressPercentage || 0,
        completedSessions: course.completedSessions || 0,
        totalSessions: course.totalSessions || 0,
        nextSessionWeek: course.nextSessionWeek,
        nextSessionNumber: course.nextSessionNumber,
        nextSessionTitle: course.nextSessionTitle,
        nextSessionType: course.nextSessionType,
        totalWeeks: course.totalWeeks || 8,
        currentWeek: course.currentWeek || Math.ceil((course.completedSessions || 0) / 4)
      }))
      
      setEnrolledCourses(transformedCourses)
      
      // Fetch mock interviews
      const interviewsData = await ApiService.getMyMockInterviewBookings()
      console.log('🎤 Interviews data:', interviewsData)
      
      const transformedInterviews: MockInterview[] = interviewsData.map((interview: any) => ({
        bookingId: interview.bookingId || interview.id,
        interviewTypeId: interview.interviewTypeId,
        interviewTypeName: interview.interviewTypeName,
        scheduledDateTime: interview.scheduledDateTime,
        status: interview.status,
        programmingLanguage: interview.programmingLanguage,
        amount: interview.amount,
        feedbackReceived: interview.feedbackReceived || false
      }))
      
      setMockInterviews(transformedInterviews)
      
    } catch (error) {
      console.error('❌ Failed to fetch data:', error)
      setEnrolledCourses([])
      setMockInterviews([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleCourseClick = (enrollmentId: number) => {
    router.push(`/dashboard/learner/${enrollmentId}`)
  }

  const calculateStats = (): Stats => {
    const totalCourses = enrolledCourses.length
    const completedSessions = enrolledCourses.reduce((sum, c) => sum + (c.completedSessions || 0), 0)
    const averageProgress = totalCourses > 0 
      ? Math.round(enrolledCourses.reduce((sum, c) => sum + (c.progressPercentage || 0), 0) / totalCourses)
      : 0
    const upcomingInterviews = mockInterviews.filter(i => i.status === 'SCHEDULED').length
    const completedInterviews = mockInterviews.filter(i => i.status === 'COMPLETED').length

    return {
      totalCourses,
      completedSessions,
      averageProgress,
      upcomingInterviews,
      completedInterviews,
      totalInterviews: mockInterviews.length
    }
  }

  if (authLoading || !hasCheckedAuth || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-green-600" />
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!user || user.role !== 'LEARNER') return null

  const stats = calculateStats()

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Hero Stats */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {user.name}! 🎉</h1>
        <p className="text-green-100 text-lg mb-6">Continue your learning journey with Sophiray</p>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold">{stats.totalCourses}</div>
            <div className="text-green-100 text-sm">Active Courses</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold">{stats.completedSessions}</div>
            <div className="text-green-100 text-sm">Sessions Done</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold">{stats.averageProgress}%</div>
            <div className="text-green-100 text-sm">Avg Progress</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold">{stats.upcomingInterviews}</div>
            <div className="text-green-100 text-sm">Upcoming Interviews</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-4">
        <button 
          onClick={() => setSelectedTab('courses')}
          className="bg-white rounded-lg p-6 text-left hover:shadow-lg transition-all border-2 border-transparent hover:border-green-500"
        >
          <BookOpen className="w-10 h-10 text-green-600 mb-3" />
          <h3 className="font-semibold text-lg mb-1">My Courses</h3>
          <p className="text-gray-600 text-sm mb-3">{stats.totalCourses} active courses</p>
          <div className="flex items-center text-green-600 text-sm font-medium">
            View Progress <ChevronRight className="w-4 h-4 ml-1" />
          </div>
        </button>

        <button 
          onClick={() => setSelectedTab('interviews')}
          className="bg-white rounded-lg p-6 text-left hover:shadow-lg transition-all border-2 border-transparent hover:border-blue-500"
        >
          <Video className="w-10 h-10 text-blue-600 mb-3" />
          <h3 className="font-semibold text-lg mb-1">Mock Interviews</h3>
          <p className="text-gray-600 text-sm mb-3">{stats.upcomingInterviews} upcoming</p>
          <div className="flex items-center text-blue-600 text-sm font-medium">
            View Interviews <ChevronRight className="w-4 h-4 ml-1" />
          </div>
        </button>
      </div>

      {/* Contact Support */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h2 className="text-xl font-semibold text-blue-900 mb-4 flex items-center">
          <MessageCircle className="w-6 h-6 mr-2" />
          Need Help? Contact Support
        </h2>
        <div className="flex flex-wrap gap-3">
          <a href="tel:+919502666078" className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            <Phone className="w-4 h-4 mr-2" />
            +91 95026 66078
          </a>
          <a href="https://wa.me/919502666078" target="_blank" rel="noopener noreferrer" className="flex items-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
            <MessageCircle className="w-4 h-4 mr-2" />
            WhatsApp
          </a>
          <a href="mailto:support@sophiray.com" className="flex items-center bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
            <Mail className="w-4 h-4 mr-2" />
            Email
          </a>
        </div>
      </div>
    </div>
  )

  const renderCourses = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">My Courses</h2>
        <div className="text-sm text-gray-600">
          {stats.completedSessions} sessions completed
        </div>
      </div>

      {enrolledCourses.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg">
          <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Courses Yet</h3>
          <p className="text-gray-600 mb-4">Start learning by enrolling in a course</p>
          <Button 
            onClick={() => router.push('/courses')}
            className="bg-green-600 hover:bg-green-700"
          >
            Browse Courses
          </Button>
        </div>
      ) : (
        enrolledCourses.map((course) => (
          <div 
            key={course.enrollmentId} 
            className="bg-white rounded-xl shadow-lg border-2 border-gray-200 overflow-hidden hover:border-green-500 transition-all cursor-pointer"
            onClick={() => handleCourseClick(course.enrollmentId)}
          >
            {/* Course Header */}
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 border-b">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{course.courseTitle}</h3>
                  <p className="text-gray-600 mb-3">{course.categoryName}</p>
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      course.level === 'Advanced' ? 'bg-red-100 text-red-800' :
                      course.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {course.level}
                    </span>
                    <span className="text-sm text-gray-600">
                      Enrolled {new Date(course.enrolledAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold text-green-600">{course.progressPercentage}%</div>
                  <div className="text-sm text-gray-600">Complete</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Overall Progress</span>
                  <span className="text-sm text-gray-600">
                    {course.completedSessions} / {course.totalSessions} sessions
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-green-600 h-3 rounded-full transition-all"
                    style={{ width: `${course.progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Next Session */}
              {course.nextSessionTitle && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center flex-1">
                      <Play className="w-5 h-5 text-blue-600 mr-2 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-gray-900">Next Up</div>
                        <div className="text-sm text-gray-600">
                          Week {course.nextSessionWeek}, Session {course.nextSessionNumber}: {course.nextSessionTitle}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-blue-600 ml-2 flex-shrink-0" />
                  </div>
                </div>
              )}
            </div>

            {/* Learning Roadmap */}
            <div className="p-6">
              <h4 className="font-semibold text-lg mb-4 flex items-center">
                <MapPin className="w-5 h-5 mr-2 text-green-600" />
                Learning Roadmap - {course.totalWeeks} Weeks
              </h4>
              
              <div className="space-y-3">
                {[...Array(course.totalWeeks)].map((_, weekIndex) => {
                  const weekNum = weekIndex + 1
                  const isCurrentWeek = weekNum === course.currentWeek
                  const isPastWeek = weekNum < course.currentWeek
                  
                  return (
                    <div 
                      key={weekNum}
                      className={`flex items-center p-3 rounded-lg border-2 transition-all ${
                        isCurrentWeek ? 'bg-green-50 border-green-500' :
                        isPastWeek ? 'bg-gray-50 border-gray-300' :
                        'bg-white border-gray-200'
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0 ${
                        isCurrentWeek ? 'bg-green-600 text-white' :
                        isPastWeek ? 'bg-green-100 text-green-800' :
                        'bg-gray-200 text-gray-600'
                      }`}>
                        {isPastWeek ? <CheckCircle className="w-6 h-6" /> : weekNum}
                      </div>
                      
                      <div className="flex-1">
                        <div className="font-medium text-gray-900">Week {weekNum}</div>
                        <div className="text-sm text-gray-600">
                          {isPastWeek ? 'Completed' : isCurrentWeek ? 'In Progress' : 'Upcoming'}
                        </div>
                      </div>

                      {isCurrentWeek && (
                        <div className="flex items-center">
                          <Zap className="w-5 h-5 text-green-600 mr-1" />
                          <span className="text-sm font-medium text-green-600">Active</span>
                        </div>
                      )}

                      {isPastWeek && (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      )}
                    </div>
                  )
                })}
              </div>

              <Button 
                onClick={(e) => {
                  e.stopPropagation()
                  handleCourseClick(course.enrollmentId)
                }}
                className="w-full mt-6 bg-gradient-to-r from-green-600 to-green-700 hover:shadow-lg"
              >
                View Detailed Progress & Sessions
              </Button>
            </div>
          </div>
        ))
      )}
    </div>
  )

  const renderInterviews = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Mock Interviews</h2>
        <Button 
          onClick={() => router.push('/mock-interviews')}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Book New Interview
        </Button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-6 border-2 border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-8 h-8 text-blue-600" />
            <div className="text-3xl font-bold">{stats.upcomingInterviews}</div>
          </div>
          <div className="text-gray-600">Upcoming</div>
        </div>
        <div className="bg-white rounded-lg p-6 border-2 border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <div className="text-3xl font-bold">{stats.completedInterviews}</div>
          </div>
          <div className="text-gray-600">Completed</div>
        </div>
        <div className="bg-white rounded-lg p-6 border-2 border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <Award className="w-8 h-8 text-purple-600" />
            <div className="text-3xl font-bold">{stats.totalInterviews}</div>
          </div>
          <div className="text-gray-600">Total</div>
        </div>
      </div>

      {/* Interview List */}
      {mockInterviews.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg">
          <Video className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Interviews Yet</h3>
          <p className="text-gray-600 mb-4">Practice with mock interviews</p>
          <Button 
            onClick={() => router.push('/mock-interviews')}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Book Interview
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {mockInterviews.map((interview) => (
            <div 
              key={interview.bookingId} 
              className={`bg-white rounded-lg p-6 border-2 ${
                interview.status === 'SCHEDULED' ? 'border-blue-500' : 'border-gray-200'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <h3 className="text-xl font-bold text-gray-900">{interview.interviewTypeName}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      interview.status === 'SCHEDULED' ? 'bg-blue-100 text-blue-800' :
                      interview.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {interview.status}
                    </span>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      {new Date(interview.scheduledDateTime).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-2" />
                      {new Date(interview.scheduledDateTime).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                    {interview.programmingLanguage && (
                      <div className="flex items-center">
                        <Code className="w-4 h-4 mr-2" />
                        Language: {interview.programmingLanguage}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {interview.status === 'COMPLETED' && interview.feedbackReceived && (
                <div className="mt-4 pt-4 border-t bg-green-50 text-green-700 py-2 rounded-lg text-center font-medium">
                  ✓ Feedback Available
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Head>
        <title>Learner Dashboard | Personalized 1-on-1 Learning | Sophiray</title>
        <meta
          name="description"
          content="Track your courses, sessions, and mock interviews. Continue your personalized one-on-one learning journey on Sophiray."
        />
        <meta name="keywords" content="learner dashboard, sophiray, one on one tutorial, 1-on-1 learning" />
        <meta name="robots" content="noindex, follow" />
      </Head>
      <Navigation />
      
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          {/* Navigation Tabs */}
          <div className="bg-white rounded-lg shadow-sm mb-6 p-2">
            <div className="flex gap-2">
              {[
                { key: 'overview', label: 'Overview', icon: BarChart3 },
                { key: 'courses', label: 'Courses', icon: BookOpen },
                { key: 'interviews', label: 'Interviews', icon: Video }
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setSelectedTab(tab.key)}
                  className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                    selectedTab === tab.key
                      ? 'bg-green-600 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <tab.icon className="w-5 h-5 inline mr-2" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          {selectedTab === 'overview' && renderOverview()}
          {selectedTab === 'courses' && renderCourses()}
          {selectedTab === 'interviews' && renderInterviews()}
        </div>
      </main>
      
      <Footer />
    </div>
  )
}