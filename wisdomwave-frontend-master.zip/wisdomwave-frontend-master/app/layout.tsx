import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { AuthProvider } from '@/components/providers/AuthProvider'
import { ThemeProvider } from '@/components/providers/ThemeProvider'
import { getAllCategories } from '@/lib/courseData'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Sophiray - Premium 1-on-1 Online Learning Platform | Master Tech Skills',
  description: 'Transform your career with Sophiray\'s personalized 1-on-1 online tutoring. Expert instructors teach Full Stack Development, Data Science, AI, Machine Learning, Digital Marketing, Cybersecurity, Mobile Development, UI/UX Design. Interview preparation, coding bootcamp, and job placement assistance with industry-recognized certificates.',
  keywords: '1-on-1 online tutoring, personal tutor online, private coding instructor, one on one programming lessons, personalized learning platform, individual tutoring online, custom learning path, dedicated coding mentor, private software development tutor, full stack development course, web development bootcamp, react js tutorial, node js training, python programming course, data science certification, machine learning course, artificial intelligence training, AI development, deep learning, data analytics course, SQL training, big data course, digital marketing mastery, SEO optimization course, social media marketing, content marketing training, email marketing course, PPC advertising, google ads certification, cybersecurity training, ethical hacking course, penetration testing, network security, cloud security, mobile app development, react native course, flutter development, iOS development, android development, kotlin programming, UI UX design course, user interface design, user experience training, figma tutorial, wireframing course, prototype design, javascript course, typescript training, java programming, C++ tutorial, python for beginners, django framework, flask python, spring boot course, angular training, vue js course, next js tutorial, tailwind css, bootstrap course, mongodb training, postgresql course, mysql database, redis cache, docker course, kubernetes training, DevOps certification, CI CD pipeline, AWS certification, azure training, google cloud platform, git version control, agile methodology, scrum master certification, interview preparation, coding interview, system design interview, behavioral interview, technical interview prep, mock interview practice, DSA course, data structures algorithms, leetcode preparation, competitive programming, software engineer interview, frontend developer interview, backend developer interview, full stack interview, FAANG interview prep, job placement assistance, career counseling, resume building, portfolio development, live coding sessions, hands-on projects, real world projects, capstone project, industry mentorship, expert guidance, personalized feedback, flexible scheduling, online certification, recognized certificate, professional development, skill enhancement, career transformation, upskilling, reskilling, tech bootcamp, coding academy, software training institute, IT courses online, computer science degree alternative, self paced learning, interactive learning, video tutorials, screen sharing sessions, code review, debugging help, project assistance, homework help, assignment support, exam preparation, placement training, corporate training, team training, technology education, learn programming online, best online courses, top rated instructors, affordable pricing, EMI options, money back guarantee, free trial class, demo session',
  authors: [{ name: 'Sophiray by Charvitos Technologies' }],
  creator: 'Charvitos Technologies',
  publisher: 'Sophiray',
  robots: 'index, follow',
  metadataBase: new URL('https://sophiray.com'),
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://sophiray.com/',
    siteName: 'Sophiray',
    title: 'Sophiray - Premium 1-on-1 Online Learning Platform | Master Tech & Business Skills',
    description: 'Master in-demand tech skills with personalized 1-on-1 instruction from industry experts. Full Stack Development, Data Science, AI/ML, Digital Marketing, Cybersecurity, Mobile Development, and UI/UX Design. Interview preparation and job placement support with 95% success rate.',
    images: [
      {
        url: '/images/sophiray-social-banner.jpg',
        width: 1200,
        height: 630,
        alt: 'Sophiray - Premium 1-on-1 Online Learning Platform',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Sophiray - Personalized 1-on-1 Online Learning Platform',
    description: 'Master tech skills with expert 1-on-1 instruction. Full stack development, data science, AI/ML, digital marketing, cybersecurity courses with certificates. Interview prep & job placement assistance.',
    images: ['/images/sophiray-twitter-banner.jpg'],
    creator: '@SophirayEdu',
  },
  verification: {
    google: 'your-google-verification-code',
  },
  category: 'education',
  alternates: {
    canonical: 'https://sophiray.com',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Generate global keywords from courseData (titles + skills with 1-on-1 variants)
  const categories = getAllCategories()
  const base = Array.from(new Set([
    ...categories.flatMap(cat => cat.courses.map(c => c.title.toLowerCase())),
    ...categories.flatMap(cat => cat.courses.flatMap(c => (c.skills || []).map(s => s.toLowerCase())))
  ]))
  const variants = ['one on one tutorial', '1-on-1 mentoring', 'personalized coaching', 'live online training', 'certificate course']
  const globalKeywords = Array.from(new Set([
    ...base.slice(0, 120),
    ...base.slice(0, 80).flatMap(k => variants.map(v => `${k} ${v}`))
  ])).join(', ')

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#16a34a" />
        <meta name="msapplication-TileColor" content="#16a34a" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-title" content="Sophiray" />
        <meta name="application-name" content="Sophiray" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="keywords" content={globalKeywords} />
        
        {/* Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "EducationalOrganization",
              "name": "Sophiray",
              "alternateName": "Sophiray Online Learning Platform by Charvitos",
              "url": "https://sophiray.com",
              "logo": "https://sophiray.com/logo.png",
              "description": "Premier 1-on-1 online learning platform offering personalized instruction, expert-led tech courses, interview preparation, and industry-recognized certificates in Full Stack Development, Data Science, AI/ML, Digital Marketing, Cybersecurity, Mobile Development, and UI/UX Design.",
              "founder": {
                "@type": "Organization",
                "name": "Charvitos Technologies"
              },
              "foundingDate": "2024",
              "address": {
                "@type": "PostalAddress",
                "addressLocality": "Hyderabad",
                "addressRegion": "Telangana",
                "addressCountry": "IN"
              },
              "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+91-95026-66078",
                "contactType": "customer service",
                "email": "support@charvitos.com",
                "availableLanguage": ["English", "Hindi"]
              },
              "sameAs": [
                "https://twitter.com/SophirayEdu",
                "https://linkedin.com/company/sophiray",
                "https://facebook.com/Sophiray"
              ],
              "offers": {
                "@type": "AggregateOffer",
                "priceCurrency": "INR",
                "lowPrice": "9999",
                "highPrice": "49999",
                "offerCount": "100+"
              },
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "reviewCount": "5000",
                "bestRating": "5",
                "worstRating": "1"
              },
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Tech Courses Catalog",
                "itemListElement": [
                  {
                    "@type": "Course",
                    "name": "Full Stack Web Development",
                    "description": "Master frontend and backend development with React, Node.js, and databases",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  },
                  {
                    "@type": "Course",
                    "name": "Data Science & AI",
                    "description": "Learn Python, machine learning, deep learning, and AI development",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  },
                  {
                    "@type": "Course",
                    "name": "Digital Marketing Mastery",
                    "description": "Complete digital marketing training including SEO, social media, and PPC",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  },
                  {
                    "@type": "Course",
                    "name": "Cybersecurity",
                    "description": "Ethical hacking, penetration testing, and network security training",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  },
                  {
                    "@type": "Course",
                    "name": "Mobile App Development",
                    "description": "Build iOS and Android apps with React Native and Flutter",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  },
                  {
                    "@type": "Course",
                    "name": "UI/UX Design",
                    "description": "User interface and user experience design with Figma",
                    "provider": {
                      "@type": "Organization",
                      "name": "Sophiray"
                    }
                  }
                ]
              }
            })
          }}
        />

        {/* Additional Structured Data for Course Provider */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "Sophiray - 1-on-1 Online Tutoring",
              "image": "https://sophiray.com/logo.png",
              "description": "Premium 1-on-1 online tutoring platform for technology and business courses with personalized instruction and interview preparation.",
              "priceRange": "₹₹₹",
              "address": {
                "@type": "PostalAddress",
                "addressLocality": "Hyderabad",
                "addressRegion": "Telangana",
                "addressCountry": "IN"
              },
              "telephone": "+91-95026-66078",
              "email": "support@charvitos.com",
              "url": "https://sophiray.com",
              "paymentAccepted": "Cash, Credit Card, Debit Card, UPI, Net Banking",
              "openingHours": "Mo-Su 00:00-23:59",
              "areaServed": {
                "@type": "Country",
                "name": "India"
              },
              "availableLanguage": ["English", "Hindi"]
            })
          }}
        />

        {/* FAQ Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "What is 1-on-1 online tutoring at Sophiray?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sophiray offers personalized 1-on-1 online tutoring where each student gets dedicated attention from expert instructors. Sessions are customized to your learning pace, goals, and skill level in areas like Full Stack Development, Data Science, Digital Marketing, and more."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Do you provide interview preparation?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes! Sophiray offers comprehensive interview preparation including mock interviews, coding challenges, system design, behavioral questions, and resume building for roles like Software Engineer, Data Scientist, and Product Manager."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Are the certificates industry-recognized?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, Sophiray provides industry-recognized certificates upon course completion that can be added to your LinkedIn profile and resume to showcase your skills to employers."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What courses are available?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sophiray offers courses in Full Stack Web Development, Data Science & AI, Digital Marketing, Cybersecurity, Mobile App Development, UI/UX Design, and specialized interview preparation programs."
                  }
                }
              ]
            })
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}