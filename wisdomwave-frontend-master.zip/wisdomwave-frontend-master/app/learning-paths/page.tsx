// app/learning-paths/page.tsx - Interactive Career Learning Paths
'use client'

import React, { useState } from 'react'
import Head from 'next/head'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { 
  Map, 
  Target, 
  Clock, 
  Users, 
  Star, 
  CheckCircle, 
  ArrowRight,
  Code2, 
  Brain, 
  Shield, 
  Cloud, 
  Palette,
  BarChart3,
  Smartphone,
  Globe,
  Briefcase,
  Trophy,
  PlayCircle,
  BookOpen,
  Award,
  TrendingUp,
  Calendar,
  MapPin,
  Route,
  Navigation as NavigationIcon,
  Flag,
  Zap,
  Rocket,
  ChevronRight,
  Timer,
  DollarSign
} from 'lucide-react'

// Career path data structure
interface Milestone {
  id: string
  title: string
  duration: string
  courses: string[]
  skills: string[]
  projects: string[]
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert'
  salary: string
  jobTitles: string[]
}

interface CareerPath {
  id: string
  title: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  color: string
  gradient: string
  totalDuration: string
  averageSalary: string
  demandLevel: 'High' | 'Very High' | 'Extreme'
  students: string
  successRate: string
  milestones: Milestone[]
}

const careerPaths: CareerPath[] = [
  {
    id: 'full-stack',
    title: 'Full-Stack Developer',
    icon: Globe,
    description: 'Master both frontend and backend development to build complete web applications from scratch.',
    color: 'blue',
    gradient: 'from-blue-500 to-blue-700',
    totalDuration: '8-12 months',
    averageSalary: '₹8-25 LPA',
    demandLevel: 'Very High',
    students: '12.5K+',
    successRate: '94%',
    milestones: [
      {
        id: 'fs1',
        title: 'Frontend Foundations',
        duration: '2-3 months',
        courses: ['HTML/CSS Mastery', 'JavaScript Fundamentals', 'React.js'],
        skills: ['HTML5', 'CSS3', 'JavaScript ES6+', 'React', 'Responsive Design'],
        projects: ['Portfolio Website', 'Weather App', 'Todo Application'],
        difficulty: 'Beginner',
        salary: '₹3-6 LPA',
        jobTitles: ['Frontend Developer', 'UI Developer', 'Junior Web Developer']
      },
      {
        id: 'fs2',
        title: 'Backend Mastery',
        duration: '2-3 months',
        courses: ['Node.js', 'Express.js', 'Database Design', 'API Development'],
        skills: ['Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'REST APIs'],
        projects: ['Blog API', 'E-commerce Backend', 'Authentication System'],
        difficulty: 'Intermediate',
        salary: '₹5-12 LPA',
        jobTitles: ['Backend Developer', 'API Developer', 'Server-side Developer']
      },
      {
        id: 'fs3',
        title: 'Full-Stack Integration',
        duration: '2-3 months',
        courses: ['System Design', 'DevOps Basics', 'Testing', 'Deployment'],
        skills: ['System Architecture', 'Docker', 'AWS', 'Testing', 'CI/CD'],
        projects: ['Full-Stack Social Media App', 'Real-time Chat App'],
        difficulty: 'Advanced',
        salary: '₹8-18 LPA',
        jobTitles: ['Full-Stack Developer', 'Web Application Developer']
      },
      {
        id: 'fs4',
        title: 'Senior Developer',
        duration: '2-3 months',
        courses: ['Advanced Architecture', 'Team Leadership', 'Performance Optimization'],
        skills: ['Microservices', 'Leadership', 'Code Review', 'Mentoring'],
        projects: ['Scalable Enterprise Application', 'Open Source Contribution'],
        difficulty: 'Expert',
        salary: '₹15-25 LPA',
        jobTitles: ['Senior Full-Stack Developer', 'Tech Lead', 'Solution Architect']
      }
    ]
  },
  {
    id: 'ai-ml',
    title: 'AI/ML Engineer',
    icon: Brain,
    description: 'Build intelligent systems using machine learning, deep learning, and artificial intelligence.',
    color: 'purple',
    gradient: 'from-purple-500 to-purple-700',
    totalDuration: '10-14 months',
    averageSalary: '₹12-35 LPA',
    demandLevel: 'Extreme',
    students: '8.9K+',
    successRate: '91%',
    milestones: [
      {
        id: 'ai1',
        title: 'Python & Data Foundations',
        duration: '3-4 months',
        courses: ['Python Programming', 'Statistics', 'Data Analysis', 'Pandas/NumPy'],
        skills: ['Python', 'Statistics', 'Data Analysis', 'Pandas', 'NumPy', 'Matplotlib'],
        projects: ['Data Analysis Dashboard', 'Sales Prediction Model'],
        difficulty: 'Beginner',
        salary: '₹4-8 LPA',
        jobTitles: ['Data Analyst', 'Junior Data Scientist', 'Python Developer']
      },
      {
        id: 'ai2',
        title: 'Machine Learning',
        duration: '3-4 months',
        courses: ['ML Algorithms', 'Scikit-learn', 'Model Evaluation', 'Feature Engineering'],
        skills: ['Supervised Learning', 'Unsupervised Learning', 'Scikit-learn', 'Model Selection'],
        projects: ['Recommendation System', 'Fraud Detection Model'],
        difficulty: 'Intermediate',
        salary: '₹8-18 LPA',
        jobTitles: ['ML Engineer', 'Data Scientist', 'ML Developer']
      },
      {
        id: 'ai3',
        title: 'Deep Learning & AI',
        duration: '2-3 months',
        courses: ['Neural Networks', 'TensorFlow', 'PyTorch', 'Computer Vision', 'NLP'],
        skills: ['Deep Learning', 'TensorFlow', 'PyTorch', 'Computer Vision', 'NLP'],
        projects: ['Image Classification App', 'Chatbot', 'Sentiment Analysis'],
        difficulty: 'Advanced',
        salary: '₹12-25 LPA',
        jobTitles: ['Deep Learning Engineer', 'AI Engineer', 'Computer Vision Engineer']
      },
      {
        id: 'ai4',
        title: 'AI Specialist',
        duration: '2-3 months',
        courses: ['MLOps', 'Model Deployment', 'AI Ethics', 'Research Methods'],
        skills: ['MLOps', 'Model Deployment', 'Research', 'Team Leadership'],
        projects: ['Production AI System', 'Research Paper'],
        difficulty: 'Expert',
        salary: '₹20-35 LPA',
        jobTitles: ['Senior AI Engineer', 'AI Research Scientist', 'ML Architect']
      }
    ]
  },
  {
    id: 'cybersecurity',
    title: 'Cybersecurity Specialist',
    icon: Shield,
    description: 'Protect systems and data from cyber threats with advanced security techniques and tools.',
    color: 'red',
    gradient: 'from-red-500 to-red-700',
    totalDuration: '8-10 months',
    averageSalary: '₹10-30 LPA',
    demandLevel: 'Very High',
    students: '4.2K+',
    successRate: '89%',
    milestones: [
      {
        id: 'cs1',
        title: 'Security Fundamentals',
        duration: '2-3 months',
        courses: ['Network Security', 'Linux Administration', 'Security Principles'],
        skills: ['Network Security', 'Linux', 'Security Protocols', 'Risk Assessment'],
        projects: ['Network Security Audit', 'Security Policy Document'],
        difficulty: 'Beginner',
        salary: '₹5-10 LPA',
        jobTitles: ['Junior Security Analyst', 'IT Security Specialist']
      },
      {
        id: 'cs2',
        title: 'Ethical Hacking',
        duration: '2-3 months',
        courses: ['Penetration Testing', 'Vulnerability Assessment', 'Kali Linux'],
        skills: ['Penetration Testing', 'Vulnerability Scanning', 'Kali Linux', 'Metasploit'],
        projects: ['Penetration Test Report', 'Vulnerability Scanner'],
        difficulty: 'Intermediate',
        salary: '₹8-18 LPA',
        jobTitles: ['Ethical Hacker', 'Penetration Tester', 'Security Consultant']
      },
      {
        id: 'cs3',
        title: 'Advanced Security',
        duration: '2-2 months',
        courses: ['Incident Response', 'Forensics', 'Malware Analysis'],
        skills: ['Incident Response', 'Digital Forensics', 'Malware Analysis', 'SIEM'],
        projects: ['Incident Response Plan', 'Malware Analysis Report'],
        difficulty: 'Advanced',
        salary: '₹12-25 LPA',
        jobTitles: ['Security Engineer', 'Incident Response Specialist', 'Forensic Analyst']
      },
      {
        id: 'cs4',
        title: 'Security Leadership',
        duration: '2 months',
        courses: ['Security Architecture', 'Compliance', 'Team Management'],
        skills: ['Security Architecture', 'Compliance', 'Leadership', 'Strategy'],
        projects: ['Enterprise Security Strategy', 'Compliance Framework'],
        difficulty: 'Expert',
        salary: '₹20-30 LPA',
        jobTitles: ['Security Architect', 'CISO', 'Security Manager']
      }
    ]
  },
  {
    id: 'devops',
    title: 'DevOps Engineer',
    icon: Cloud,
    description: 'Bridge development and operations with automation, cloud platforms, and continuous delivery.',
    color: 'cyan',
    gradient: 'from-cyan-500 to-cyan-700',
    totalDuration: '6-8 months',
    averageSalary: '₹9-28 LPA',
    demandLevel: 'Very High',
    students: '6.7K+',
    successRate: '92%',
    milestones: [
      {
        id: 'do1',
        title: 'Infrastructure Basics',
        duration: '2 months',
        courses: ['Linux Administration', 'Networking', 'Shell Scripting'],
        skills: ['Linux', 'Bash Scripting', 'Networking', 'System Administration'],
        projects: ['Server Setup Automation', 'Monitoring Scripts'],
        difficulty: 'Beginner',
        salary: '₹4-8 LPA',
        jobTitles: ['System Administrator', 'Junior DevOps Engineer']
      },
      {
        id: 'do2',
        title: 'Cloud & Containers',
        duration: '2 months',
        courses: ['AWS/Azure', 'Docker', 'Kubernetes', 'Infrastructure as Code'],
        skills: ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'Ansible'],
        projects: ['Containerized Application', 'Cloud Infrastructure'],
        difficulty: 'Intermediate',
        salary: '₹7-15 LPA',
        jobTitles: ['Cloud Engineer', 'Container Specialist', 'DevOps Engineer']
      },
      {
        id: 'do3',
        title: 'CI/CD & Automation',
        duration: '1-2 months',
        courses: ['Jenkins', 'GitLab CI', 'Monitoring', 'Security'],
        skills: ['Jenkins', 'GitLab CI', 'Prometheus', 'Grafana', 'Security'],
        projects: ['Complete CI/CD Pipeline', 'Monitoring Dashboard'],
        difficulty: 'Advanced',
        salary: '₹12-22 LPA',
        jobTitles: ['Senior DevOps Engineer', 'Site Reliability Engineer']
      },
      {
        id: 'do4',
        title: 'DevOps Leadership',
        duration: '1-2 months',
        courses: ['Architecture Design', 'Team Leadership', 'Strategy'],
        skills: ['Architecture', 'Leadership', 'Strategy', 'Mentoring'],
        projects: ['Enterprise DevOps Strategy', 'Team Training Program'],
        difficulty: 'Expert',
        salary: '₹18-28 LPA',
        jobTitles: ['DevOps Architect', 'Principal Engineer', 'Engineering Manager']
      }
    ]
  },
  {
    id: 'data-science',
    title: 'Data Scientist',
    icon: BarChart3,
    description: 'Extract insights from data using statistical analysis, machine learning, and visualization.',
    color: 'green',
    gradient: 'from-green-500 to-green-700',
    totalDuration: '9-12 months',
    averageSalary: '₹8-25 LPA',
    demandLevel: 'High',
    students: '9.3K+',
    successRate: '88%',
    milestones: [
      {
        id: 'ds1',
        title: 'Data Foundations',
        duration: '3 months',
        courses: ['Python/R', 'Statistics', 'SQL', 'Data Visualization'],
        skills: ['Python', 'Statistics', 'SQL', 'Pandas', 'Matplotlib', 'Seaborn'],
        projects: ['Sales Analysis Dashboard', 'Customer Segmentation'],
        difficulty: 'Beginner',
        salary: '₹4-8 LPA',
        jobTitles: ['Data Analyst', 'Business Analyst', 'Junior Data Scientist']
      },
      {
        id: 'ds2',
        title: 'Advanced Analytics',
        duration: '3 months',
        courses: ['Machine Learning', 'Advanced Statistics', 'A/B Testing'],
        skills: ['Machine Learning', 'Hypothesis Testing', 'A/B Testing', 'Scikit-learn'],
        projects: ['Predictive Model', 'A/B Test Analysis'],
        difficulty: 'Intermediate',
        salary: '₹6-15 LPA',
        jobTitles: ['Data Scientist', 'Analytics Engineer', 'ML Engineer']
      },
      {
        id: 'ds3',
        title: 'Specialized Skills',
        duration: '2-3 months',
        courses: ['Deep Learning', 'Big Data', 'Cloud Platforms'],
        skills: ['Deep Learning', 'Spark', 'Hadoop', 'AWS/GCP', 'TensorFlow'],
        projects: ['Big Data Pipeline', 'Deep Learning Model'],
        difficulty: 'Advanced',
        salary: '₹10-20 LPA',
        jobTitles: ['Senior Data Scientist', 'ML Engineer', 'Data Engineer']
      },
      {
        id: 'ds4',
        title: 'Data Science Leadership',
        duration: '1-3 months',
        courses: ['Team Leadership', 'Business Strategy', 'Project Management'],
        skills: ['Leadership', 'Strategy', 'Project Management', 'Communication'],
        projects: ['Data Strategy Framework', 'Team Development Program'],
        difficulty: 'Expert',
        salary: '₹15-25 LPA',
        jobTitles: ['Lead Data Scientist', 'Data Science Manager', 'Chief Data Officer']
      }
    ]
  },
  {
    id: 'mobile-dev',
    title: 'Mobile App Developer',
    icon: Smartphone,
    description: 'Create native and cross-platform mobile applications for iOS and Android platforms.',
    color: 'indigo',
    gradient: 'from-indigo-500 to-indigo-700',
    totalDuration: '7-9 months',
    averageSalary: '₹6-20 LPA',
    demandLevel: 'High',
    students: '7.1K+',
    successRate: '90%',
    milestones: [
      {
        id: 'md1',
        title: 'Mobile Fundamentals',
        duration: '2 months',
        courses: ['Mobile UI/UX', 'React Native Basics', 'Flutter Basics'],
        skills: ['Mobile UI/UX', 'React Native', 'Flutter', 'Mobile Design Patterns'],
        projects: ['Simple Mobile App', 'UI Component Library'],
        difficulty: 'Beginner',
        salary: '₹3-7 LPA',
        jobTitles: ['Junior Mobile Developer', 'UI/UX Designer']
      },
      {
        id: 'md2',
        title: 'Cross-Platform Development',
        duration: '2-3 months',
        courses: ['Advanced React Native', 'Advanced Flutter', 'State Management'],
        skills: ['Advanced React Native', 'Advanced Flutter', 'Redux', 'Provider'],
        projects: ['Cross-Platform App', 'E-commerce Mobile App'],
        difficulty: 'Intermediate',
        salary: '₹5-12 LPA',
        jobTitles: ['Mobile App Developer', 'React Native Developer', 'Flutter Developer']
      },
      {
        id: 'md3',
        title: 'Native Development',
        duration: '2-3 months',
        courses: ['iOS Development', 'Android Development', 'App Store Optimization'],
        skills: ['Swift', 'Kotlin', 'iOS SDK', 'Android SDK', 'App Store Optimization'],
        projects: ['Native iOS App', 'Native Android App'],
        difficulty: 'Advanced',
        salary: '₹8-16 LPA',
        jobTitles: ['iOS Developer', 'Android Developer', 'Senior Mobile Developer']
      },
      {
        id: 'md4',
        title: 'Mobile Architecture',
        duration: '1-2 months',
        courses: ['Mobile Architecture', 'Performance Optimization', 'Team Leadership'],
        skills: ['Mobile Architecture', 'Performance Optimization', 'Leadership'],
        projects: ['Scalable Mobile Architecture', 'Performance Optimization Guide'],
        difficulty: 'Expert',
        salary: '₹12-20 LPA',
        jobTitles: ['Mobile Architect', 'Senior Mobile Engineer', 'Mobile Team Lead']
      }
    ]
  }
]

export default function LearningPathsPage() {
  const [selectedCareer, setSelectedCareer] = useState<string>('full-stack')
  const [selectedMilestone, setSelectedMilestone] = useState<string | null>(null)

  const currentPath = careerPaths.find(path => path.id === selectedCareer)

  const allKeywords = Array.from(new Set(
    careerPaths.flatMap(path => [
      path.title.toLowerCase(),
      ...path.milestones.flatMap(m => [
        ...m.courses.map(c => c.toLowerCase()),
        ...m.skills.map(s => s.toLowerCase())
      ])
    ])
  ))

  const seoKeywords = [
    ...allKeywords,
    ...allKeywords.slice(0, 60).flatMap(k => [
      `${k} one on one tutorial`,
      `${k} 1-on-1 mentoring`,
      `${k} personalized coaching`,
      `${k} live online training`
    ])
  ]
    .filter(Boolean)
    .join(', ')

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200'
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'Advanced': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'Expert': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case 'High': return 'text-green-600'
      case 'Very High': return 'text-blue-600'
      case 'Extreme': return 'text-purple-600'
      default: return 'text-gray-600'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Head>
        <title>Learning Paths | Personalized One-on-One Roadmaps | Sophiray</title>
        <meta
          name="description"
          content="Follow structured, career-focused learning paths with personalized one-on-one mentorship. Full-Stack, AI/ML, Cybersecurity, DevOps, Data Science, and Mobile Development."
        />
        <meta name="keywords" content={seoKeywords} />
        <meta property="og:title" content="Learning Paths | Personalized One-on-One Roadmaps | Sophiray" />
        <meta
          property="og:description"
          content="From beginner to expert, get 1-on-1 guidance across industry-ready roadmaps and projects."
        />
        <meta property="og:type" content="website" />
      </Head>
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.05]"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -mr-48 -mt-48"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-100 text-sm font-medium mb-6">
              <Map className="w-4 h-4 mr-2" />
              6 Career Paths • 50+ Courses • Job-Ready Programs
            </div>

            <h1 className="text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
              Your Career Roadmap
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-4xl mx-auto leading-relaxed">
              Navigate your journey to success with structured learning paths designed by industry experts. 
              From beginner to expert, we'll guide you every step of the way.
            </p>
          </div>
        </div>
      </div>

      {/* Career Tabs */}
      <div className="bg-white dark:bg-gray-800 sticky top-16 z-40 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto scrollbar-hide py-4 space-x-2">
            {careerPaths.map((path) => {
              const IconComponent = path.icon
              const isActive = selectedCareer === path.id
              
              return (
                <button
                  key={path.id}
                  onClick={() => {
                    setSelectedCareer(path.id)
                    setSelectedMilestone(null)
                  }}
                  className={`flex items-center px-6 py-3 rounded-xl font-medium transition-all duration-200 whitespace-nowrap ${
                    isActive
                      ? `bg-gradient-to-r ${path.gradient} text-white shadow-lg scale-105`
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  <IconComponent className="w-5 h-5 mr-2" />
                  {path.title}
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Career Overview */}
      {currentPath && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden mb-12">
            <div className={`bg-gradient-to-r ${currentPath.gradient} p-8 text-white`}>
              <div className="flex items-center mb-4">
                <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 mr-6">
                  <currentPath.icon className="w-12 h-12 text-white" />
                </div>
                <div>
                  <h2 className="text-4xl font-bold mb-2">{currentPath.title}</h2>
                  <p className="text-xl opacity-90">{currentPath.description}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Clock className="w-5 h-5 mr-2" />
                    <span className="text-sm opacity-80">Duration</span>
                  </div>
                  <div className="text-2xl font-bold">{currentPath.totalDuration}</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <DollarSign className="w-5 h-5 mr-2" />
                    <span className="text-sm opacity-80">Avg Salary</span>
                  </div>
                  <div className="text-2xl font-bold">{currentPath.averageSalary}</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    <span className="text-sm opacity-80">Demand</span>
                  </div>
                  <div className={`text-2xl font-bold ${getDemandColor(currentPath.demandLevel)}`}>
                    {currentPath.demandLevel}
                  </div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Trophy className="w-5 h-5 mr-2" />
                    <span className="text-sm opacity-80">Success Rate</span>
                  </div>
                  <div className="text-2xl font-bold">{currentPath.successRate}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Career Map */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  Career Roadmap
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Follow this step-by-step journey from beginner to expert level
                </p>
              </div>
              <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  {currentPath.students} enrolled
                </div>
                <div className="flex items-center">
                  <Award className="w-4 h-4 mr-1" />
                  {currentPath.successRate} completion
                </div>
              </div>
            </div>

            {/* Roadmap Visualization */}
            <div className="relative">
              {/* Progress Line */}
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700"></div>

              <div className="space-y-8">
                {currentPath.milestones.map((milestone, index) => {
                  const isSelected = selectedMilestone === milestone.id
                  const isCompleted = index < 2 // Mock completion status
                  
                  return (
                    <div key={milestone.id} className="relative">
                      {/* Milestone Marker */}
                      <div className={`absolute left-6 w-4 h-4 rounded-full border-4 ${
                        isCompleted 
                          ? 'bg-green-500 border-green-200' 
                          : isSelected
                          ? `bg-${currentPath.color}-500 border-${currentPath.color}-200`
                          : 'bg-white border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                      } z-10`}>
                        {isCompleted && (
                          <CheckCircle className="w-4 h-4 text-green-500 -ml-2 -mt-2" />
                        )}
                      </div>

                      {/* Milestone Content */}
                      <div 
                        className={`ml-16 bg-gray-50 dark:bg-gray-700 rounded-xl p-6 cursor-pointer transition-all duration-300 hover:shadow-lg ${
                          isSelected ? 'ring-2 ring-blue-500 shadow-lg' : ''
                        }`}
                        onClick={() => setSelectedMilestone(isSelected ? null : milestone.id)}
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <h4 className="text-xl font-bold text-gray-900 dark:text-white mr-4">
                                {milestone.title}
                              </h4>
                              <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(milestone.difficulty)}`}>
                                {milestone.difficulty}
                              </span>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300">
                              <div className="flex items-center">
                                <Timer className="w-4 h-4 mr-1" />
                                {milestone.duration}
                              </div>
                              <div className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-1" />
                                {milestone.salary}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center">
                            <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${
                              isSelected ? 'rotate-90' : ''
                            }`} />
                          </div>
                        </div>

                        {/* Expanded Content */}
                        {isSelected && (
                          <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600">
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                              {/* Courses */}
                              <div>
                                <h5 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                                  <BookOpen className="w-4 h-4 mr-2" />
                                  Core Courses ({milestone.courses.length})
                                </h5>
                                <ul className="space-y-2">
                                  {milestone.courses.map((course, idx) => (
                                    <li key={idx} className="flex items-center text-sm">
                                      <CheckCircle className="w-3 h-3 text-green-500 mr-2 flex-shrink-0" />
                                      <span className="text-gray-700 dark:text-gray-300">{course}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Skills */}
                              <div>
                                <h5 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                                  <Target className="w-4 h-4 mr-2" />
                                  Key Skills ({milestone.skills.length})
                                </h5>
                                <div className="flex flex-wrap gap-1">
                                  {milestone.skills.map((skill, idx) => (
                                    <span key={idx} className={`px-2 py-1 rounded text-xs font-medium bg-${currentPath.color}-100 text-${currentPath.color}-800 dark:bg-${currentPath.color}-900 dark:text-${currentPath.color}-200`}>
                                      {skill}
                                    </span>
                                  ))}
                                </div>
                              </div>

                              {/* Projects */}
                              <div>
                                <h5 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                                  <Code2 className="w-4 h-4 mr-2" />
                                  Projects ({milestone.projects.length})
                                </h5>
                                <ul className="space-y-2">
                                  {milestone.projects.map((project, idx) => (
                                    <li key={idx} className="flex items-center text-sm">
                                      <Rocket className="w-3 h-3 text-purple-500 mr-2 flex-shrink-0" />
                                      <span className="text-gray-700 dark:text-gray-300">{project}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>

                            {/* Job Titles */}
                            <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
                              <h5 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                                <Briefcase className="w-4 h-4 mr-2" />
                                Career Opportunities
                              </h5>
                              <div className="flex flex-wrap gap-2">
                                {milestone.jobTitles.map((title, idx) => (
                                  <span key={idx} className="px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full text-sm font-medium">
                                    {title}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Success Destination */}
              <div className="relative mt-8">
                <div className="absolute left-6 w-4 h-4 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-500 border-4 border-yellow-200 z-10">
                  <Flag className="w-4 h-4 text-yellow-500 -ml-2 -mt-2" />
                </div>
                <div className="ml-16 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-xl p-6 border border-yellow-200 dark:border-yellow-800">
                  <div className="flex items-center mb-4">
                    <Trophy className="w-8 h-8 text-yellow-600 mr-4" />
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 dark:text-white">
                        Career Success!
                      </h4>
                      <p className="text-gray-600 dark:text-gray-300">
                        You're now a qualified {currentPath.title} ready for industry roles
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">{currentPath.averageSalary}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-300">Expected Salary</div>
                    </div>
                    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600">{currentPath.demandLevel}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-300">Market Demand</div>
                    </div>
                    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-purple-600">{currentPath.successRate}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-300">Success Rate</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Resources */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center mb-4">
                <Users className="w-8 h-8 text-blue-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Community Support</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                Join our active community of learners and get help from peers and mentors.
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center mb-4">
                <Calendar className="w-8 h-8 text-green-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">1-on-1 Mentorship</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                Get personalized guidance from industry professionals throughout your journey.
              </p>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}