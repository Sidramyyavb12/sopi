'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { useAuth } from '@/hooks/useAuth'
import { ApiService } from '@/lib/api'
import { 
  Calendar,
  Clock,
  Video,
  FileText,
  Loader2,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Target,
  Code,
  MessageSquare,
  Star,
  Download
} from 'lucide-react'
import { Button } from '@/components/ui/button'

interface MockInterviewBooking {
  bookingId: number
  interviewTypeId: string
  interviewTypeName: string
  scheduledDateTime: string
  status: string
  programmingLanguage?: string
  jobDescription: string
  additionalNotes?: string
  amount: number
  meetingLink?: string
  feedbackReceived: boolean
  feedback?: {
    overallRating: number
    technicalSkills: number
    communication: number
    problemSolving: number
    comments: string
    strengths: string[]
    improvements: string[]
  }
}

export default function InterviewDetailsPage({ params }: { params: { bookingId: string } }) {
  const { user, isLoading: authLoading } = useAuth()
  const [booking, setBooking] = useState<MockInterviewBooking | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isCancelling, setIsCancelling] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (authLoading) return
    if (!user) {
      router.push('/login')
      return
    }
    if (user.role !== 'LEARNER') {
      router.push('/')
      return
    }

    fetchBookingDetails()
  }, [authLoading, user, params.bookingId])

  const fetchBookingDetails = async () => {
    try {
      setIsLoading(true)
      const data = await ApiService.getMockInterviewBooking(parseInt(params.bookingId))
      console.log('📋 Interview booking:', data)
      setBooking(data)
    } catch (error) {
      console.error('❌ Failed to fetch booking:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancelBooking = async () => {
    if (!confirm('Are you sure you want to cancel this interview? This action cannot be undone.')) {
      return
    }

    try {
      setIsCancelling(true)
      await ApiService.cancelMockInterviewBooking(parseInt(params.bookingId))
      alert('Interview cancelled successfully')
      router.push('/dashboard/learner')
    } catch (error) {
      console.error('❌ Failed to cancel booking:', error)
      alert('Failed to cancel interview')
    } finally {
      setIsCancelling(false)
    }
  }

  const handleJoinInterview = () => {
    if (booking?.meetingLink) {
      window.open(booking.meetingLink, '_blank')
    } else {
      alert('Meeting link not available yet. Please check back closer to your interview time.')
    }
  }

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading interview details...</p>
        </div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-600">Interview booking not found</p>
          <Button 
            onClick={() => router.push('/dashboard/learner')}
            className="mt-4"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SCHEDULED':
        return <span className="px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">Scheduled</span>
      case 'COMPLETED':
        return <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">Completed</span>
      case 'CANCELLED':
        return <span className="px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">Cancelled</span>
      default:
        return <span className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">{status}</span>
    }
  }

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-5 h-5 ${
              i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
            }`}
          />
        ))}
        <span className="ml-2 text-gray-600 font-medium">{rating}/5</span>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <main className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Button
            variant="outline"
            onClick={() => router.push('/dashboard/learner')}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>

          {/* Interview Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-8 text-white mb-8">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">{booking.interviewTypeName}</h1>
                <div className="flex items-center gap-3">
                  {getStatusBadge(booking.status)}
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">₹{(booking.amount / 100).toFixed(0)}</div>
                <div className="text-blue-100 text-sm">Amount Paid</div>
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid md:grid-cols-2 gap-4 mt-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Calendar className="w-5 h-5 mr-2" />
                  <span className="text-sm text-blue-100">Interview Date</span>
                </div>
                <div className="text-lg font-semibold">
                  {new Date(booking.scheduledDateTime).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Clock className="w-5 h-5 mr-2" />
                  <span className="text-sm text-blue-100">Interview Time</span>
                </div>
                <div className="text-lg font-semibold">
                  {new Date(booking.scheduledDateTime).toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            {booking.status === 'SCHEDULED' && (
              <div className="flex gap-4 mt-6">
                <Button
                  onClick={handleJoinInterview}
                  className="flex-1 bg-white text-blue-700 hover:bg-blue-50"
                  disabled={!booking.meetingLink}
                >
                  <Video className="w-4 h-4 mr-2" />
                  {booking.meetingLink ? 'Join Interview' : 'Link Coming Soon'}
                </Button>
                <Button
                  onClick={handleCancelBooking}
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                  disabled={isCancelling}
                >
                  {isCancelling ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Cancelling...
                    </>
                  ) : (
                    'Cancel Interview'
                  )}
                </Button>
              </div>
            )}
          </div>

          {/* Interview Details */}
          <div className="space-y-6">
            {/* Job Description */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <Target className="w-6 h-6 mr-2 text-blue-600" />
                Job Description
              </h3>
              <p className="text-gray-700 whitespace-pre-wrap">{booking.jobDescription}</p>
            </div>

            {/* Programming Language */}
            {booking.programmingLanguage && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <Code className="w-6 h-6 mr-2 text-blue-600" />
                  Programming Language
                </h3>
                <div className="inline-block bg-blue-100 text-blue-800 px-4 py-2 rounded-lg font-medium">
                  {booking.programmingLanguage}
                </div>
              </div>
            )}

            {/* Additional Notes */}
            {booking.additionalNotes && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <MessageSquare className="w-6 h-6 mr-2 text-blue-600" />
                  Additional Notes
                </h3>
                <p className="text-gray-700 whitespace-pre-wrap">{booking.additionalNotes}</p>
              </div>
            )}

            {/* Feedback Section */}
            {booking.status === 'COMPLETED' && booking.feedbackReceived && booking.feedback && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900 flex items-center">
                    <FileText className="w-6 h-6 mr-2 text-green-600" />
                    Interview Feedback
                  </h3>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </div>

                {/* Overall Rating */}
                <div className="mb-6 p-4 bg-green-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-2">Overall Rating</div>
                  {renderStars(booking.feedback.overallRating)}
                </div>

                {/* Detailed Ratings */}
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-600 mb-2">Technical Skills</div>
                    {renderStars(booking.feedback.technicalSkills)}
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-600 mb-2">Communication</div>
                    {renderStars(booking.feedback.communication)}
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-600 mb-2">Problem Solving</div>
                    {renderStars(booking.feedback.problemSolving)}
                  </div>
                </div>

                {/* Comments */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Interviewer Comments</h4>
                  <p className="text-gray-700 p-4 bg-gray-50 rounded-lg">{booking.feedback.comments}</p>
                </div>

                {/* Strengths */}
                {booking.feedback.strengths && booking.feedback.strengths.length > 0 && (
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
                      Your Strengths
                    </h4>
                    <ul className="space-y-2">
                      {booking.feedback.strengths.map((strength, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="w-5 h-5 mr-2 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Areas for Improvement */}
                {booking.feedback.improvements && booking.feedback.improvements.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <AlertCircle className="w-5 h-5 mr-2 text-yellow-600" />
                      Areas for Improvement
                    </h4>
                    <ul className="space-y-2">
                      {booking.feedback.improvements.map((improvement, index) => (
                        <li key={index} className="flex items-start">
                          <AlertCircle className="w-5 h-5 mr-2 text-yellow-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{improvement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* No Feedback Yet */}
            {booking.status === 'COMPLETED' && !booking.feedbackReceived && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 text-center">
                <Clock className="w-12 h-12 mx-auto mb-4 text-yellow-600" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Feedback Pending
                </h3>
                <p className="text-gray-600">
                  Your interview feedback is being prepared. You'll be notified once it's ready.
                </p>
              </div>
            )}

            {/* Cancelled Notice */}
            {booking.status === 'CANCELLED' && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
                <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-600" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Interview Cancelled
                </h3>
                <p className="text-gray-600 mb-4">
                  This interview has been cancelled. Please book a new interview if needed.
                </p>
                <Button onClick={() => router.push('/mock-interviews')}>
                  Book New Interview
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}