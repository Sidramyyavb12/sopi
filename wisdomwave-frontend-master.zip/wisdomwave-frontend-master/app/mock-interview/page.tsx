// app/mock-interview/page.tsx - PART 1 (COMPLETE REFACTORED)
'use client'

import React, { useState } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/navigation'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import AuthModal from '@/components/auth/AuthModal'
import { useAuth } from '@/hooks/useAuth'
import PaymentSuccessModal from '@/components/payment/PaymentSuccessModal'
import { handleInterviewPayment } from '@/lib/helpers/paymentHelpers'
import { 
  Mic,
  Video,
  Clock,
  Star,
  Award,
  Users,
  CheckCircle,
  PlayCircle,
  Calendar,
  FileText,
  MessageCircle,
  TrendingUp,
  Target,
  Shield,
  X,
  AlertCircle,
  Send
} from 'lucide-react'

// ============================================
// TYPE DEFINITIONS
// ============================================

interface InterviewType {
  id: string
  name: string
  description: string
  duration: string
  price: number // in rupees
  priceInPaise: number // in paise for backend
  features: string[]
  popular?: boolean
}

// ============================================
// STATIC DATA
// ============================================

const interviewTypes: InterviewType[] = [
  {
    id: 'regular-technical',
    name: 'Regular Technical Interview',
    description: 'Language-specific coding challenges and technical problem-solving sessions',
    duration: '60 minutes',
    price: 1000,
    priceInPaise: 100000,
    features: [
      'Live coding session', 
      'Language-specific questions', 
      'Data structures & algorithms', 
      'Code review and optimization', 
      'Best practices discussion'
    ],
    popular: true
  },
  {
    id: 'system-design',
    name: 'System Design Interview',
    description: 'Architecture design and scalability discussions with expert feedback',
    duration: '75 minutes',
    price: 1500,
    priceInPaise: 150000,
    features: [
      'Architecture design', 
      'Scalability planning', 
      'Database design', 
      'Distributed systems', 
      'Real-world scenarios'
    ]
  }
]

const programmingLanguages = [
  'JavaScript', 'Python', 'Java', 'C++', 'C#', 'Go', 'Rust', 
  'TypeScript', 'Swift', 'Kotlin', 'PHP', 'Ruby', 'Scala'
]

// ============================================
// STATS DATA
// ============================================

const stats = [
  { icon: Users, value: '10K+', label: 'Interviews Conducted' },
  { icon: Star, value: '4.9', label: 'Average Rating' },
  { icon: TrendingUp, value: '87%', label: 'Success Rate' },
  { icon: Award, value: '50+', label: 'Expert Interviewers' }
]

const howItWorksSteps = [
  {
    step: '1',
    icon: Target,
    title: 'Choose Interview Type',
    description: 'Select between Regular Technical or System Design based on your needs'
  },
  {
    step: '2',
    icon: Calendar,
    title: 'Schedule Session',
    description: 'Pick a convenient time slot and provide your job description details'
  },
  {
    step: '3',
    icon: Video,
    title: 'Live Interview',
    description: 'Join the video call and practice with our expert interviewer'
  },
  {
    step: '4',
    icon: FileText,
    title: 'Get Feedback',
    description: 'Receive detailed written feedback and improvement recommendations'
  }
]

const features = [
  {
    icon: Video,
    title: 'Live 1-on-1 Sessions',
    description: 'Real-time video interviews with experienced professionals from top companies'
  },
  {
    icon: MessageCircle,
    title: 'Detailed Feedback',
    description: 'Comprehensive written and verbal feedback on your performance and areas for improvement'
  },
  {
    icon: Target,
    title: 'Personalized Guidance',
    description: 'Customized interview prep based on your target role and job description'
  },
  {
    icon: Shield,
    title: 'Success Guarantee',
    description: 'Money-back guarantee if you don\'t see improvement in your interview skills'
  }
]

// ============================================
// MAIN COMPONENT
// ============================================

export default function MockInterviewPage() {
  const router = useRouter()
  const { user } = useAuth()
  
  // ============================================
  // STATE MANAGEMENT
  // ============================================
  
  // Interview Selection
  const [selectedType, setSelectedType] = useState<string>('regular-technical')
  
  // Modals
  const [showBookingModal, setShowBookingModal] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  
  // Processing
  const [isProcessing, setIsProcessing] = useState(false)
  
  // Payment Result
  const [paymentResult, setPaymentResult] = useState<any>(null)
  
  // Booking Form Fields
  const [jobDescription, setJobDescription] = useState('')
  const [selectedTime, setSelectedTime] = useState('')
  const [selectedLanguage, setSelectedLanguage] = useState('')
  const [additionalNotes, setAdditionalNotes] = useState('')

  // Available time slots
  const timeSlots = [
    'Today 2:00 PM', 
    'Today 4:00 PM', 
    'Tomorrow 10:00 AM', 
    'Tomorrow 2:00 PM', 
    'Tomorrow 4:00 PM', 
    'Day after 9:00 AM'
  ]

  // ============================================
  // HANDLERS - BOOKING FLOW
  // ============================================

  /**
   * Handle initial booking button click
   * Check authentication and open booking modal
   */
  const handleBooking = async (): Promise<void> => {
    // Check if user is logged in
    if (!user) {
      setShowAuthModal(true)
      return
    }

    // Check if user is a learner
    if (user.role !== 'LEARNER') {
      alert(`⚠️ Only learners can book interviews\n\nYou are: ${user.role}`)
      return
    }

    // Open booking modal
    setShowBookingModal(true)
  }

  /**
   * Validate booking form
   */
  const validateBookingForm = (): { isValid: boolean; error?: string } => {
    const isRegularTechnical = selectedType === 'regular-technical'
    
    if (!selectedTime) {
      return { isValid: false, error: 'Please select a time slot' }
    }
    
    if (!jobDescription.trim()) {
      return { isValid: false, error: 'Please provide job description' }
    }
    
    if (isRegularTechnical && !selectedLanguage) {
      return { isValid: false, error: 'Please select a programming language' }
    }
    
    return { isValid: true }
  }

  /**
   * Handle confirm booking - Process payment
   */
  const handleConfirmBooking = async (): Promise<void> => {
    // Validate form
    const validation = validateBookingForm()
    if (!validation.isValid) {
      alert(`❌ ${validation.error}`)
      return
    }
    
    setIsProcessing(true)

    try {
      // Get selected interview type
      const selectedInterview = interviewTypes.find(t => t.id === selectedType)
      if (!selectedInterview) {
        alert('❌ Invalid interview type selected')
        setIsProcessing(false)
        return
      }

      // Convert selected time to ISO format
      // TODO: In production, use proper date picker
      const scheduledDateTime = new Date().toISOString()

      console.log('📝 Creating order with price:', selectedInterview.priceInPaise, 'paise (₹' + selectedInterview.price + ')')
      
      // Create booking details
      const bookingDetails = {
        interviewTypeId: selectedType,
        scheduledDateTime,
        programmingLanguage: selectedType === 'regular-technical' ? selectedLanguage : undefined,
        jobDescription: jobDescription.trim(),
        additionalNotes: additionalNotes.trim() || undefined
      }

      // Handle payment using helper function
      await handleInterviewPayment(
        {
          interviewTypeId: selectedInterview.id,
          interviewTypeName: selectedInterview.name,
          amount: selectedInterview.priceInPaise,
          scheduledDateTime,
          programmingLanguage: bookingDetails.programmingLanguage,
          jobDescription: bookingDetails.jobDescription,
          additionalNotes: bookingDetails.additionalNotes,
          user
        },
        (result) => {
          // ✅ Payment Success Callback
          console.log('✅ Payment successful:', result)
          
          setPaymentResult({
            title: selectedInterview.name,
            bookingId: result.bookingId,
            paymentId: result.paymentId,
            status: result.status,
            redirectPath: '/dashboard/learner'
          })
          
          setShowSuccessModal(true)
          setShowBookingModal(false)
          
          // Reset form
          setJobDescription('')
          setSelectedTime('')
          setSelectedLanguage('')
          setAdditionalNotes('')
          
          setIsProcessing(false)
        },
        (error) => {
          // ❌ Payment Error Callback
          console.error('❌ Payment error:', error)
          
          if (error !== 'Payment cancelled') {
            alert(`❌ Payment Error\n\n${error}`)
          }
          
          setIsProcessing(false)
        }
      )

    } catch (error: any) {
      console.error('❌ Booking error:', error)
      alert(`❌ Booking Error\n\n${error.message || 'Please try again'}`)
      setIsProcessing(false)
    }
  }

  /**
   * Reset booking form
   */
  const resetBookingForm = () => {
    setJobDescription('')
    setSelectedTime('')
    setSelectedLanguage('')
    setAdditionalNotes('')
  }

  // ============================================
  // RENDER - Continue to PART 2 for JSX
  // ============================================
  
  // JSX continues in PART 2...
  // app/mock-interview/page.tsx - PART 2 (JSX)
// Continue from PART 1...

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Head>
        <title>Mock Interview Practice | 1-on-1 Technical & System Design | Sophiray</title>
        <meta
          name="description"
          content="Book personalized one-on-one mock interviews for coding and system design. Get expert feedback, detailed reports, and targeted improvement plans."
        />
        <meta
          name="keywords"
          content={[
            'mock interview one on one',
            '1-on-1 coding interview practice',
            'system design interview mentoring',
            'personalized interview coaching',
            'technical interview preparation',
            'live interview feedback'
          ].join(', ')}
        />
        <meta property="og:title" content="Mock Interview Practice | 1-on-1 Technical & System Design | Sophiray" />
        <meta
          property="og:description"
          content="Practice with experts and receive detailed feedback to ace your next interview."
        />
        <meta property="og:type" content="website" />
      </Head>
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/[0.05]"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -mr-48 -mt-48"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-purple-500/20 border border-purple-400/30 text-purple-100 text-sm font-medium mb-6">
              <Mic className="w-4 h-4 mr-2" />
              Technical Interview Practice • Expert Feedback • All Programming Languages
            </div>

            <h1 className="text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-purple-100 bg-clip-text text-transparent">
              Master Technical Interviews
            </h1>
            <p className="text-xl lg:text-2xl text-purple-100 mb-8 max-w-4xl mx-auto leading-relaxed">
              Practice coding challenges and system design with industry experts. Get personalized feedback 
              on your technical skills and problem-solving approach.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => router.push('/contact')}
                className="bg-white text-purple-700 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-50 transition-colors flex items-center justify-center"
              >
                <MessageCircle className="w-6 h-6 mr-2" />
                Contact Us
              </button>
            </div>

            {/* Stats */}
            {/* <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mt-12">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <div className="text-purple-200 mb-2">
                    <stat.icon className="w-8 h-8 mx-auto" />
                  </div>
                  <div className="text-3xl font-bold mb-1">{stat.value}</div>
                  <div className="text-purple-200 text-sm">{stat.label}</div>
                </div>
              ))}
            </div> */}
          </div>
        </div>
      </div>

      {/* Interview Types */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Choose Your Technical Interview Type
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Select between language-specific coding challenges or system design interviews based on your preparation needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {interviewTypes.map((type) => (
            <div
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`relative bg-white dark:bg-gray-800 rounded-2xl p-8 cursor-pointer transition-all duration-300 border-2 hover:shadow-xl ${
                selectedType === type.id
                  ? 'border-purple-500 shadow-lg scale-105'
                  : 'border-gray-200 dark:border-gray-700 hover:border-purple-300'
              }`}
            >
              {type.popular && (
                <div className="absolute -top-3 -right-3 bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                  POPULAR
                </div>
              )}
              
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  {type.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-base mb-4">
                  {type.description}
                </p>
                <div className="flex items-center justify-between text-base text-gray-500 dark:text-gray-400 mb-6">
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    {type.duration}
                  </div>
                  <div className="flex items-center font-bold text-2xl text-purple-600">
                    ₹{type.price.toLocaleString()}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {type.features.map((feature, index) => (
                  <div key={index} className="flex items-center text-base text-gray-600 dark:text-gray-300">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    {feature}
                  </div>
                ))}
              </div>

              <button
                className={`w-full mt-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 ${
                  selectedType === type.id
                    ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-purple-100 dark:hover:bg-purple-900/20'
                }`}
              >
                {selectedType === type.id ? 'Selected' : 'Select This Option'}
              </button>
            </div>
          ))}
        </div>

        {/* Book Interview Button */}
        <div className="text-center">
          <button
            onClick={handleBooking}
            className="bg-gradient-to-r from-purple-600 to-purple-700 text-white px-12 py-4 rounded-xl font-bold text-xl hover:from-purple-700 hover:to-purple-800 transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105"
          >
            <Calendar className="w-6 h-6 mr-3 inline" />
            Book {interviewTypes.find(t => t.id === selectedType)?.name} - ₹{interviewTypes.find(t => t.id === selectedType)?.price.toLocaleString()}
          </button>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Simple 4-step process to get expert interview feedback and improve your skills.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorksSteps.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="bg-purple-100 dark:bg-purple-900/30 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-10 h-10 text-purple-600" />
                  </div>
                  <div className="absolute -top-2 -right-2 bg-purple-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
                    {step.step}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{step.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Why Choose Our Platform?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Get the most comprehensive interview preparation experience with industry experts.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="bg-purple-100 dark:bg-purple-900/30 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ✅ REFACTORED: Booking Modal */}
      {showBookingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Modal Header */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Book {interviewTypes.find(t => t.id === selectedType)?.name}
                </h3>
                <button
                  onClick={() => {
                    setShowBookingModal(false)
                    resetBookingForm()
                  }}
                  disabled={isProcessing}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-50"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Interview Type Info */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-6">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    {interviewTypes.find(t => t.id === selectedType)?.name}
                  </h4>
                  <div className="text-right">
                    <div className="text-xl font-bold text-purple-600">
                      ₹{interviewTypes.find(t => t.id === selectedType)?.price.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-500">
                      {interviewTypes.find(t => t.id === selectedType)?.duration}
                    </div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {interviewTypes.find(t => t.id === selectedType)?.description}
                </p>
              </div>

              {/* Programming Language Selection - only for regular technical */}
              {selectedType === 'regular-technical' && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    Preferred Programming Language *
                  </label>
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    disabled={isProcessing}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50"
                  >
                    <option value="">Select a programming language</option>
                    {programmingLanguages.map((lang) => (
                      <option key={lang} value={lang}>
                        {lang}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Time Slots */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Select Time Slot *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {timeSlots.map((slot, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedTime(slot)}
                      disabled={isProcessing}
                      className={`p-3 rounded-lg border text-left transition-all disabled:opacity-50 ${
                        selectedTime === slot
                          ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                          : 'border-gray-300 dark:border-gray-600 hover:border-purple-300 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2" />
                        {slot}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Job Description */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Job Description / Role Details *
                </label>
                <textarea
                  rows={4}
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  disabled={isProcessing}
                  placeholder="Paste the job description or describe the role you're preparing for..."
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none disabled:opacity-50"
                />
              </div>

              {/* Additional Notes */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Additional Notes (Optional)
                </label>
                <textarea
                  rows={3}
                  value={additionalNotes}
                  onChange={(e) => setAdditionalNotes(e.target.value)}
                  disabled={isProcessing}
                  placeholder="Any specific areas you'd like to focus on..."
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none disabled:opacity-50"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <button
                  onClick={() => {
                    setShowBookingModal(false)
                    resetBookingForm()
                  }}
                  disabled={isProcessing}
                  className="flex-1 px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmBooking}
                  disabled={isProcessing}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-700 hover:to-purple-800 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isProcessing ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Confirm - ₹{interviewTypes.find(t => t.id === selectedType)?.price.toLocaleString()}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Ace Your Next Interview?
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
            Don't let interview anxiety hold you back. Practice with experts, get personalized feedback, 
            and land your dream job with confidence.
          </p>
          <button 
            onClick={() => router.push('/contact')}
            className="bg-white text-purple-700 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-50 transition-colors inline-flex items-center justify-center"
          >
            <MessageCircle className="w-6 h-6 mr-2" />
            Contact Us for More Info
          </button>
        </div>
      </div>

      <Footer />
      
      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => {
          setShowAuthModal(false)
          setShowBookingModal(true)
        }}
      />

      {/* ✅ NEW: Payment Success Modal */}
      {paymentResult && (
        <PaymentSuccessModal
          isOpen={showSuccessModal}
          onClose={() => setShowSuccessModal(false)}
          type="interview"
          data={paymentResult}
        />
      )}
    </div>
  )
}