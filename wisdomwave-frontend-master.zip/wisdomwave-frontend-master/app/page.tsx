'use client'

import { useState } from 'react'
import Navigation from '@/components/layout/Navigation'
import HeroSection from '@/components/layout/HeroSection'
import FeaturedCourses from '@/components/courses/FeaturedCourses'
import StatsSection from '@/components/layout/StatsSection'
import TestimonialsSection from '@/components/layout/TestimonialsSection'
import Footer from '@/components/layout/Footer'
import CourseDetailModal from '@/components/courses/CourseDetailModal'
import { useAuth } from '@/hooks/useAuth'
import { ApiService } from '@/lib/api'
import { Course } from '@/types/course'
import { useRouter } from 'next/navigation'

export default function HomePage() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [showCourseModal, setShowCourseModal] = useState(false)
  const { user } = useAuth()
  const router = useRouter()

  // Handle course enrollment
  const handleCourseEnroll = async (course: Course, selectedPath = 'basic') => {
    if (!user) {
      // Redirect to login page instead of showing modal
      router.push('/login?from=' + encodeURIComponent(window.location.pathname))
      return
    }

    try {
      await ApiService.enrollInCourse(course.id, {
        learningPath: selectedPath,
        paymentMethod: 'pending'
      })
      
      alert(`Successfully enrolled in ${course.title}!`)
      setShowCourseModal(false)
      
      // Redirect to dashboard after enrollment
      if (user.role === 'INSTRUCTOR') {
        router.push('/dashboard/instructor')
      } else {
        router.push('/dashboard/learner')
      }
    } catch (error) {
      console.error('Enrollment failed:', error)
      alert('Enrollment failed. Please try again.')
    }
  }

  // Handle course details view
  const handleCourseDetails = (course: Course) => {
    setSelectedCourse(course)
    setShowCourseModal(true)
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
      {/* Navigation handles its own auth routing */}
      <Navigation />
      
      <HeroSection 
        onExploreClick={() => router.push('/courses')}
        onDemoClick={() => router.push('/contact')}
      />
      
      <FeaturedCourses 
        onCourseSelect={handleCourseEnroll} 
        onCourseDetails={handleCourseDetails} 
      />
      
      <StatsSection />
      
      <TestimonialsSection />
      
      <Footer />
      
      {/* Only course modal, no auth modal */}
      <CourseDetailModal
        course={selectedCourse}
        isOpen={showCourseModal}
        onClose={() => setShowCourseModal(false)}
        onEnroll={handleCourseEnroll}
      />
    </div>
  )
}