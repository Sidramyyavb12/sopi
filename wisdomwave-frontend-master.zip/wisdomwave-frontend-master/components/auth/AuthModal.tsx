// components/auth/AuthModal.tsx - Updated (Without Google Login)
'use client'

import React, { useState } from 'react'
import { X, User, Users } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ValidationUtils } from '@/lib/validations'
import { RegisterData } from '@/types/auth'

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [isLoginMode, setIsLoginMode] = useState(true)
  const [role, setRole] = useState<'LEARNER' | 'INSTRUCTOR'>('LEARNER')
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    confirmPassword: ''
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const { login, register, isAuthenticating } = useAuth()

  const resetForm = () => {
    setFormData({ email: '', password: '', name: '', confirmPassword: '' })
    setErrors({})
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (isLoginMode) {
      const validation = ValidationUtils.validateLoginForm({
        email: formData.email,
        password: formData.password
      })
      
      if (!validation.isValid) {
        setErrors(validation.errors)
        return
      }
    } else {
      const validation = ValidationUtils.validateRegisterForm({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        confirmPassword: formData.confirmPassword,
        role: role
      })
      
      if (!validation.isValid) {
        setErrors(validation.errors)
        return
      }
    }

    try {
      if (isLoginMode) {
        await login({
          email: formData.email,
          password: formData.password
        })
      } else {
        await register({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role: role
        } as RegisterData)
      }
      
      resetForm()
      onSuccess()
    } catch (error) {
      setErrors({ 
        submit: error instanceof Error ? error.message : `${isLoginMode ? 'Login' : 'Registration'} failed. Please try again.`
      })
    }
  }

  const switchMode = () => {
    setIsLoginMode(!isLoginMode)
    resetForm()
  }

  if (!isOpen) return null
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-md w-full p-6 animate-scaleIn">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            {isLoginMode ? 'Welcome Back' : 'Join Sophiray'}
          </h2>
          <button 
            onClick={onClose} 
            className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* ✅ REMOVED: Google OAuth Button and divider */}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLoginMode && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                I am a:
              </label>
              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setRole('LEARNER')}
                  className={`flex-1 p-3 rounded-lg border-2 transition-colors ${
                    role === 'LEARNER' 
                      ? 'border-green-600 bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-400' 
                      : 'border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <Users className="w-5 h-5 mx-auto mb-1" />
                  Learner
                </button>
                <button
                  type="button"
                  onClick={() => setRole('INSTRUCTOR')}
                  className={`flex-1 p-3 rounded-lg border-2 transition-colors ${
                    role === 'INSTRUCTOR' 
                      ? 'border-green-600 bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-400' 
                      : 'border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <User className="w-5 h-5 mx-auto mb-1" />
                  Instructor
                </button>
              </div>
            </div>
          )}

          {!isLoginMode && (
            <Input
              label="Full Name"
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              error={errors.name}
              required={!isLoginMode}
            />
          )}
          
          <Input
            label="Email Address"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            error={errors.email}
            required
          />
          
          <Input
            label="Password"
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            error={errors.password}
            required
          />

          {!isLoginMode && (
            <Input
              label="Confirm Password"
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              error={errors.confirmPassword}
              required={!isLoginMode}
            />
          )}

          {errors.submit && (
            <div className="p-3 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded-lg">
              <p className="text-sm text-red-600 dark:text-red-400">{errors.submit}</p>
            </div>
          )}
          
          <Button
            type="submit"
            loading={isAuthenticating}
            className="w-full"
          >
            {isLoginMode ? 'Sign In' : 'Create Account'}
          </Button>
        </form>
        
        <div className="mt-4 text-center">
          <button
            onClick={switchMode}
            className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 text-sm transition-colors"
          >
            {isLoginMode ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </div>
      </div>
    </div>
  )
}