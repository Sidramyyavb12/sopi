// components/course/CertificatePreview.tsx
import React from 'react';
import { Award, CheckCircle, Star, Shield } from 'lucide-react';

interface CertificatePreviewProps {
  courseTitle: string;
}

const CertificatePreview: React.FC<CertificatePreviewProps> = ({ courseTitle }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center mb-4">
        <Award className="w-6 h-6 text-green-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Certificate of Completion
        </h3>
      </div>
      
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
        Upon successful completion, you'll receive a verified certificate to showcase your achievement.
      </p>

      {/* Professional Certificate Preview Card */}
      <div className="relative bg-white rounded-lg overflow-hidden shadow-lg border-2 border-amber-200 dark:border-amber-700 mb-4">
        {/* Certificate Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `repeating-linear-gradient(45deg, #16a34a 0, #16a34a 1px, transparent 0, transparent 50%)`,
            backgroundSize: '10px 10px'
          }}></div>
        </div>

        {/* Decorative Border */}
        <div className="absolute inset-0 border-8 border-double border-amber-300 dark:border-amber-600 rounded-lg pointer-events-none"></div>
        
        {/* Certificate Content */}
        <div className="relative p-8 text-center">
          {/* Top Decorative Element */}
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-green-400 blur-xl opacity-30"></div>
              <div className="relative bg-gradient-to-br from-green-600 to-emerald-700 p-3 rounded-full">
                <Award className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>

          {/* Sophiray Logo */}
          <div className="mb-3">
            <div className="inline-flex items-center justify-center px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg shadow-md">
              <span className="text-white font-bold text-lg tracking-wide">SOPHIRAY</span>
            </div>
          </div>

          {/* Certificate Title */}
          <div className="mb-4">
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-widest mb-1">
              Certificate of Achievement
            </p>
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto"></div>
          </div>

          {/* Recipient Section */}
          <div className="mb-4">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 italic">
              This certifies that
            </p>
            <div className="mb-3">
              <p className="text-lg font-bold text-gray-800 dark:text-gray-200 font-serif">
                Your Name Here
              </p>
              <div className="h-0.5 w-48 bg-gray-300 dark:bg-gray-600 mx-auto mt-1"></div>
            </div>
          </div>

          {/* Course Achievement */}
          <div className="mb-4">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
              has successfully completed
            </p>
            <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200 line-clamp-2 px-4">
              {courseTitle}
            </h4>
          </div>

          {/* Completion Details */}
          <div className="flex items-center justify-center gap-6 mb-4 text-xs text-gray-600 dark:text-gray-400">
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 text-amber-500 fill-current" />
              <span>Verified</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-3 h-3 text-green-600" />
              <span>Authentic</span>
            </div>
          </div>

          {/* Signature Section */}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="text-center">
              <div className="mb-1">
                <div className="h-px w-20 bg-gray-400 dark:bg-gray-600 mx-auto mb-1"></div>
                <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                  Instructor
                </p>
              </div>
            </div>
            <div className="text-center">
              <div className="mb-1">
                <div className="h-px w-20 bg-gray-400 dark:bg-gray-600 mx-auto mb-1"></div>
                <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                  Date
                </p>
              </div>
            </div>
          </div>

          {/* Certificate ID */}
          <div className="mt-3">
            <p className="text-xs text-gray-400 dark:text-gray-500 font-mono">
              ID: CERT-{Math.random().toString(36).substr(2, 9).toUpperCase()}
            </p>
          </div>
        </div>

        {/* Corner Decorations */}
        <div className="absolute top-2 left-2 w-8 h-8 border-l-2 border-t-2 border-amber-400 dark:border-amber-600 rounded-tl-lg"></div>
        <div className="absolute top-2 right-2 w-8 h-8 border-r-2 border-t-2 border-amber-400 dark:border-amber-600 rounded-tr-lg"></div>
        <div className="absolute bottom-2 left-2 w-8 h-8 border-l-2 border-b-2 border-amber-400 dark:border-amber-600 rounded-bl-lg"></div>
        <div className="absolute bottom-2 right-2 w-8 h-8 border-r-2 border-b-2 border-amber-400 dark:border-amber-600 rounded-br-lg"></div>
      </div>

      {/* Certificate Features */}
      <div className="space-y-2">
        <div className="flex items-start text-sm">
          <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 dark:text-gray-300">Shareable on LinkedIn & social media</span>
        </div>
        <div className="flex items-start text-sm">
          <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 dark:text-gray-300">Verifiable certificate ID</span>
        </div>
        <div className="flex items-start text-sm">
          <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 dark:text-gray-300">High-resolution PDF download</span>
        </div>
        <div className="flex items-start text-sm">
          <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 dark:text-gray-300">Lifetime validity</span>
        </div>
      </div>
    </div>
  );
};

export default CertificatePreview;