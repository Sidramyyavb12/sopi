// components/course/CourseOverview.tsx
import React from 'react';
import { CheckCircle, Target } from 'lucide-react';

interface CourseOverviewProps {
  description: string;
  teacherSessions: number;
  totalSessions: number;
  prerequisites: string[];
  whatYoullLearn: string[];
}

const CourseOverview: React.FC<CourseOverviewProps> = ({
  description,
  teacherSessions,
  totalSessions,
  prerequisites,
  whatYoullLearn
}) => {
  return (
    <div className="space-y-8">
      {/* Course Description */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Course Overview
        </h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <p className="text-gray-700 dark:text-gray-300 mb-4 leading-relaxed">
            {description}
          </p>
          <p className="text-gray-700 dark:text-gray-300">
            This comprehensive course follows a structured learning approach with{' '}
            {teacherSessions} live teacher sessions and {totalSessions - teacherSessions} homework
            sessions, ensuring you get both expert guidance and plenty of hands-on practice.
          </p>
        </div>
      </div>

      {/* Prerequisites */}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
          Prerequisites
        </h3>
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
          <ul className="space-y-3">
            {prerequisites.map((prereq, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700 dark:text-gray-300">{prereq}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* What You'll Learn */}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
          What You'll Learn
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {whatYoullLearn.map((skill, index) => (
            <div key={index} className="flex items-start">
              <Target className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
              <span className="text-gray-700 dark:text-gray-300">{skill}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CourseOverview;