// components/course/CourseProjects.tsx
import React from 'react';
import { CheckSquare } from 'lucide-react';

interface Project {
  title: string;
  description: string;
  duration: string;
  technologies: string[];
  features: string[];
}

interface CourseProjectsProps {
  projects: Project[];
}

const CourseProjects: React.FC<CourseProjectsProps> = ({ projects }) => {
  if (!projects || projects.length === 0) {
    return null;
  }

  return (
    <div>
      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        Course Projects
      </h3>
      <div className="space-y-6">
        {projects.map((project, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700"
          >
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {project.title}
            </h4>
            <p className="text-gray-600 dark:text-gray-300 mb-4">{project.description}</p>
            
            {/* Technologies */}
            <div className="flex flex-wrap gap-2 mb-4">
              {project.technologies.map((tech, techIndex) => (
                <span
                  key={techIndex}
                  className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-2 py-1 rounded text-sm"
                >
                  {tech}
                </span>
              ))}
            </div>
            
            {/* Duration and Features Count */}
            <div className="grid grid-cols-2 gap-4 text-sm mb-4">
              <div>
                <span className="font-medium text-gray-900 dark:text-white">Duration: </span>
                <span className="text-gray-600 dark:text-gray-300">{project.duration}</span>
              </div>
              <div>
                <span className="font-medium text-gray-900 dark:text-white">Features: </span>
                <span className="text-gray-600 dark:text-gray-300">
                  {project.features.length} components
                </span>
              </div>
            </div>
            
            {/* Key Features */}
            <div>
              <h5 className="font-medium text-gray-900 dark:text-white mb-2">Key Features:</h5>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {project.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-center text-sm text-gray-600 dark:text-gray-300"
                  >
                    <CheckSquare className="w-3 h-3 text-green-600 mr-2 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseProjects;