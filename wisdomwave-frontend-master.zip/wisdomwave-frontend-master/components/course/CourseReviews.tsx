// components/course/CourseReviews.tsx
import React from 'react';
import { Star, ThumbsUp } from 'lucide-react';

interface Review {
  name: string;
  rating: number;
  date: string;
  review: string;
  helpful: number;
}

interface CourseReviewsProps {
  rating: number;
  totalReviews: number;
  reviews: Review[];
  ratingBreakdown: { rating: number; percentage: number }[];
}

const CourseReviews: React.FC<CourseReviewsProps> = ({
  rating,
  totalReviews,
  reviews,
  ratingBreakdown
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Student Reviews</h2>
        <div className="flex items-center">
          <Star className="w-5 h-5 text-yellow-400 fill-current" />
          <span className="ml-2 font-semibold text-xl">{rating}</span>
          <span className="ml-2 text-gray-600 dark:text-gray-300">
            ({totalReviews.toLocaleString()} reviews)
          </span>
        </div>
      </div>

      {/* Rating Breakdown */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Rating Breakdown
        </h3>
        <div className="space-y-3">
          {ratingBreakdown.map((item) => (
            <div key={item.rating} className="flex items-center">
              <span className="text-sm w-8">{item.rating}</span>
              <Star className="w-4 h-4 text-yellow-400 fill-current mr-2" />
              <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-4">
                <div
                  className="bg-yellow-400 h-2 rounded-full"
                  style={{ width: `${item.percentage}%` }}
                ></div>
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-300 w-12">
                {item.percentage}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Individual Reviews */}
      <div className="space-y-6">
        {reviews.map((review, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white">{review.name}</h4>
                <div className="flex items-center mt-1">
                  <div className="flex items-center mr-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{review.date}</span>
                </div>
              </div>
            </div>
            <p className="text-gray-700 dark:text-gray-300 mb-4">{review.review}</p>
            <div className="flex items-center justify-between">
              <button className="flex items-center text-sm text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                <ThumbsUp className="w-4 h-4 mr-1" />
                Helpful ({review.helpful})
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseReviews;