// components/course/CourseSyllabus.tsx
import React from 'react';
import { BookOpen } from 'lucide-react';

interface SyllabusSection {
  title: string;
  duration: string;
  lessons: number;
  topics: string[];
}

interface CourseSyllabusProps {
  syllabus: SyllabusSection[];
}

const CourseSyllabus: React.FC<CourseSyllabusProps> = ({ syllabus }) => {
  if (!syllabus || syllabus.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 dark:text-gray-400">Syllabus information coming soon...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Course Syllabus
      </h2>
      {syllabus.map((section, index) => (
        <div
          key={index}
          className="border border-gray-200 dark:border-gray-700 rounded-lg p-6 bg-white dark:bg-gray-800"
        >
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            {section.title}
          </h3>
          <ul className="space-y-3">
            {section.topics.map((topic, topicIndex) => (
              <li key={topicIndex} className="flex items-start">
                <BookOpen className="w-4 h-4 text-green-600 mr-3 mt-1 flex-shrink-0" />
                <span className="text-gray-700 dark:text-gray-300">{topic}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default CourseSyllabus;