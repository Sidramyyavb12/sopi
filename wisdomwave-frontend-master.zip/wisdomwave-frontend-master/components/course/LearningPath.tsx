// components/course/LearningPath.tsx
import React, { useState } from 'react';
import {
  Calendar,
  ChevronDown,
  Clock,
  User,
  BookOpen,
  Lightbulb,
  CheckCircle,
  Code,
  ArrowRight,
  Target,
  CheckSquare
} from 'lucide-react';

interface Session {
  session: number;
  title: string;
  type: 'teacher' | 'homework';
  duration: string;
  topics: string[];
  activities: string[];
  homework?: string;
  deliverables?: string[];
}

interface LearningPathWeek {
  week: number;
  title: string;
  description: string;
  sessions: Session[];
}

interface LearningPathProps {
  learningPath: LearningPathWeek[];
  teacherSessions: number;
  totalSessions: number;
}

const LearningPath: React.FC<LearningPathProps> = ({
  learningPath,
  teacherSessions,
  totalSessions
}) => {
  const [expandedWeek, setExpandedWeek] = useState<number | null>(null);

  const toggleWeek = (weekIndex: number) => {
    setExpandedWeek(expandedWeek === weekIndex ? null : weekIndex);
  };

  const homeworkSessions = totalSessions - teacherSessions;
  const totalWeeks = Math.ceil(totalSessions / 4);

  if (!learningPath || learningPath.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 dark:text-gray-400">Learning path coming soon...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Complete Learning Path
        </h2>
        <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg p-6 border border-green-200 dark:border-green-800">
          <p className="text-gray-700 dark:text-gray-300 mb-4">
            Follow this structured {totalWeeks}-week learning path with alternating teacher and
            homework sessions:
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">{teacherSessions}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Teacher Sessions</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-600">{homeworkSessions}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Homework Sessions</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-600">{totalSessions}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Total Sessions</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-orange-600">{totalWeeks}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Weeks</div>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Breakdown */}
      {learningPath.map((week, weekIndex) => (
        <div
          key={weekIndex}
          className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-800"
        >
          {/* Week Header */}
          <button
            onClick={() => toggleWeek(weekIndex)}
            className="w-full p-6 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors text-left"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Week {week.week}: {week.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">{week.description}</p>
              </div>
              <div className="flex items-center">
                <Calendar className="w-5 h-5 text-gray-400 mr-2" />
                <span className="text-sm text-gray-600 dark:text-gray-300 mr-3">
                  {week.sessions.length} sessions
                </span>
                <ChevronDown
                  className={`w-5 h-5 transition-transform ${
                    expandedWeek === weekIndex ? 'rotate-180' : ''
                  }`}
                />
              </div>
            </div>
          </button>

          {/* Week Content */}
          {expandedWeek === weekIndex && (
            <div className="p-6 space-y-6">
              {week.sessions.map((session, sessionIndex) => (
                <div
                  key={sessionIndex}
                  className={`rounded-lg p-6 border ${
                    session.type === 'teacher'
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                      : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                  }`}
                >
                  {/* Session Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <span
                          className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            session.type === 'teacher'
                              ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100'
                          }`}
                        >
                          {session.type === 'teacher' ? (
                            <>
                              <User className="w-3 h-3 mr-1" />
                              LIVE WITH TEACHER
                            </>
                          ) : (
                            <>
                              <BookOpen className="w-3 h-3 mr-1" />
                              HOMEWORK SESSION
                            </>
                          )}
                        </span>
                      </div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                        Session {session.session}: {session.title}
                      </h4>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mb-3">
                        <Clock className="w-4 h-4 mr-1" />
                        {session.duration}
                      </div>
                    </div>
                  </div>

                  {/* Session Content Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Topics */}
                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-3 flex items-center">
                        <Lightbulb className="w-4 h-4 mr-2" />
                        Topics Covered:
                      </h5>
                      <ul className="space-y-2">
                        {session.topics.map((topic, topicIndex) => (
                          <li key={topicIndex} className="flex items-start text-sm">
                            <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">{topic}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Activities and Deliverables */}
                    <div className="space-y-4">
                      {/* Activities */}
                      <div
                        className={`rounded-lg p-4 ${
                          session.type === 'teacher'
                            ? 'bg-green-100 dark:bg-green-800/30'
                            : 'bg-blue-100 dark:bg-blue-800/30'
                        }`}
                      >
                        <h5
                          className={`font-medium mb-2 flex items-center ${
                            session.type === 'teacher'
                              ? 'text-green-800 dark:text-green-200'
                              : 'text-blue-800 dark:text-blue-200'
                          }`}
                        >
                          <Code className="w-4 h-4 mr-2" />
                          {session.type === 'teacher' ? 'Live Activities:' : 'Practice Activities:'}
                        </h5>
                        <ul className="space-y-1">
                          {session.activities.map((activity, activityIndex) => (
                            <li
                              key={activityIndex}
                              className={`text-sm flex items-start ${
                                session.type === 'teacher'
                                  ? 'text-green-700 dark:text-green-300'
                                  : 'text-blue-700 dark:text-blue-300'
                              }`}
                            >
                              <ArrowRight className="w-3 h-3 mr-2 mt-0.5 flex-shrink-0" />
                              {activity}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Homework/Deliverables */}
                      <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
                        <h5 className="font-medium text-gray-800 dark:text-gray-200 mb-2 flex items-center">
                          <Target className="w-4 h-4 mr-2" />
                          {session.type === 'teacher' ? 'Homework Assignment:' : 'Deliverables:'}
                        </h5>
                        {session.homework && (
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            {session.homework}
                          </p>
                        )}
                        {session.deliverables && (
                          <ul className="space-y-1">
                            {session.deliverables.map((deliverable, delIndex) => (
                              <li
                                key={delIndex}
                                className="text-sm text-gray-700 dark:text-gray-300 flex items-start"
                              >
                                <CheckSquare className="w-3 h-3 mr-2 mt-0.5 flex-shrink-0" />
                                {deliverable}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default LearningPath;