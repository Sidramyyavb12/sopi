'use client'

import React from 'react'
import Image from 'next/image'
import { Star, Clock, Award, Target, Video } from 'lucide-react'
import { Course } from '@/types/course'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/utils'

interface CourseCardProps {
  course: Course
  onEnroll: (course: Course) => void
  onViewDetails: (course: Course) => void
}

export default function CourseCard({ course, onEnroll, onViewDetails }: CourseCardProps) {
  return (
    // Entire card clickable except buttons
    <div
      onClick={() => onViewDetails(course)}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 group hover:-translate-y-1 cursor-pointer relative"
    >
      {/* Prevent click event on buttons from triggering card click */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute inset-0 z-0"
      />

      {/* Card Content */}
      <div className="relative z-10">
        {/* Image */}
        <div className="relative mb-4">
          <Image
            src={course.imageUrl || 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=250&fit=crop'}
            alt={`${course.title} - Online Course by ${course.instructor?.name}`}
            width={400}
            height={200}
            className="w-full h-48 object-cover rounded-lg"
          />
          <div className="absolute top-4 right-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium">
            {course.level}
          </div>
          {course.originalPrice && (
            <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              {Math.round(((course.originalPrice - course.price) / course.originalPrice) * 100)}% OFF
            </div>
          )}
        </div>

        <div className="mb-3">
          <span className="text-xs text-green-600 dark:text-green-400 font-medium uppercase tracking-wide">
            {course.category} • {course.subcategory}
          </span>
        </div>

        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
          {course.title}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">{course.description}</p>

        {/* Instructor Info */}
        <div className="flex items-center mb-4">
          <Image
            src={course.instructor?.image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${course.instructor?.name}`}
            alt={course.instructor?.name || 'Instructor'}
            width={32}
            height={32}
            className="w-8 h-8 rounded-full mr-3"
          />
          <div>
            <p className="text-sm font-medium text-gray-900 dark:text-white">{course.instructor?.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{course.instructor?.studentsCount?.toLocaleString()} students</p>
          </div>
        </div>

        {/* Stats */}
        {/* <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="ml-1 text-sm text-gray-600 dark:text-gray-300 font-medium">{course.rating}</span>
              <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">({course.enrolledCount})</span>
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="ml-1 text-sm text-gray-600 dark:text-gray-300">{course.totalHours || course.duration}</span>
            </div>
          </div>
        </div> */}

        {/* Skills */}
        <div className="mb-4 flex flex-wrap gap-1">
          {course.skills?.slice(0, 3).map((skill, index) => (
            <span key={index} className="px-2 py-1 bg-green-50 dark:bg-green-900 text-green-700 dark:text-green-300 text-xs rounded-full">
              {skill}
            </span>
          ))}
          {course.skills?.length > 3 && (
            <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded-full">
              +{course.skills.length - 3} more
            </span>
          )}
        </div>

        {/* Features */}
        <div className="mb-4 space-y-1">
          {course.hasCertificate && (
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Award className="w-4 h-4 text-green-600 mr-2" />
              <span>Certificate of Completion</span>
            </div>
          )}
          {course.jobPlacementRate && (
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Target className="w-4 h-4 text-blue-600 mr-2" />
              <span>{course.jobPlacementRate}% Job Placement Rate</span>
            </div>
          )}
          {course.features?.includes('Live Sessions') && (
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Video className="w-4 h-4 text-purple-600 mr-2" />
              <span>Live 1-on-1 Sessions</span>
            </div>
          )}
        </div>

        {/* Pricing */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              {formatPrice(course.price)}
            </div>
            {course.originalPrice && (
              <div className="text-lg text-gray-500 dark:text-gray-400 line-through">
                {formatPrice(course.originalPrice)}
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              {course.completionRate}% completion rate
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex space-x-2 z-20 relative">
          <Button
            variant="outline"
            onClick={(e) => {
              e.stopPropagation()
              onViewDetails(course)
            }}
            className="flex-1"
          >
            View Details
          </Button>
          <Button
            onClick={(e) => {
              e.stopPropagation()
              onEnroll(course)
            }}
            className="flex-1"
          >
            Enroll Now
          </Button>
        </div>
      </div>
    </div>
  )
}