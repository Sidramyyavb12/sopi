'use client'

import React, { useState } from 'react'
import Image from 'next/image'
import { 
  X, 
  User, 
  Clock, 
  Users, 
  Star, 
  Award, 
  Shield, 
  Target,
  Loader2
} from 'lucide-react'
import { Course } from '@/types/course'
import { Button } from '../ui/button'
import { formatPrice } from '@/lib/utils'

interface CourseDetailModalProps {
  course: Course | null
  isOpen: boolean
  onClose: () => void
  onEnroll: (course: Course, selectedPath?: string) => void
}

export default function CourseDetailModal({ course, isOpen, onClose, onEnroll }: CourseDetailModalProps) {
  const [isEnrolling, setIsEnrolling] = useState(false)
  
  if (!isOpen || !course) return null

  const handleEnroll = async (selectedPath = 'basic') => {
    setIsEnrolling(true)
    try {
      await onEnroll(course, selectedPath)
    } catch (error) {
      console.error('Enrollment failed:', error)
    } finally {
      setIsEnrolling(false)
    }
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{course.title}</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <Image
                src={course.imageUrl || 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=250&fit=crop'}
                alt={course.title}
                width={400}
                height={250}
                className="w-full h-64 object-cover rounded-lg mb-6"
              />
              
              <div className="space-y-6">
                {course.learningPaths && course.learningPaths.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Learning Paths</h3>
                    <div className="space-y-3">
                      {course.learningPaths.map((path, index) => (
                        <div key={path} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                          <div className="flex items-center">
                            <Target className="w-5 h-5 text-green-600 mr-2" />
                            <span className="font-medium text-gray-900 dark:text-white">{path}</span>
                          </div>
                          <span className="text-sm text-gray-600 dark:text-gray-300">
                            {formatPrice(course.price + (index * 100))}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Course Description</h3>
                  <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
                    <p className="text-gray-700 dark:text-gray-300">
                      {course.fullDescription || course.description}
                    </p>
                  </div>
                </div>

                {course.curriculum && course.curriculum.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Curriculum</h3>
                    <div className="space-y-2">
                      {course.curriculum.map((item, index) => (
                        <div key={index} className="flex items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                          <span className="w-6 h-6 bg-green-600 text-white text-xs rounded-full flex items-center justify-center mr-3">
                            {index + 1}
                          </span>
                          <span className="text-gray-700 dark:text-gray-300">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Course Details</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <User className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-700 dark:text-gray-300">
                      Instructor: {course.instructor?.name || 'TBD'}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-700 dark:text-gray-300">Duration: {course.duration}</span>
                  </div>
                  {/* <div className="flex items-center">
                    <Users className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-700 dark:text-gray-300">{course.enrolledCount} students enrolled</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="w-5 h-5 text-yellow-400 mr-3" />
                    <span className="text-gray-700 dark:text-gray-300">Rating: {course.rating}/5</span>
                  </div> */}
                </div>
              </div>

              {/* Skills */}
              {course.skills && course.skills.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Skills You'll Learn</h3>
                  <div className="flex flex-wrap gap-2">
                    {course.skills.map((skill, index) => (
                      <span 
                        key={index} 
                        className="px-3 py-1 bg-blue-50 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-sm rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              {course.hasCertificate && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Certificate</h3>
                  <div className="p-4 border-2 border-dashed border-green-300 dark:border-green-600 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Award className="w-5 h-5 text-green-600 mr-2" />
                      <span className="font-medium text-gray-900 dark:text-white">Verifiable Certificate</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      Receive a signed, blockchain-verified certificate upon completion
                    </p>
                  </div>
                </div>
              )}
              
              {course.hasProctoring && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Proctored Exam</h3>
                  <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Shield className="w-5 h-5 text-blue-600 mr-2" />
                      <span className="font-medium text-gray-900 dark:text-white">Online Proctored Assessment</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      Enhance your market value with our secure, monitored final exam
                    </p>
                  </div>
                </div>
              )}
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Pricing Options</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <span className="text-gray-700 dark:text-gray-300">Self-Paced Learning</span>
                    <span className="font-bold text-green-600 dark:text-green-400">{formatPrice(course.price)}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <span className="text-gray-700 dark:text-gray-300">1-on-1 Live Sessions</span>
                    <span className="font-bold text-green-600 dark:text-green-400">{formatPrice(course.price + 200)}</span>
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={() => handleEnroll()}
                loading={isEnrolling}
                className="w-full"
                size="lg"
              >
                Enroll Now
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}