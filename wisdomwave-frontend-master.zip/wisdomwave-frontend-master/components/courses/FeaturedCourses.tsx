'use client'

import React, { useRef } from 'react'
import Link from 'next/link'
import { CheckCircle, Star, Users, Clock, ChevronLeft, ChevronRight, TrendingUp, Award } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { allCourses } from '@/lib/courseData'

interface EnhancedCourse {
  id: string
  title: string
  description: string
  level: string
  duration: string
  students: number
  price: number
  originalPrice: number
  rating: number
  reviews: number
  skills: string[]
  categoryName: string
  categoryIcon: string
  categoryColor: string
}

interface FeaturedCoursesProps {
  onCourseSelect?: (course: any, selectedPath?: string) => void
  onCourseDetails?: (course: any) => void
}

const getCategorySlug = (categoryName: string) =>
  categoryName.toLowerCase().replace(/\s+/g, '-').replace(/&/g, '').replace(/[^a-z0-9-]/g, '')

export default function FeaturedCourses({ onCourseSelect, onCourseDetails }: FeaturedCoursesProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const getFeaturedCourses = (): EnhancedCourse[] => {
    const featuredCourses: EnhancedCourse[] = []
    Object.values(allCourses).forEach(category => {
      category.courses.forEach(course => {
        if (course.students && course.rating && course.price) {
          featuredCourses.push({
            ...course,
            categoryName: category.name,
            categoryIcon: category.icon,
            categoryColor: category.color
          })
        }
      })
    })

    const sortedCourses = featuredCourses.sort((a, b) => {
      const scoreA = a.rating * 0.6 + (a.students / 1000) * 0.4
      const scoreB = b.rating * 0.6 + (b.students / 1000) * 0.4
      return scoreB - scoreA
    })

    const aiCourses = sortedCourses.filter(c => c.categoryName === 'AI & Machine Learning')
    const nonAiCourses = sortedCourses.filter(c => c.categoryName !== 'AI & Machine Learning')
    const trending = []
    if (aiCourses.length > 0) trending.push(aiCourses[0])
    trending.push(...nonAiCourses.slice(0, 2))

    return [...trending, ...sortedCourses.filter(c => !trending.some(t => t.id === c.id))]
  }

  const allFeaturedCourses = getFeaturedCourses()
  const top3Courses = allFeaturedCourses.slice(0, 3)
  const horizontalCourses = allFeaturedCourses.slice(3, 15)

  const scroll = (dir: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === 'left' ? -400 : 400, behavior: 'smooth' })
    }
  }

  const formatStudents = (students: number) =>
    students >= 1000 ? `${(students / 1000).toFixed(1)}K+` : `${students}+`

  const getCourseUrl = (course: EnhancedCourse) => {
    const categorySlug = getCategorySlug(course.categoryName)
    return `/courses/${categorySlug}/${course.id}`
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 via-green-50/30 to-blue-50/30 dark:from-gray-900 dark:via-green-950/30 dark:to-blue-950/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-green-100 to-blue-100 dark:from-green-900/50 dark:to-blue-900/50 text-green-800 dark:text-green-200 rounded-full text-sm font-medium mb-6">
            <TrendingUp className="w-4 h-4 mr-2" />
            Most Popular Courses - Updated January 2025
          </div>
          <h2 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Featured Courses
            <span className="block text-3xl text-green-600 dark:text-green-400 mt-2">
              Learn from Industry Experts
            </span>
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-8">
            Master in-demand skills with our most popular courses — from <strong>AI & ML</strong> to <strong>Full-Stack Development</strong>.
          </p>
        </div>

        {/* Top 3 Trending */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-10">🔥 Trending Now</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {top3Courses.map((course, index) => (
              <Link key={course.id} href={getCourseUrl(course)} className="block group">
                <div
                  className={`relative overflow-hidden rounded-2xl shadow-2xl transform group-hover:scale-105 transition-all duration-300 cursor-pointer ${
                    index === 0
                      ? 'bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500'
                      : index === 1
                      ? 'bg-gradient-to-br from-green-400 via-blue-500 to-purple-600'
                      : 'bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600'
                  }`}
                >
                  <div className="absolute top-4 left-4 bg-white/90 px-3 py-1 rounded-full text-gray-900 text-sm font-bold">
                    #{index + 1} Trending
                  </div>
                  <div className="absolute top-4 right-4 text-3xl">{course.categoryIcon}</div>

                  <div className="p-8 text-white relative z-10">
                    <div className="mb-4">
                      <div className="text-sm text-white/80 mb-1">{course.categoryName}</div>
                      <h4 className="text-2xl font-bold mb-2 group-hover:text-yellow-200 transition">
                        {course.title}
                      </h4>
                      <p className="text-sm text-white/90 line-clamp-2">{course.description}</p>
                    </div>

                    <div className="flex items-center justify-between text-sm text-white/90 mb-6">
                      <div className="flex space-x-4">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-300 mr-1 fill-current" />
                          {course.rating}
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {formatStudents(course.students)}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {course.duration}
                        </div>
                      </div>
                    </div>

                    <Button
                      className="bg-white text-gray-900 hover:bg-white/90 font-semibold px-8 py-3 group-hover:scale-105 transition-transform"
                      onClick={(e) => e.preventDefault()}
                    >
                      View Course
                    </Button>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Horizontal Scroll Courses */}
        <div className="mb-20">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white">All Featured Courses</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => scroll('left')} className="rounded-full">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => scroll('right')} className="rounded-full">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div
            ref={scrollRef}
            className="flex space-x-6 overflow-x-auto pb-4 scrollbar-hide"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {horizontalCourses.map((course) => (
              <Link
                key={course.id}
                href={getCourseUrl(course)}
                className="flex-none w-80 bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-200 dark:border-gray-700 cursor-pointer group"
              >
                <div className="p-6">
                  <div className="flex justify-between mb-4">
                    <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200">
                      <span className="mr-1">{course.categoryIcon}</span>
                      {course.categoryName}
                    </div>
                    <div className="flex items-center text-yellow-500">
                      <Star className="w-4 h-4 mr-1 fill-current" />
                      <span className="font-semibold text-sm">{course.rating}</span>
                    </div>
                  </div>

                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2 line-clamp-2">
                    {course.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-2">
                    {course.description}
                  </p>

                  <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-1" /> {formatStudents(course.students)}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" /> {course.duration}
                    </div>
                    <span className="text-green-600 dark:text-green-400 font-medium">{course.level}</span>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {course.skills.slice(0, 3).map((s, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-md"
                      >
                        {s}
                      </span>
                    ))}
                    {course.skills.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-500 text-xs rounded-md">
                        +{course.skills.length - 3}
                      </span>
                    )}
                  </div>

                  {/* Buttons (no double navigation) */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={(e) => e.preventDefault()}
                    >
                      View Details
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 bg-green-600 hover:bg-green-700 text-xs"
                      onClick={(e) => e.preventDefault()}
                    >
                      Enroll Now
                    </Button>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
  <div className="bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 rounded-3xl p-12 text-white relative overflow-hidden">
    <h3 className="text-4xl font-bold mb-4 relative z-10">Ready to Transform Your Career?</h3>
    <p className="text-lg text-white/90 mb-8 max-w-3xl mx-auto relative z-10">
      Join over 50,000 learners who’ve advanced their careers with SOPHIRAY.
    </p>
    <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
      
      {/* Primary Button */}
      <Link href="/courses">
        <Button
          size="lg"
          className="bg-white text-gray-900 hover:bg-white/90 font-semibold px-8 py-4 transform hover:scale-105 transition-all duration-300 shadow-md hover:shadow-lg"
        >
          Browse All Courses
        </Button>
      </Link>

      {/* Secondary Button (updated hover effect) */}
      <Link href="/contact">
        <Button
          variant="outline"
          size="lg"
          className="border-2 border-white text-white bg-transparent hover:bg-white hover:text-gray-900 font-semibold px-8 py-4 transform hover:scale-105 transition-all duration-300 shadow-md hover:shadow-lg"
        >
          Book Free Consultation
        </Button>
      </Link>

    </div>
  </div>
</div>

      </div>
    </section>
  )
}