'use client'

import React from 'react'
import { 
  BookOpen, 
  Video, 
  CheckCircle, 
  TrendingUp 
} from 'lucide-react'
import { Button } from '../ui/button'

interface HeroSectionProps {
  onExploreClick: () => void
  onDemoClick: () => void
}

export default function HeroSection({ onExploreClick, onDemoClick }: HeroSectionProps) {
  return (
    <section className="relative bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-900 dark:to-gray-800 py-20 overflow-hidden">
      <div className="absolute inset-0 bg-wave-pattern opacity-10"></div>
      
      {/* Background Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-green-200 dark:bg-green-800 rounded-full opacity-20 animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-green-300 dark:bg-green-700 rounded-full opacity-20 animate-pulse delay-1000"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full text-sm font-medium mb-6">
            <TrendingUp className="w-4 h-4 mr-2" />
            #1 Rated Online Learning Platform - Join 1000+ Students
          </div>
          
          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
            Illuminate Your Path with
            <span className="text-green-600 dark:text-green-400"> Sophiray</span>
            <br />
            <span className="text-2xl md:text-4xl text-gray-700 dark:text-gray-300 font-normal">
              Transform Your Career with Expert 1-on-1 Learning
            </span>
          </h1>
          
          {/* Description */}
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed">
            Master in-demand skills like <strong>Web Development</strong>, <strong>Data Science</strong>, 
            <strong> Digital Marketing</strong>, and <strong>Cybersecurity</strong> with personalized instruction from 
            industry experts at Google, Meta, Tesla, and Microsoft. Build your network and gain direct access to 
            top-tier engineers for referrals and career opportunities.
          </p>

          {/* Key Benefits */}
          <div className="flex flex-wrap justify-center gap-6 mb-8 text-sm">
            <div className="flex items-center text-gray-700 dark:text-gray-300">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span>Live 1-on-1 Sessions with Experts</span>
            </div>
            <div className="flex items-center text-gray-700 dark:text-gray-300">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span>Industry-Recognized Certificates</span>
            </div>
            <div className="flex items-center text-gray-700 dark:text-gray-300">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span>Exclusive Referral Opportunities</span>
            </div>
            <div className="flex items-center text-gray-700 dark:text-gray-300">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span>Career Guidance & Mentorship</span>
            </div>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button 
              size="xl"
              onClick={onExploreClick}
              className="bg-green-600 text-white hover:bg-green-700 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Explore 50+ Courses
            </Button>
            <Button 
              size="xl"
              variant="outline"
              onClick={onDemoClick}
              className="border-2 border-green-600 text-green-600 hover:bg-green-50 dark:hover:bg-green-900"
            >
              <Video className="w-5 h-5 mr-2" />
              Book Demo Class
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Trusted by students from leading companies
            </p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
              <div className="text-gray-400 font-semibold">Google</div>
              <div className="text-gray-400 font-semibold">Microsoft</div>
              <div className="text-gray-400 font-semibold">Amazon</div>
              <div className="text-gray-400 font-semibold">Meta</div>
              <div className="text-gray-400 font-semibold">Netflix</div>
              <div className="text-gray-400 font-semibold">Tesla</div>
            </div>
          </div>

          {/* Social Proof */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {/* <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">4.9/5</div>
              <div className="text-gray-600 dark:text-gray-300 text-sm">
                Average course rating from 1000+ reviews
              </div>
            </div> */}
            {/* <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">1K+</div>
              <div className="text-gray-600 dark:text-gray-300 text-sm">
                Students enrolled and learning actively
              </div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">500+</div>
              <div className="text-gray-600 dark:text-gray-300 text-sm">
                Top-tier engineers in our referral network
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </section>
  )
}