'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { useRouter, usePathname } from 'next/navigation'
import { 
  BookOpen, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  LogOut, 
  User,
  Home,
  GraduationCap,
  MessageCircle,
  Info,
  Map,
  Mic
} from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { useTheme } from '@/hooks/useTheme'
import { Button } from '@/components/ui/button'

export default function Navigation() {
  const { user, logout } = useAuth()
  const { isDark, toggleTheme } = useTheme()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  // Wait for component to mount before rendering user-dependent content
  useEffect(() => {
    setIsMounted(true)
  }, [])

  const handleLogout = async () => {
    try {
      await logout()
      router.push('/')
    } catch (error) {
      console.error('Logout failed:', error)
    }
  }

  const navItems = [
    { 
      label: 'Home', 
      href: '/', 
      icon: Home 
    },
    { 
      label: 'Courses', 
      href: '/courses', 
      icon: GraduationCap 
    },
    { 
      label: 'Learning Paths', 
      href: '/learning-paths', 
      icon: Map 
    },
    { 
      label: 'Mock Interview', 
      href: '/mock-interview', 
      icon: Mic 
    },
    { 
      label: 'About', 
      href: '/about', 
      icon: Info 
    },
    { 
      label: 'Contact', 
      href: '/contact', 
      icon: MessageCircle 
    },
  ]

  const closeMenu = () => setIsMenuOpen(false)

  const isActivePath = (href: string) => {
    if (href === '/') {
      return pathname === href
    }
    return pathname.startsWith(href)
  }

  const getDashboardUrl = () => {
    return user?.role === 'INSTRUCTOR' ? '/dashboard/instructor' : '/dashboard/learner'
  }

  return (
    <nav className="bg-gradient-to-r from-slate-50 via-green-50 to-emerald-50 dark:from-gray-900 dark:via-green-950 dark:to-emerald-950 shadow-xl backdrop-blur-md sticky top-0 z-50 border-b border-green-200/30 dark:border-green-700/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3 group">
            <Image 
              src="/logo.png" 
              alt="Sophiray Logo" 
              width={32}
              height={32}
              className="object-contain group-hover:scale-110 transition-transform duration-300 drop-shadow-md"
              priority
            />
            <div className="relative">
              <span className="text-3xl font-black tracking-tight relative">
                <span className="bg-gradient-to-r from-gray-800 to-gray-600 dark:from-gray-200 dark:to-gray-400 bg-clip-text text-transparent">
                  SOPHI
                </span>
                <span className="bg-gradient-to-r from-green-600 via-green-500 to-emerald-500 dark:from-green-400 dark:via-green-300 dark:to-emerald-300 bg-clip-text text-transparent">
                  RAY
                </span>
              </span>
              <div className="absolute -inset-1 bg-gradient-to-r from-green-600/20 to-emerald-600/20 dark:from-green-400/20 dark:to-emerald-400/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => {
              const isActive = isActivePath(item.href)
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`font-medium transition-colors ${
                    isActive
                      ? 'text-green-600 dark:text-green-400'
                      : 'text-gray-700 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400'
                  }`}
                >
                  {item.label}
                </Link>
              )
            })}

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>

            {/* User Section - Only render after mount */}
            {isMounted && (
              <>
                {user ? (
                  <div className="flex items-center space-x-4">
                    <img
                      src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`}
                      alt={user.name}
                      className="w-8 h-8 rounded-full"
                    />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {user.name}
                    </span>
                    <Link
                      href={getDashboardUrl()}
                      className="text-green-600 hover:text-green-700 text-sm font-medium"
                    >
                      Dashboard
                    </Link>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleLogout}
                      title="Logout"
                    >
                      <LogOut className="w-5 h-5" />
                    </Button>
                  </div>
                ) : (
                  <Link href="/login">
                    <Button className="bg-green-600 hover:bg-green-700 text-white">Sign In</Button>
                  </Link>
                )}
              </>
            )}

            {/* Placeholder to prevent layout shift */}
            {!isMounted && (
              <div className="w-40 h-10" />
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-gradient-to-r from-slate-50 via-green-50 to-emerald-50 dark:from-gray-900 dark:via-green-950 dark:to-emerald-950 border-t border-green-200/40 dark:border-green-700/40 backdrop-blur-md">
          <div className="px-4 py-2 space-y-2">
            {navItems.map((item) => {
              const IconComponent = item.icon
              const isActive = isActivePath(item.href)
              
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={closeMenu}
                  className={`flex items-center space-x-3 py-3 transition-colors ${
                    isActive
                      ? 'text-green-600 dark:text-green-400'
                      : 'text-gray-700 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{item.label}</span>
                </Link>
              )
            })}

            <div className="flex items-center justify-between py-3">
              <span className="text-gray-700 dark:text-gray-300">Theme</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
            </div>

            {/* Only render user section after mount */}
            {isMounted && (
              <>
                {user ? (
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-2">
                    <div className="flex items-center space-x-3 py-3">
                      <img
                        src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`}
                        alt={user.name}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">
                          {user.name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {user.role}
                        </div>
                      </div>
                    </div>

                    <Link
                      href={getDashboardUrl()}
                      onClick={closeMenu}
                      className="flex items-center space-x-3 py-3 text-green-600 hover:text-green-700"
                    >
                      <User className="w-5 h-5" />
                      <span>Dashboard</span>
                    </Link>

                    <button
                      onClick={() => {
                        handleLogout()
                        closeMenu()
                      }}
                      className="flex items-center space-x-3 py-3 text-red-600 hover:text-red-700 w-full text-left"
                    >
                      <LogOut className="w-5 h-5" />
                      <span>Logout</span>
                    </button>
                  </div>
                ) : (
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-2">
                    <Link href="/login" onClick={closeMenu}>
                      <Button className="w-full bg-green-600 hover:bg-green-700 text-white">Sign In</Button>
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}