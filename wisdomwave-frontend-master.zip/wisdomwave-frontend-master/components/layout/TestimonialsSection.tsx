'use client'

import React from 'react'
import { Star } from 'lucide-react'

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Shreya Gupta",
      role: "Software Developer",
      content: "Sophiray transformed my career. The 1-on-1 sessions were incredibly valuable.",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=alex",
      rating: 5
    },
    {
      name: "Raj Nath Singh",
      role: "SAP Consultant",
      content: "The personalized learning approach helped me land my dream job in just 3 months.",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=maria",
      rating: 5
    },
    {
      name: "Ashok Kumar",
      role: "Data Scientist",
      content: "Outstanding instructors and comprehensive curriculum. Highly recommended!",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=david",
      rating: 5
    }
  ]
  
  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">What Our Students Say</h2>
          <p className="text-gray-600 dark:text-gray-300">Real stories from real students</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-4">"{testimonial.content}"</p>
              <div className="flex items-center">
                <img src={testimonial.avatar} alt={testimonial.name} className="w-10 h-10 rounded-full mr-3" />
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">{testimonial.name}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}