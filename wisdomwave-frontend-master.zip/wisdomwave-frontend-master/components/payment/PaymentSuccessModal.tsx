// components/payment/PaymentSuccessModal.tsx
'use client'

import React, { useEffect } from 'react'
import { CheckCircle, X, Award, CreditCard, Calendar, ExternalLink } from 'lucide-react'

interface PaymentSuccessModalProps {
  isOpen: boolean
  onClose: () => void
  type: 'course' | 'interview'
  data: {
    title: string
    enrollmentId?: number
    bookingId?: number
    paymentId: string
    status: string
    redirectPath?: string
  }
}

export default function PaymentSuccessModal({ 
  isOpen, 
  onClose, 
  type, 
  data 
}: PaymentSuccessModalProps) {
  
  // Auto-close after 5 seconds
  useEffect(() => {
    if (isOpen && data.redirectPath) {
      const timer = setTimeout(() => {
        window.location.href = data.redirectPath!
      }, 5000)
      
      return () => clearTimeout(timer)
    }
  }, [isOpen, data.redirectPath])

  if (!isOpen) return null

  const handleRedirect = () => {
    if (data.redirectPath) {
      window.location.href = data.redirectPath
    } else {
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 animate-fadeIn">
      <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-md w-full shadow-2xl transform animate-scaleIn">
        {/* Success Icon Header */}
        <div className="relative pt-12 pb-6">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          
          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-75"></div>
              <div className="relative bg-gradient-to-br from-green-400 to-green-600 w-24 h-24 rounded-full flex items-center justify-center shadow-lg">
                <CheckCircle className="w-14 h-14 text-white" strokeWidth={2.5} />
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="px-8 pb-8">
          <h2 className="text-2xl font-bold text-center text-gray-900 dark:text-white mb-2">
            🎉 Payment Successful!
          </h2>
          
          <p className="text-center text-gray-600 dark:text-gray-300 mb-6">
            {type === 'course' 
              ? `You are now enrolled in` 
              : `Your interview has been booked!`
            }
          </p>

          {/* Details Card */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl p-6 mb-6 border border-green-200 dark:border-green-800">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4 text-lg">
              {data.title}
            </h3>
            
            <div className="space-y-3">
              {type === 'course' && data.enrollmentId && (
                <div className="flex items-center text-sm">
                  <Award className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                  <div>
                    <div className="text-gray-500 dark:text-gray-400 text-xs">Enrollment ID</div>
                    <div className="font-semibold text-gray-900 dark:text-white">
                      #{data.enrollmentId}
                    </div>
                  </div>
                </div>
              )}
              
              {type === 'interview' && data.bookingId && (
                <div className="flex items-center text-sm">
                  <Calendar className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                  <div>
                    <div className="text-gray-500 dark:text-gray-400 text-xs">Booking ID</div>
                    <div className="font-semibold text-gray-900 dark:text-white">
                      #{data.bookingId}
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex items-center text-sm">
                <CreditCard className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                <div>
                  <div className="text-gray-500 dark:text-gray-400 text-xs">Payment ID</div>
                  <div className="font-mono text-xs text-gray-900 dark:text-white break-all">
                    {data.paymentId}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Success Message */}
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mb-6 border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              {type === 'course' 
                ? `✨ You can now access all course materials and start learning. Check your email for a confirmation.`
                : `📧 You will receive a confirmation email with meeting details shortly. Check your inbox!`
              }
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
            >
              Close
            </button>
            <button
              onClick={handleRedirect}
              className="flex-1 bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center"
            >
              <span>Go to Dashboard</span>
              <ExternalLink className="w-4 h-4 ml-2" />
            </button>
          </div>

          {/* Auto-redirect message */}
          {data.redirectPath && (
            <p className="text-center text-xs text-gray-500 dark:text-gray-400 mt-4">
              Redirecting in 5 seconds...
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

// Add these animations to your globals.css
/*
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes scaleIn {
  from { transform: scale(0.9); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

.animate-fadeIn {
  animation: fadeIn 0.3s ease-out;
}

.animate-scaleIn {
  animation: scaleIn 0.3s ease-out;
}
*/