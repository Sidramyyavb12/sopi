'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'
import { ApiService } from '@/lib/api'
import { AuthUtils } from '@/lib/auth'
import { 
  User, 
  LoginCredentials, 
  RegisterData, 
  AuthContextType,
  LoginResponse,
  extractUserFromResponse,
  extractTokenFromResponse,
  extractRefreshTokenFromResponse
} from '@/types/auth'

export const AuthContext = createContext<AuthContextType | undefined>(undefined)

interface AuthProviderProps {
  children: React.ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  // 🔥 CRITICAL FIX: Initialize user from localStorage IMMEDIATELY
  const [user, setUser] = useState<User | null>(() => {
    // Only run on client side
    if (typeof window === 'undefined') {
      console.log('⚠️ Server-side render, skipping user init')
      return null
    }
    
    try {
      const token = localStorage.getItem('wisdomwave_token')
      const userData = localStorage.getItem('wisdomwave_user')
      
      console.log('🎯 AuthProvider Initial Setup:', {
        hasToken: !!token,
        hasUserData: !!userData
      })
      
      if (token && userData) {
        try {
          const parsedUser = JSON.parse(userData)
          console.log('✅ IMMEDIATELY restored user from localStorage:', parsedUser.role, parsedUser.email)
          return parsedUser
        } catch (parseError) {
          console.error('❌ Failed to parse user data:', parseError)
          // Clear corrupted data
          localStorage.removeItem('wisdomwave_user')
          localStorage.removeItem('wisdomwave_token')
        }
      } else {
        console.log('ℹ️ No saved session found')
      }
    } catch (error) {
      console.error('❌ Error during initial user restore:', error)
    }
    
    return null
  })
  
  // 🔥 FIX: Start with false since we initialize user immediately above
  const [isLoading, setIsLoading] = useState(false)
  const [isAuthenticating, setIsAuthenticating] = useState(false)

  // Verify session and optionally sync with server - RUNS ONLY ONCE
  useEffect(() => {
    console.group('🔍 Auth Session Verification')
    
    const verifySession = async () => {
      try {
        const token = AuthUtils.getStoredToken()
        const savedUser = AuthUtils.getStoredUser()

        console.log('📦 Checking stored data:', {
          hasToken: !!token,
          hasUser: !!savedUser,
          currentUserState: user ? `${user.name} (${user.role})` : 'null'
        })

        if (token && savedUser && !AuthUtils.isTokenExpired(token)) {
          console.log('✅ Valid session exists')
          
          // Safety check: If user state is null but localStorage has valid data
          if (!user) {
            console.log('🔄 User state was null, forcing restore from localStorage')
            setUser(savedUser)
          }
          
          // Optional: Verify with server in background (doesn't block UI)
          try {
            console.log('🔄 Verifying session with server...')
            const response = await ApiService.getCurrentUser()
            console.log('✅ Server verification successful, raw response:', response)
            
            // Extract user from response (might be wrapped)
            let serverUser: User = response as User
            
            // Check if response is wrapped in API format
            if (response && typeof response === 'object' && 'data' in response) {
              const apiResponse = response as { data: User }
              serverUser = apiResponse.data
              console.log('🔧 Extracted user from response.data')
            }
            
            // Update if server data is different
            if (JSON.stringify(serverUser) !== JSON.stringify(savedUser)) {
              console.log('🔧 Server has updated user data, syncing...')
              console.log('Server user:', serverUser)
              setUser(serverUser)
              AuthUtils.setAuthData(token, serverUser)
            } else {
              console.log('✅ User data is up to date, no sync needed')
            }
          } catch (verifyError) {
            console.warn('⚠️ Server verification failed (keeping cached user):', verifyError)
            // Don't clear auth - network errors shouldn't log out users
          }
        } else if (token && AuthUtils.isTokenExpired(token)) {
          console.log('⏰ Token expired, clearing session')
          AuthUtils.clearAuthData()
          setUser(null)
        } else if (!token || !savedUser) {
          console.log('ℹ️ No valid session found')
          AuthUtils.clearAuthData()
          setUser(null)
        }
      } catch (error) {
        console.error('❌ Session verification error:', error)
        // On error, try to keep the user if they were already loaded
        if (!user) {
          AuthUtils.clearAuthData()
          setUser(null)
        }
      } finally {
        setIsLoading(false)
        console.log('✅ Session verification complete')
        console.log('👤 Final user state:', user ? `${user.name} (${user.role})` : 'Not logged in')
        console.groupEnd()
      }
    }

    verifySession()
  }, []) // Only run once on mount

  // Debug log when user changes
  useEffect(() => {
    if (user) {
      console.log('👤 User state updated:', user.name, user.role, user.email)
    } else {
      console.log('👤 User state cleared')
    }
  }, [user])

  const login = async (credentials: LoginCredentials): Promise<LoginResponse> => {
    setIsAuthenticating(true)
    
    console.group('🔐 Login Process')
    console.log('📧 Logging in:', credentials.email)
    
    try {
      const response = await ApiService.login(credentials)
      console.log('📦 Login API response received')
      
      const user = extractUserFromResponse(response)
      const token = extractTokenFromResponse(response)
      const refreshToken = extractRefreshTokenFromResponse(response)
      
      console.log('📤 Extracted data:', {
        hasUser: !!user,
        hasToken: !!token,
        userRole: user?.role,
        userName: user?.name
      })
      
      if (!user || !token) {
        throw new Error('Invalid login response: missing user data or token')
      }
      
      // Save to localStorage
      console.log('💾 Saving auth data to localStorage...')
      AuthUtils.setAuthData(token, user, refreshToken || undefined)
      
      // Update state
      console.log('🔄 Updating user state...')
      setUser(user)
      
      console.log('✅ Login successful!', user.role, user.email)
      console.groupEnd()
      
      return response
    } catch (error) {
      console.error('❌ Login failed:', error)
      console.groupEnd()
      throw error
    } finally {
      setIsAuthenticating(false)
    }
  }

  const register = async (userData: RegisterData): Promise<LoginResponse> => {
    setIsAuthenticating(true)
    
    console.group('📝 Registration Process')
    
    try {
      const response = await ApiService.register(userData)
      
      const user = extractUserFromResponse(response)
      const token = extractTokenFromResponse(response)
      const refreshToken = extractRefreshTokenFromResponse(response)
      
      if (!user || !token) {
        throw new Error('Invalid registration response: missing user data or token')
      }
      
      AuthUtils.setAuthData(token, user, refreshToken || undefined)
      setUser(user)
      
      console.log('✅ Registration successful:', user.role)
      console.groupEnd()
      
      return response
    } catch (error) {
      console.error('❌ Registration failed:', error)
      console.groupEnd()
      throw error
    } finally {
      setIsAuthenticating(false)
    }
  }

  const loginWithGoogle = async (googleToken: string): Promise<LoginResponse> => {
    setIsAuthenticating(true)
    
    console.group('🔐 Google Login Process')
    
    try {
      const response = await ApiService.loginWithGoogle(googleToken)
      
      const user = extractUserFromResponse(response)
      const token = extractTokenFromResponse(response)
      const refreshToken = extractRefreshTokenFromResponse(response)
      
      if (!user || !token) {
        throw new Error('Invalid Google login response: missing user data or token')
      }
      
      AuthUtils.setAuthData(token, user, refreshToken || undefined)
      setUser(user)
      
      console.log('✅ Google login successful:', user.role)
      console.groupEnd()
      
      return response
    } catch (error) {
      console.error('❌ Google login failed:', error)
      console.groupEnd()
      throw error
    } finally {
      setIsAuthenticating(false)
    }
  }

  const logout = async (): Promise<void> => {
    console.group('🚪 Logout Process')
    
    try {
      console.log('📡 Calling logout API...')
      await ApiService.logout()
      console.log('✅ Logout API successful')
    } catch (error) {
      console.warn('⚠️ Logout API failed (clearing local data anyway):', error)
    } finally {
      console.log('🗑️ Clearing auth data from localStorage')
      AuthUtils.clearAuthData()
      setUser(null)
      console.log('✅ Logout completed')
      console.groupEnd()
    }
  }

  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticating,
    register,
    login,
    loginWithGoogle,
    logout
  }

  console.log('🔄 AuthProvider rendering, user:', user ? `${user.name} (${user.role})` : 'null', 'isLoading:', isLoading)

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}