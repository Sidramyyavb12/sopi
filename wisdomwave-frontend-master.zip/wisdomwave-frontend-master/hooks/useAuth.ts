'use client'

import { useContext } from 'react'
import { AuthContext } from '@/components/providers/AuthProvider'
import { AuthContextType } from '@/types/auth'

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

// Additional auth hooks for convenience
export function useUser() {
  const { user } = useAuth()
  return user
}

export function useIsAuthenticated() {
  const { user } = useAuth()
  return !!user
}

export function useIsRole(role: 'LEARNER' | 'INSTRUCTOR' | 'ADMIN') {
  const { user } = useAuth()
  return user?.role === role
}

export function useIsLearner() {
  return useIsRole('LEARNER')
}

export function useIsInstructor() {
  return useIsRole('INSTRUCTOR')
}

export function useIsAdmin() {
  return useIsRole('ADMIN')
}