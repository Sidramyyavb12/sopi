'use client'

import { useState, useEffect } from 'react'
import { ApiService } from '@/lib/api'
import { Course, CourseSearchParams } from '@/types/course'

export function useCourses(params: CourseSearchParams = {}) {
  const [courses, setCourses] = useState<Course[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [total, setTotal] = useState(0)

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        setIsLoading(true)
        setError(null)
        const response = await ApiService.getCourses(params)
        setCourses(response.data || response)
        setTotal(response.total || (response.data || response).length)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch courses')
        setCourses([])
      } finally {
        setIsLoading(false)
      }
    }

    fetchCourses()
  }, [JSON.stringify(params)])

  const refetch = () => {
    setIsLoading(true)
    // Trigger useEffect by updating params
  }

  return {
    courses,
    isLoading,
    error,
    total,
    refetch
  }
}

export function useCourse(courseId: string) {
  const [course, setCourse] = useState<Course | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!courseId) return

    const fetchCourse = async () => {
      try {
        setIsLoading(true)
        setError(null)
        const courseData = await ApiService.getCourseById(courseId)
        setCourse(courseData)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch course')
        setCourse(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCourse()
  }, [courseId])

  return {
    course,
    isLoading,
    error
  }
}

export function useEnrolledCourses() {
  const [courses, setCourses] = useState<Course[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      try {
        setIsLoading(true)
        setError(null)
        const coursesData = await ApiService.getEnrolledCourses()
        setCourses(coursesData)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch enrolled courses')
        setCourses([])
      } finally {
        setIsLoading(false)
      }
    }

    fetchEnrolledCourses()
  }, [])

  return {
    courses,
    isLoading,
    error
  }
}

export function useCourseEnrollment() {
  const [isEnrolling, setIsEnrolling] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const enrollInCourse = async (courseId: string, enrollmentData: any) => {
    try {
      setIsEnrolling(true)
      setError(null)
      await ApiService.enrollInCourse(courseId, enrollmentData)
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to enroll in course')
      return false
    } finally {
      setIsEnrolling(false)
    }
  }

  return {
    enrollInCourse,
    isEnrolling,
    error
  }
}