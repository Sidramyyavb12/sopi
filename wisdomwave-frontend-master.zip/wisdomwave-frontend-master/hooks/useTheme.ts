'use client'

import { useContext } from 'react'
import { ThemeContext } from '@/components/providers/ThemeProvider'

interface ThemeContextType {
  isDark: boolean
  toggleTheme: () => void
}

export function useTheme(): ThemeContextType {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}

// Additional theme utilities
export function useIsDarkMode() {
  const { isDark } = useTheme()
  return isDark
}

export function useToggleTheme() {
  const { toggleTheme } = useTheme()
  return toggleTheme
}