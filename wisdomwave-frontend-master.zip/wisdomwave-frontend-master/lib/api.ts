// lib/api.ts - COMPLETE UPDATED VERSION with Contact Endpoints

import { 
  LoginCredentials, 
  RegisterData, 
  LoginResponse 
} from '@/types/auth'
import { 
  Course, 
  CourseSearchParams, 
  EnrollmentData 
} from '@/types/course'
import { 
  UserProfile, 
  LearnerDashboard, 
  InstructorDashboard, 
  ContactFormData 
} from '@/types/user'

// API Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'https://api.sophiray.com/api'
// const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';

interface ApiRequestOptions extends RequestInit {
  headers?: Record<string, string>
  skipAutoRedirect?: boolean
}

export class ApiService {
  private static getAuthToken(): string | null {
    if (typeof window === 'undefined') return null
    return localStorage.getItem('wisdomwave_token')
  }

  private static logRequest(endpoint: string, options: ApiRequestOptions, token: string | null) {
    console.group(`🚀 API Request: ${options.method || 'GET'} ${endpoint}`)
    console.log('📍 Full URL:', `${API_BASE_URL}${endpoint}`)
    console.log('🔑 Auth Token:', token ? `${token.substring(0, 20)}...` : 'None')
    console.log('📦 Headers:', options.headers)
    if (options.body) {
      console.log('📝 Request Body:', JSON.parse(options.body as string))
    }
    console.groupEnd()
  }

  private static logResponse(endpoint: string, response: Response, data: any) {
    console.group(`📨 API Response: ${response.status} ${endpoint}`)
    console.log('✅ Status:', response.status, response.statusText)
    console.log('📋 Headers:', Object.fromEntries(response.headers.entries()))
    console.log('📄 Response Data:', data)
    console.groupEnd()
  }

  private static logError(endpoint: string, error: any) {
    console.group(`❌ API Error: ${endpoint}`)
    console.error('Error Details:', error)
    console.error('Error Message:', error.message)
    console.error('Error Stack:', error.stack)
    console.groupEnd()
  }

  private static async request<T>(
    endpoint: string, 
    options: ApiRequestOptions = {}
  ): Promise<T> {
    const token = this.getAuthToken()
    
    const defaultOptions: ApiRequestOptions = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` }),
      },
    }

    const config: ApiRequestOptions = {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers,
      },
    }

    this.logRequest(endpoint, config, token)

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, config)
      
      let data: any
      const contentType = response.headers.get('content-type')
      
      if (contentType && contentType.includes('application/json')) {
        data = await response.json()
      } else {
        data = await response.text()
      }

      this.logResponse(endpoint, response, data)
      
      if (!response.ok) {
        if (response.status === 401) {
          console.warn('🔒 Authentication failed')
          
          const isAuthEndpoint = endpoint.includes('/auth/login') || 
                                 endpoint.includes('/auth/register') || 
                                 endpoint.includes('/auth/google')
          const shouldSkipRedirect = options.skipAutoRedirect || isAuthEndpoint
          
          if (!shouldSkipRedirect && typeof window !== 'undefined') {
            console.log('🔄 Auto-redirecting to login page')
            localStorage.removeItem('wisdomwave_token')
            localStorage.removeItem('wisdomwave_user')
            window.location.href = '/login'
          } else {
            console.log('🚫 Skipping auto-redirect for auth endpoint or explicit skip')
          }
        }
        
        const errorMessage = typeof data === 'object' && data.message 
          ? data.message 
          : typeof data === 'string' 
            ? data 
            : `HTTP error! status: ${response.status}`
            
        throw new Error(errorMessage)
      }
      
      return data
    } catch (error) {
      this.logError(endpoint, error)
      throw error
    }
  }

  // ============================================
  // Auth APIs
  // ============================================

  static async register(userData: RegisterData): Promise<LoginResponse> {
    console.log('🎯 Starting Registration Process')
    
    try {
      const response = await this.request<any>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
        skipAutoRedirect: true,
      })
      
      console.log('✅ Registration Successful!')
      return response
    } catch (error) {
      console.error('❌ Registration Failed:', error)
      throw error
    }
  }

  static async login(credentials: LoginCredentials): Promise<LoginResponse> {
    console.log('🎯 Starting Login Process')
    
    try {
      const response = await this.request<any>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
        skipAutoRedirect: true,
      })
      
      console.log('✅ Login Successful!')
      return response
    } catch (error) {
      console.error('❌ Login Failed:', error)
      throw error
    }
  }

  static async loginWithGoogle(googleToken: string): Promise<LoginResponse> {
    console.log('🎯 Starting Google Login Process')
    
    try {
      const response = await this.request<any>('/auth/google', {
        method: 'POST',
        body: JSON.stringify({ token: googleToken }),
        skipAutoRedirect: true,
      })
      
      console.log('✅ Google Login Successful!')
      return response
    } catch (error) {
      console.error('❌ Google Login Failed:', error)
      throw error
    }
  }

  static async logout(): Promise<void> {
    console.log('🎯 Starting Logout Process')
    
    try {
      await this.request<void>('/auth/logout', {
        method: 'POST',
      })
      
      console.log('✅ Logout Successful!')
      
      if (typeof window !== 'undefined') {
        localStorage.removeItem('wisdomwave_token')
        localStorage.removeItem('wisdomwave_user')
        console.log('🗑️ Cleared localStorage')
      }
    } catch (error) {
      console.error('❌ Logout Failed:', error)
      throw error
    }
  }

  static async refreshToken(): Promise<LoginResponse> {
    console.log('🎯 Starting Token Refresh Process')
    
    try {
      const response = await this.request<any>('/auth/refresh', {
        method: 'POST',
      })
      
      console.log('✅ Token Refresh Successful!')
      return response
    } catch (error) {
      console.error('❌ Token Refresh Failed:', error)
      throw error
    }
  }

  // ============================================
  // User APIs
  // ============================================

  static async getCurrentUser(): Promise<UserProfile> {
    return this.request<UserProfile>('/users/me')
  }

  static async updateProfile(userData: Partial<UserProfile>): Promise<UserProfile> {
    return this.request<UserProfile>('/users/me', {
      method: 'PUT',
      body: JSON.stringify(userData),
    })
  }

  // ============================================
  // Course APIs
  // ============================================

  static async getCourses(params: CourseSearchParams = {}): Promise<{ data: Course[], total: number }> {
    const queryString = new URLSearchParams()
    
    if (params.query) queryString.append('query', params.query)
    if (params.filters?.category) queryString.append('category', params.filters.category)
    if (params.filters?.level) queryString.append('level', params.filters.level)
    if (params.filters?.featured !== undefined) queryString.append('featured', params.filters.featured.toString())
    if (params.sortBy) queryString.append('sortBy', params.sortBy)
    if (params.limit) queryString.append('limit', params.limit.toString())
    if (params.offset) queryString.append('offset', params.offset.toString())

    return this.request<{ data: Course[], total: number }>(
      `/courses${queryString.toString() ? `?${queryString.toString()}` : ''}`
    )
  }

  static async getCourseById(id: string): Promise<Course> {
    return this.request<Course>(`/courses/${id}`)
  }

  static async enrollInCourse(courseId: string, enrollmentData: EnrollmentData): Promise<void> {
    return this.request<void>(`/courses/${courseId}/enroll`, {
      method: 'POST',
      body: JSON.stringify(enrollmentData),
    })
  }

  static async getEnrolledCourses(): Promise<Course[]> {
    return this.request<Course[]>('/users/me/courses')
  }

  /**
   * Get course info (PUBLIC ENDPOINT - No auth required)
   * ✅ UPDATED: Returns totalWeeks and totalSessions needed for payment
   */
  static async getCourseInfo(courseId: string): Promise<{
    courseId: string
    categorySlug: string
    title: string
    price: number // in paise
    totalWeeks: number      // ✅ ADDED
    totalSessions: number   // ✅ ADDED
    isActive: boolean
    priceInRupees: number
  }> {
    console.log('💰 Fetching course info (PUBLIC) for:', courseId)
    
    const response = await this.request<any>(`/public/courses/info/${courseId}`, {
      skipAutoRedirect: true,
    })
    
    const courseInfo = response.data || response
    
    console.log('✅ Course info received:', courseInfo)
    
    return {
      ...courseInfo,
      priceInRupees: courseInfo.priceInRupees || (courseInfo.price / 100)
    }
  }

  // ============================================
  // Instructor APIs
  // ============================================

  static async getInstructorCourses(): Promise<Course[]> {
    return this.request<Course[]>('/instructor/courses')
  }

  static async createCourse(courseData: Partial<Course>): Promise<Course> {
    return this.request<Course>('/instructor/courses', {
      method: 'POST',
      body: JSON.stringify(courseData),
    })
  }

  static async updateCourse(courseId: string, courseData: Partial<Course>): Promise<Course> {
    return this.request<Course>(`/instructor/courses/${courseId}`, {
      method: 'PUT',
      body: JSON.stringify(courseData),
    })
  }

  static async getInstructorStats(): Promise<any> {
    return this.request<any>('/instructor/stats')
  }

  // ============================================
  // Contact APIs (PUBLIC - No auth required)
  // ============================================

  /**
   * Submit contact form / demo request (PUBLIC ENDPOINT)
   * ✅ No authentication required - Anyone can submit demo requests
   */
  static async submitContactForm(formData: ContactFormData): Promise<void> {
    console.log('📧 Submitting contact form (PUBLIC):', formData)
    
    return this.request<void>('/contact/demo-request', {
      method: 'POST',
      body: JSON.stringify(formData),
      skipAutoRedirect: true, // ✅ PUBLIC ENDPOINT - No auth required
    })
  }

  /**
   * Health check for contact service (PUBLIC ENDPOINT)
   */
  static async contactHealthCheck(): Promise<{ message: string }> {
    return this.request<any>('/contact/health', {
      skipAutoRedirect: true,
    })
  }

  // ============================================
  // Dashboard APIs
  // ============================================

  static async getLearnerDashboard(): Promise<LearnerDashboard> {
    return this.request<LearnerDashboard>('/dashboard/learner')
  }

  static async getInstructorDashboard(): Promise<InstructorDashboard> {
    return this.request<InstructorDashboard>('/dashboard/instructor')
  }

  // ============================================
  // Search and Filters
  // ============================================

  static async searchCourses(query: string): Promise<Course[]> {
    return this.request<Course[]>(`/courses/search?q=${encodeURIComponent(query)}`)
  }

  static async getCourseCategories(): Promise<string[]> {
    return this.request<string[]>('/courses/categories')
  }

  // ============================================
  // Payment APIs (Legacy - for future implementation)
  // ============================================

  static async createPaymentIntent(courseId: string, amount: number): Promise<any> {
    return this.request<any>('/payments/create-intent', {
      method: 'POST',
      body: JSON.stringify({ courseId, amount }),
    })
  }

  static async confirmPayment(paymentIntentId: string): Promise<any> {
    return this.request<any>(`/payments/confirm/${paymentIntentId}`, {
      method: 'POST',
    })
  }

  // ============================================
  // Razorpay Payment APIs - FIXED VERSION
  // ============================================

  /**
   * Create Razorpay Order for Course
   * ✅ FIXED: Now includes totalWeeks and totalSessions
   */
  static async createRazorpayOrder(orderData: {
    courseId: string
    categorySlug: string
    courseTitle: string
    amount: number        // in paise
    currency?: string
    totalWeeks: number    // ✅ REQUIRED by backend
    totalSessions: number // ✅ REQUIRED by backend
  }): Promise<{
    orderId: string
    currency: string
    amount: number
    keyId: string
    courseId: string
    courseTitle: string
    studentName: string
    studentEmail: string
    studentPhone: string
  }> {
    console.log('🎯 Creating Razorpay Order')
    console.log('📋 Order Data:', orderData)
    
    // Validate required fields
    if (!orderData.courseId) {
      throw new Error('Course ID is required')
    }
    if (!orderData.categorySlug) {
      throw new Error('Category slug is required')
    }
    if (!orderData.courseTitle) {
      throw new Error('Course title is required')
    }
    if (!orderData.amount || orderData.amount < 1) {
      throw new Error('Valid amount is required')
    }
    if (!orderData.totalWeeks || orderData.totalWeeks < 1) {
      throw new Error('Total weeks is required and must be at least 1')
    }
    if (!orderData.totalSessions || orderData.totalSessions < 1) {
      throw new Error('Total sessions is required and must be at least 1')
    }

    const response = await this.request<any>('/payment/razorpay/create-order', {
      method: 'POST',
      body: JSON.stringify({
        courseId: orderData.courseId,
        categorySlug: orderData.categorySlug,
        courseTitle: orderData.courseTitle,
        amount: orderData.amount,
        currency: orderData.currency || 'INR',
        totalWeeks: orderData.totalWeeks,       // ✅ ADDED
        totalSessions: orderData.totalSessions  // ✅ ADDED
      }),
    })
    
    console.log('✅ Razorpay Order Created:', response)
    
    return response.data || response
  }

  /**
   * Verify Razorpay Payment
   */
  static async verifyRazorpayPayment(paymentData: {
    razorpayOrderId: string
    razorpayPaymentId: string
    razorpaySignature: string
  }): Promise<{
    isValid: boolean
    message: string
    status: string
    courseId?: string
    paymentId?: string
    enrollmentId?: number
  }> {
    console.log('🎯 Verifying Razorpay Payment')
    
    const response = await this.request<any>('/payment/razorpay/verify-payment', {
      method: 'POST',
      body: JSON.stringify(paymentData),
    })
    
    console.log('✅ Payment Verified!')
    return response.data || response
  }

  /**
   * Test Razorpay Configuration
   */
  static async testRazorpayConfig(): Promise<{ success: boolean, message: string }> {
    return this.request<any>('/payment/razorpay/test', {
      method: 'GET',
    })
  }

  // ============================================
  // Enrollment APIs
  // ============================================

  /**
   * Get user's enrolled courses
   */
  static async getMyEnrollments(): Promise<any[]> {
    console.log('🎯 Fetching My Enrollments')
    const response = await this.request<any>('/enrollments/my-courses')
    
    const enrollments = response.data || response
    
    console.log('📚 Enrollments received:', enrollments)
    return Array.isArray(enrollments) ? enrollments : []
  }

  /**
   * Check if user is enrolled in a specific course
   */
  static async isEnrolledInCourse(courseId: string): Promise<{
    isEnrolled: boolean
    enrollmentId?: number
  }> {
    console.log('🔍 Checking enrollment for course:', courseId)
    
    try {
      const enrollments = await this.getMyEnrollments()
      
      const enrollment = enrollments.find((e: any) => e.courseId === courseId)
      
      if (enrollment) {
        console.log('✅ User is enrolled! Enrollment ID:', enrollment.id)
        return {
          isEnrolled: true,
          enrollmentId: enrollment.id
        }
      } else {
        console.log('ℹ️ User is not enrolled in this course')
        return {
          isEnrolled: false
        }
      }
    } catch (error) {
      console.error('❌ Error checking enrollment:', error)
      return {
        isEnrolled: false
      }
    }
  }

  /**
   * Get enrollment details
   */
  static async getEnrollmentDetails(enrollmentId: number): Promise<any> {
    const response = await this.request<any>(`/enrollments/${enrollmentId}`)
    return response.data || response
  }

  /**
   * Get course progress
   */
  static async getCourseProgress(enrollmentId: number): Promise<any> {
    console.log('📊 Fetching course progress for enrollment:', enrollmentId)
    
    const response = await this.request<any>(`/enrollments/${enrollmentId}/progress`)
    
    const progress = response.data || response
    
    console.log('✅ Progress received:', progress)
    return progress
  }

  /**
   * Start session
   */
  static async startSession(enrollmentId: number, weekNumber: number, sessionNumber: number): Promise<void> {
    console.log(`🎬 Starting session W${weekNumber}S${sessionNumber} for enrollment:`, enrollmentId)
    
    await this.request<void>(
      `/enrollments/${enrollmentId}/sessions/start?weekNumber=${weekNumber}&sessionNumber=${sessionNumber}`, 
      {
        method: 'POST',
      }
    )
    
    console.log('✅ Session started successfully')
  }

  /**
   * Complete session
   */
  static async completeSession(enrollmentId: number, weekNumber: number, sessionNumber: number): Promise<void> {
    console.log(`✅ Completing session W${weekNumber}S${sessionNumber} for enrollment:`, enrollmentId)
    
    await this.request<void>(
      `/enrollments/${enrollmentId}/sessions/complete?weekNumber=${weekNumber}&sessionNumber=${sessionNumber}`, 
      {
        method: 'POST',
      }
    )
    
    console.log('✅ Session completed successfully')
  }

  /**
   * Submit homework
   */
  static async submitHomework(sessionProgressId: number, fileUrl: string, notes?: string): Promise<void> {
    console.log('📤 Submitting homework for session:', sessionProgressId)
    
    await this.request<void>(
      `/enrollments/sessions/${sessionProgressId}/homework?fileUrl=${encodeURIComponent(fileUrl)}${notes ? `&notes=${encodeURIComponent(notes)}` : ''}`, 
      {
        method: 'POST',
      }
    )
    
    console.log('✅ Homework submitted successfully')
  }

  // ============================================
  // Mock Interview APIs
  // ============================================

  /**
   * Get all interview types (PUBLIC)
   */
  static async getInterviewTypes(): Promise<any[]> {
    console.log('🎯 Fetching interview types')
    const response = await this.request<any>('/mock-interviews/types', {
      skipAutoRedirect: true,
    })
    return response.data || response
  }

  /**
   * Get interview type details (PUBLIC)
   */
  static async getInterviewType(typeId: string): Promise<{
    typeId: string
    name: string
    description: string
    durationMinutes: number
    price: number // in paise
    priceInRupees: number
    isActive: boolean
    features: string[]
  }> {
    console.log('💰 Fetching interview type:', typeId)
    const response = await this.request<any>(`/mock-interviews/types/${typeId}`, {
      skipAutoRedirect: true,
    })
    return response.data || response
  }

  /**
   * Create Razorpay Order for Mock Interview
   */
  static async createMockInterviewOrder(orderData: {
    interviewTypeId: string
    interviewTypeName: string
    amount: number // in paise
    scheduledDateTime: string // ISO format
    programmingLanguage?: string
    jobDescription: string
    additionalNotes?: string
    currency?: string
  }): Promise<{
    orderId: string
    currency: string
    amount: number
    keyId: string
    interviewTypeId: string
    interviewTypeName: string
    studentName: string
    studentEmail: string
    studentPhone: string
  }> {
    console.log('🎯 Creating Razorpay Order for Mock Interview')
    console.log('📋 Order Data:', orderData)
    
    const response = await this.request<any>('/payment/razorpay/create-mock-interview-order', {
      method: 'POST',
      body: JSON.stringify({
        ...orderData,
        currency: orderData.currency || 'INR'
      }),
    })
    
    console.log('✅ Razorpay Order Created!')
    return response.data || response
  }

  /**
   * Verify Mock Interview Payment
   */
  static async verifyMockInterviewPayment(paymentData: {
    razorpayOrderId: string
    razorpayPaymentId: string
    razorpaySignature: string
    bookingDetails: {
      interviewTypeId: string
      scheduledDateTime: string
      programmingLanguage?: string
      jobDescription: string
      additionalNotes?: string
    }
  }): Promise<{
    isValid: boolean
    message: string
    status: string
    bookingId?: number
    paymentId?: string
  }> {
    console.log('🎯 Verifying Mock Interview Payment')
    
    const response = await this.request<any>('/payment/razorpay/verify-mock-interview-payment', {
      method: 'POST',
      body: JSON.stringify(paymentData),
    })
    
    console.log('✅ Payment Verified!')
    return response.data || response
  }

  /**
   * Get user's mock interview bookings
   */
  static async getMyMockInterviewBookings(): Promise<any[]> {
    console.log('🎯 Fetching my mock interview bookings')
    const response = await this.request<any>('/mock-interviews/my-bookings')
    const bookings = response.data || response
    console.log('📚 Bookings received:', bookings)
    return Array.isArray(bookings) ? bookings : []
  }

  /**
   * Get booking details
   */
  static async getMockInterviewBooking(bookingId: number): Promise<any> {
    const response = await this.request<any>(`/mock-interviews/bookings/${bookingId}`)
    return response.data || response
  }

  /**
   * Cancel booking
   */
  static async cancelMockInterviewBooking(bookingId: number): Promise<void> {
    await this.request<void>(`/mock-interviews/bookings/${bookingId}/cancel`, {
      method: 'POST',
    })
  }

  // ============================================
  // Debug Helper Methods
  // ============================================

  static debugLocalStorage() {
    console.group('🔍 LocalStorage Debug')
    console.log('🔑 Token:', localStorage.getItem('wisdomwave_token'))
    console.log('👤 User:', JSON.parse(localStorage.getItem('wisdomwave_user') || 'null'))
    console.groupEnd()
  }

  static clearDebugData() {
    console.log('🗑️ Clearing all debug data from localStorage')
    localStorage.removeItem('wisdomwave_token')
    localStorage.removeItem('wisdomwave_user')
  }
}