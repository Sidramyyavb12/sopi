import { User } from '@/types/auth'

export const AUTH_STORAGE_KEYS = {
  TOKEN: 'wisdomwave_token',
  USER: 'wisdomwave_user',
  REFRESH_TOKEN: 'wisdomwave_refresh_token',
} as const

export class AuthUtils {
  static getStoredToken(): string | null {
    if (typeof window === 'undefined') return null
    return localStorage.getItem(AUTH_STORAGE_KEYS.TOKEN)
  }

  static getStoredUser(): User | null {
    if (typeof window === 'undefined') return null
    const userData = localStorage.getItem(AUTH_STORAGE_KEYS.USER)
    try {
      if (!userData) return null
      
      const parsed = JSON.parse(userData)
      
      // 🔥 FIX: Check if it's wrapped in API response format
      if (parsed.data && parsed.success !== undefined) {
        console.log('🔧 Unwrapping user from API response format')
        return parsed.data // Return the actual user object
      }
      
      // Already in correct format
      return parsed
    } catch (error) {
      console.error('Failed to parse stored user data:', error)
      return null
    }
  }

  static getStoredRefreshToken(): string | null {
    if (typeof window === 'undefined') return null
    return localStorage.getItem(AUTH_STORAGE_KEYS.REFRESH_TOKEN)
  }

  static setAuthData(token: string, user: User, refreshToken?: string): void {
    if (typeof window === 'undefined') return
    
    // 🔥 FIX: Make sure we're ONLY saving the user object, not the wrapper
    let userToSave = user
    
    // If user is wrapped in API response, unwrap it
    if ((user as any).data && (user as any).success !== undefined) {
      console.log('🔧 Unwrapping user before saving')
      userToSave = (user as any).data
    }
    
    localStorage.setItem(AUTH_STORAGE_KEYS.TOKEN, token)
    localStorage.setItem(AUTH_STORAGE_KEYS.USER, JSON.stringify(userToSave))
    
    if (refreshToken) {
      localStorage.setItem(AUTH_STORAGE_KEYS.REFRESH_TOKEN, refreshToken)
    }
    
    console.log('💾 Auth data saved to localStorage:', userToSave.role, userToSave.email)
  }

  static clearAuthData(): void {
    if (typeof window === 'undefined') return
    
    localStorage.removeItem(AUTH_STORAGE_KEYS.TOKEN)
    localStorage.removeItem(AUTH_STORAGE_KEYS.USER)
    localStorage.removeItem(AUTH_STORAGE_KEYS.REFRESH_TOKEN)
    
    console.log('🗑️ Auth data cleared from localStorage')
  }

  static isTokenExpired(token: string): boolean {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]))
      const currentTime = Date.now() / 1000
      const isExpired = payload.exp < currentTime
      
      if (isExpired) {
        console.log('⏰ Token is expired')
      }
      
      return isExpired
    } catch (error) {
      console.error('Failed to parse token:', error)
      return true
    }
  }

  static getUserRole(): 'LEARNER' | 'INSTRUCTOR' | 'ADMIN' | null {
    const user = this.getStoredUser()
    return user?.role || null
  }

  static isAuthenticated(): boolean {
    const token = this.getStoredToken()
    return token ? !this.isTokenExpired(token) : false
  }

  static requireAuth(): boolean {
    if (!this.isAuthenticated()) {
      if (typeof window !== 'undefined') {
        window.location.href = '/login'
      }
      return false
    }
    return true
  }

  static requireRole(allowedRoles: Array<'LEARNER' | 'INSTRUCTOR' | 'ADMIN'>): boolean {
    const userRole = this.getUserRole()
    
    if (!userRole || !allowedRoles.includes(userRole)) {
      if (typeof window !== 'undefined') {
        window.location.href = '/unauthorized'
      }
      return false
    }
    return true
  }

  static redirectAfterLogin(user: User): string {
    switch (user.role) {
      case 'INSTRUCTOR':
        return '/dashboard/instructor'
      case 'LEARNER':
        return '/dashboard/learner'
      case 'ADMIN':
        return '/admin/dashboard'
      default:
        return '/dashboard/learner'
    }
  }

  static getAvatarUrl(user: User): string {
    if (user.avatar) {
      return user.avatar
    }
    
    // Generate avatar from email or name
    const seed = user.email || user.name
    return `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(seed)}`
  }

  static formatUserDisplayName(user: User): string {
    return user.name || user.email.split('@')[0]
  }

  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  static validatePassword(password: string): {
    isValid: boolean
    errors: string[]
  } {
    const errors: string[] = []
    
    if (password.length < 8) {
      errors.push('Password must be at least 8 characters long')
    }
    
    if (!/(?=.*[a-z])/.test(password)) {
      errors.push('Password must contain at least one lowercase letter')
    }
    
    if (!/(?=.*[A-Z])/.test(password)) {
      errors.push('Password must contain at least one uppercase letter')
    }
    
    if (!/(?=.*\d)/.test(password)) {
      errors.push('Password must contain at least one number')
    }
    
    if (!/(?=.*[@$!%*?&])/.test(password)) {
      errors.push('Password must contain at least one special character')
    }
    
    return {
      isValid: errors.length === 0,
      errors
    }
  }

  static generateSecurePassword(length: number = 12): string {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@$!%*?&'
    let password = ''
    
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length))
    }
    
    return password
  }

  // Helper function to normalize user data from API (converts null to undefined)
  static normalizeUser(user: any): User {
    // If it's wrapped in API response, unwrap it first
    let actualUser = user
    if (user.data && user.success !== undefined) {
      actualUser = user.data
    }
    
    return {
      id: actualUser.id,
      email: actualUser.email,
      name: actualUser.name,
      role: actualUser.role,
      avatar: actualUser.avatar,
      bio: actualUser.bio,
      createdAt: actualUser.createdAt,
      updatedAt: actualUser.updatedAt,
      
      // Convert null to undefined for optional fields
      phoneNumber: actualUser.phoneNumber ?? undefined,
      location: actualUser.location ?? undefined,
      timezone: actualUser.timezone ?? undefined,
      isActive: actualUser.isActive ?? undefined,
      isEmailVerified: actualUser.isEmailVerified ?? undefined,
      lastLogin: actualUser.lastLogin ?? undefined,
      
      totalHoursLearned: actualUser.totalHoursLearned ?? undefined,
      certificatesEarned: actualUser.certificatesEarned ?? undefined,
      learningStreak: actualUser.learningStreak ?? undefined,
      
      instructorRating: actualUser.instructorRating ?? undefined,
      studentsCount: actualUser.studentsCount ?? undefined,
      totalEarnings: actualUser.totalEarnings ?? undefined,
    }
  }
}