// lib/helpers/enrollmentHelpers.ts
import { ApiService } from '@/lib/api'

/**
 * Check if user is enrolled in a course
 */
export const checkEnrollment = async (
  courseId: string,
  user: any
): Promise<{ isEnrolled: boolean; enrollmentId: number | null }> => {
  if (!user || user.role !== 'LEARNER') {
    return { isEnrolled: false, enrollmentId: null }
  }

  try {
    console.log('🔍 Checking enrollment for course:', courseId)
    const enrollments = await ApiService.getMyEnrollments()
    
    const enrollment = enrollments.find((e: any) => e.courseId === courseId)
    
    if (enrollment) {
      console.log('✅ User is enrolled! Enrollment ID:', enrollment.enrollmentId)
      return {
        isEnrolled: true,
        enrollmentId: enrollment.enrollmentId
      }
    } else {
      console.log('ℹ️ User is not enrolled in this course')
      return {
        isEnrolled: false,
        enrollmentId: null
      }
    }
  } catch (error) {
    console.error('❌ Error checking enrollment:', error)
    return {
      isEnrolled: false,
      enrollmentId: null
    }
  }
}

/**
 * Fetch course info from backend
 */
export const fetchCourseInfo = async (courseId: string) => {
  try {
    console.log('💰 Fetching backend course info for:', courseId)
    const courseInfo = await ApiService.getCourseInfo(courseId)
    console.log('✅ Backend course info loaded:', courseInfo)
    return courseInfo
  } catch (error) {
    console.error('❌ Failed to fetch backend course info:', error)
    return null
  }
}

/**
 * Handle enrollment action (either continue learning or enroll)
 */
export const handleEnrollmentAction = (
  isEnrolled: boolean,
  enrollmentId: number | null,
  router: any,
  showAuthModal: () => void,
  user: any
): 'continue' | 'auth' | 'enroll' => {
  // If already enrolled, redirect to course page
  if (isEnrolled && enrollmentId) {
    router.push(`/dashboard/learner/course/${enrollmentId}`)
    return 'continue'
  }

  // If not logged in, show auth modal
  if (!user) {
    showAuthModal()
    return 'auth'
  }

  // If not a learner, show error
  if (user.role !== 'LEARNER') {
    alert(`⚠️ Only learners can enroll\n\nYou are: ${user.role}`)
    return 'auth'
  }

  // Proceed with enrollment
  return 'enroll'
}

/**
 * Calculate course pricing
 */
export const calculatePricing = (
  backendCourseInfo: any,
  frontendPrice: number
) => {
  const displayPrice = backendCourseInfo?.priceInRupees || frontendPrice
  const priceInPaise = backendCourseInfo?.price || (frontendPrice * 100)
  
  // Calculate original price as 30% more than backend price
  const calculatedOriginalPrice = Math.round(displayPrice * 1.30)
  const originalPrice = backendCourseInfo ? calculatedOriginalPrice : (frontendPrice * 1.30)
  
  // Recalculate discount
  const discountPercentage = Math.round(
    ((originalPrice - displayPrice) / originalPrice) * 100
  )

  return {
    displayPrice,
    priceInPaise,
    originalPrice,
    discountPercentage,
    savings: Math.round(originalPrice - displayPrice)
  }
}

/**
 * Validate enrollment data before payment
 */
export const validateEnrollmentData = (
  backendCourseInfo: any,
  frontendCourse: any
): {
  isValid: boolean
  error?: string
  data?: {
    priceInPaise: number
    totalWeeks: number
    totalSessions: number
  }
} => {
  let priceInPaise: number
  let totalWeeks: number
  let totalSessions: number

  if (backendCourseInfo) {
    priceInPaise = backendCourseInfo.price
    totalWeeks = backendCourseInfo.totalWeeks
    totalSessions = backendCourseInfo.totalSessions
  } else {
    // Fallback to frontend data
    priceInPaise = frontendCourse.price * 100
    totalWeeks = Math.ceil(frontendCourse.totalSessions / 4)
    totalSessions = frontendCourse.totalSessions
  }

  // Validate
  if (priceInPaise < 1) {
    return { isValid: false, error: 'Invalid amount' }
  }

  if (!totalWeeks || totalWeeks < 1) {
    return { isValid: false, error: 'Invalid total weeks' }
  }

  if (!totalSessions || totalSessions < 1) {
    return { isValid: false, error: 'Invalid total sessions' }
  }

  return {
    isValid: true,
    data: {
      priceInPaise: Math.round(priceInPaise),
      totalWeeks,
      totalSessions
    }
  }
}