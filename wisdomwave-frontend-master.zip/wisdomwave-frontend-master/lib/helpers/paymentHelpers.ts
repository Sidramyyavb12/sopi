// lib/helpers/paymentHelpers.ts
import { ApiService } from '@/lib/api'

/**
 * Load Razorpay Script
 */
export const loadRazorpayScript = (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && (window as any).Razorpay) {
      resolve(true)
      return
    }

    const script = document.createElement('script')
    script.src = 'https://checkout.razorpay.com/v1/checkout.js'
    script.onload = () => {
      console.log('✅ Razorpay script loaded')
      resolve(true)
    }
    script.onerror = () => {
      console.error('❌ Failed to load Razorpay')
      resolve(false)
    }
    document.body.appendChild(script)
  })
}

/**
 * Course Payment Handler
 */
export interface CoursePaymentData {
  courseId: string
  categorySlug: string
  courseTitle: string
  amount: number
  totalWeeks: number
  totalSessions: number
  user: any
}

export const handleCoursePayment = async (
  data: CoursePaymentData,
  onSuccess: (result: any) => void,
  onError: (error: string) => void
) => {
  try {
    // Load Razorpay
    const loaded = await loadRazorpayScript()
    if (!loaded) {
      onError('Failed to load payment gateway. Please refresh and try again.')
      return
    }

    console.log('📝 Creating order...')
    
    // Create order
    const orderData = await ApiService.createRazorpayOrder({
      courseId: data.courseId,
      categorySlug: data.categorySlug,
      courseTitle: data.courseTitle,
      amount: data.amount,
      currency: 'INR',
      totalWeeks: data.totalWeeks,
      totalSessions: data.totalSessions
    })

    console.log('✅ Order created:', orderData)

    // Razorpay options
    const options = {
      key: orderData.keyId,
      amount: orderData.amount,
      currency: orderData.currency,
      name: 'Sophiray Learning',
      description: orderData.courseTitle,
      order_id: orderData.orderId,
      
      prefill: {
        name: orderData.studentName || data.user.name,
        email: orderData.studentEmail || data.user.email,
        contact: orderData.studentPhone || ''
      },
      
      theme: {
        color: '#16a34a'
      },

      handler: async function (response: any) {
        console.log('✅ Payment successful:', response)
        
        try {
          const result = await ApiService.verifyRazorpayPayment({
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature
          })

          if (result.isValid) {
            onSuccess(result)
          } else {
            onError(result.message || 'Payment verification failed')
          }
        } catch (error: any) {
          onError(error.message || 'Failed to verify payment')
        }
      },

      modal: {
        ondismiss: function() {
          console.log('⚠️ Payment cancelled by user')
          onError('Payment cancelled')
        },
        escape: true,
        backdropclose: false
      }
    }

    const razorpay = new (window as any).Razorpay(options)
    
    razorpay.on('payment.failed', function (response: any) {
      console.error('❌ Payment failed:', response.error)
      onError(response.error.description || 'Payment failed')
    })
    
    razorpay.open()

  } catch (error: any) {
    console.error('❌ Payment error:', error)
    onError(error.message || 'Payment error occurred')
  }
}

/**
 * Mock Interview Payment Handler
 */
export interface InterviewPaymentData {
  interviewTypeId: string
  interviewTypeName: string
  amount: number
  scheduledDateTime: string
  programmingLanguage?: string
  jobDescription: string
  additionalNotes?: string
  user: any
}

export const handleInterviewPayment = async (
  data: InterviewPaymentData,
  onSuccess: (result: any) => void,
  onError: (error: string) => void
) => {
  try {
    // Load Razorpay
    const loaded = await loadRazorpayScript()
    if (!loaded) {
      onError('Failed to load payment gateway. Please refresh and try again.')
      return
    }

    console.log('📝 Creating interview order...')

    // Booking details
    const bookingDetails = {
      interviewTypeId: data.interviewTypeId,
      scheduledDateTime: data.scheduledDateTime,
      programmingLanguage: data.programmingLanguage,
      jobDescription: data.jobDescription,
      additionalNotes: data.additionalNotes
    }
    
    // Create order
    const orderData = await ApiService.createMockInterviewOrder({
      interviewTypeId: data.interviewTypeId,
      interviewTypeName: data.interviewTypeName,
      amount: data.amount,
      currency: 'INR',
      ...bookingDetails
    })

    console.log('✅ Interview order created:', orderData)

    // Razorpay options
    const options = {
      key: orderData.keyId,
      amount: orderData.amount,
      currency: orderData.currency,
      name: 'Sophiray Learning',
      description: orderData.interviewTypeName,
      order_id: orderData.orderId,
      
      prefill: {
        name: orderData.studentName || data.user.name,
        email: orderData.studentEmail || data.user.email,
        contact: orderData.studentPhone || ''
      },
      
      theme: {
        color: '#9333ea'
      },

      handler: async function (response: any) {
        console.log('✅ Payment successful:', response)
        
        try {
          const result = await ApiService.verifyMockInterviewPayment({
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature,
            bookingDetails
          })

          if (result.isValid) {
            onSuccess(result)
          } else {
            onError(result.message || 'Payment verification failed')
          }
        } catch (error: any) {
          onError(error.message || 'Failed to verify payment')
        }
      },

      modal: {
        ondismiss: function() {
          console.log('⚠️ Payment cancelled by user')
          onError('Payment cancelled')
        },
        escape: true,
        backdropclose: false
      }
    }

    const razorpay = new (window as any).Razorpay(options)
    
    razorpay.on('payment.failed', function (response: any) {
      console.error('❌ Payment failed:', response.error)
      onError(response.error.description || 'Payment failed')
    })
    
    razorpay.open()

  } catch (error: any) {
    console.error('❌ Payment error:', error)
    onError(error.message || 'Payment error occurred')
  }
}