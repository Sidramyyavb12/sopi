import { LoginCredentials, RegisterData } from '@/types/auth'
import { ContactFormData } from '@/types/user'

export interface ValidationResult {
  isValid: boolean
  errors: Record<string, string>
}

export class ValidationUtils {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  static validatePassword(password: string): {
    isValid: boolean
    errors: string[]
  } {
    const errors: string[] = []
    
    if (password.length < 8) {
      errors.push('Password must be at least 8 characters long')
    }
    
    if (!/(?=.*[a-z])/.test(password)) {
      errors.push('Password must contain at least one lowercase letter')
    }
    
    if (!/(?=.*[A-Z])/.test(password)) {
      errors.push('Password must contain at least one uppercase letter')
    }
    
    if (!/(?=.*\d)/.test(password)) {
      errors.push('Password must contain at least one number')
    }
    
    return {
      isValid: errors.length === 0,
      errors
    }
  }

  static validateLoginForm(data: LoginCredentials): ValidationResult {
    const errors: Record<string, string> = {}

    // Email validation
    if (!data.email) {
      errors.email = 'Email is required'
    } else if (!this.validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address'
    }

    // Password validation
    if (!data.password) {
      errors.password = 'Password is required'
    } else if (data.password.length < 6) {
      errors.password = 'Password must be at least 6 characters long'
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    }
  }

  static validateRegisterForm(data: RegisterData & { confirmPassword: string }): ValidationResult {
    const errors: Record<string, string> = {}

    // Name validation
    if (!data.name || data.name.trim().length === 0) {
      errors.name = 'Full name is required'
    } else if (data.name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters long'
    } else if (data.name.trim().length > 50) {
      errors.name = 'Name must not exceed 50 characters'
    }

    // Email validation
    if (!data.email) {
      errors.email = 'Email is required'
    } else if (!this.validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address'
    }

    // Password validation
    if (!data.password) {
      errors.password = 'Password is required'
    } else {
      const passwordValidation = this.validatePassword(data.password)
      if (!passwordValidation.isValid) {
        errors.password = passwordValidation.errors[0]
      }
    }

    // Confirm password validation
    if (!data.confirmPassword) {
      errors.confirmPassword = 'Please confirm your password'
    } else if (data.password !== data.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match'
    }

    // Role validation
    if (!data.role || !['LEARNER', 'INSTRUCTOR'].includes(data.role)) {
      errors.role = 'Please select a valid role'
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    }
  }

  static validateContactForm(data: ContactFormData): ValidationResult {
    const errors: Record<string, string> = {}

    // Name validation
    if (!data.name || data.name.trim().length === 0) {
      errors.name = 'Full name is required'
    } else if (data.name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters long'
    }

    // Email validation
    if (!data.email) {
      errors.email = 'Email is required'
    } else if (!this.validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address'
    }

    // Course validation
    if (!data.course) {
      errors.course = 'Please select a course of interest'
    }

    // Message validation (optional but if provided, should have minimum length)
    if (data.message && data.message.trim().length > 0 && data.message.trim().length < 10) {
      errors.message = 'Message should be at least 10 characters long if provided'
    } else if (data.message && data.message.trim().length > 1000) {
      errors.message = 'Message should not exceed 1000 characters'
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    }
  }

  static validatePhoneNumber(phone: string): boolean {
    // Basic phone number validation (supports various formats)
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''))
  }

  static validateUrl(url: string): boolean {
    try {
      new URL(url)
      return true
    } catch {
      return false
    }
  }

  static sanitizeInput(input: string): string {
    return input
      .trim()
      .replace(/[<>]/g, '') // Remove potential HTML tags
      .substring(0, 1000) // Limit length
  }

  static validateFileSize(file: File, maxSizeInMB: number): boolean {
    const maxSizeInBytes = maxSizeInMB * 1024 * 1024
    return file.size <= maxSizeInBytes
  }

  static validateFileType(file: File, allowedTypes: string[]): boolean {
    return allowedTypes.includes(file.type)
  }

  static validateImageFile(file: File): ValidationResult {
    const errors: Record<string, string> = {}
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
    const maxSizeInMB = 5

    if (!this.validateFileType(file, allowedTypes)) {
      errors.type = 'Please upload a valid image file (JPEG, PNG, GIF, or WebP)'
    }

    if (!this.validateFileSize(file, maxSizeInMB)) {
      errors.size = `File size must be less than ${maxSizeInMB}MB`
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    }
  }

  static validateAge(birthDate: string): boolean {
    const today = new Date()
    const birth = new Date(birthDate)
    const age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      return age - 1 >= 13
    }
    
    return age >= 13
  }

  static validateCreditCard(cardNumber: string): boolean {
    // Luhn algorithm for credit card validation
    const digits = cardNumber.replace(/\D/g, '')
    let sum = 0
    let isEven = false

    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = parseInt(digits[i])

      if (isEven) {
        digit *= 2
        if (digit > 9) {
          digit -= 9
        }
      }

      sum += digit
      isEven = !isEven
    }

    return sum % 10 === 0 && digits.length >= 13 && digits.length <= 19
  }

  static validateExpiryDate(month: string, year: string): boolean {
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth() + 1
    const currentYear = currentDate.getFullYear()
    
    const expMonth = parseInt(month)
    const expYear = parseInt(year)
    
    if (expMonth < 1 || expMonth > 12) return false
    if (expYear < currentYear) return false
    if (expYear === currentYear && expMonth < currentMonth) return false
    
    return true
  }

  static validateCVV(cvv: string): boolean {
    return /^\d{3,4}$/.test(cvv)
  }

  static getPasswordStrength(password: string): {
    score: number
    feedback: string[]
  } {
    let score = 0
    const feedback: string[] = []

    // Length check
    if (password.length >= 8) {
      score += 1
    } else {
      feedback.push('Use at least 8 characters')
    }

    // Lowercase check
    if (/[a-z]/.test(password)) {
      score += 1
    } else {
      feedback.push('Add lowercase letters')
    }

    // Uppercase check
    if (/[A-Z]/.test(password)) {
      score += 1
    } else {
      feedback.push('Add uppercase letters')
    }

    // Number check
    if (/\d/.test(password)) {
      score += 1
    } else {
      feedback.push('Add numbers')
    }

    // Special character check
    if (/[@$!%*?&]/.test(password)) {
      score += 1
    } else {
      feedback.push('Add special characters')
    }

    // Bonus for length
    if (password.length >= 12) {
      score += 1
    }

    return { score, feedback }
  }
}