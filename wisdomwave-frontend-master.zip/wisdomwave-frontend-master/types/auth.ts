export interface User {
  id: number  // Changed from string to number to match your API
  email: string
  name: string
  role: 'LEARNER' | 'INSTRUCTOR' | 'ADMIN'
  avatar?: string
  bio?: string
  createdAt: string
  updatedAt: string
  
  // Additional fields - FIXED: Removed | null
  phoneNumber?: string
  location?: string
  timezone?: string
  isActive?: boolean
  isEmailVerified?: boolean
  lastLogin?: string
  
  // Learner specific fields
  totalHoursLearned?: number
  certificatesEarned?: number
  learningStreak?: number
  
  // Instructor specific fields
  instructorRating?: number
  studentsCount?: number
  totalEarnings?: number
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  name: string
  email: string
  password: string
  role: 'LEARNER' | 'INSTRUCTOR'
}

export interface AuthResponse {
  user: User
  token: string
  refreshToken?: string
}

// API response structure (what your backend actually returns)
export interface ApiAuthResponse {
  success: boolean
  message: string
  data: User | {  // 🔥 FIX: data can be User directly OR contain user
    user?: User
    token?: string
    refreshToken?: string
  }
  timestamp: string
}

export type LoginResponse = AuthResponse | ApiAuthResponse

export interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticating: boolean
  login: (credentials: LoginCredentials) => Promise<LoginResponse>
  register: (userData: RegisterData) => Promise<LoginResponse>
  loginWithGoogle: (googleToken: string) => Promise<LoginResponse>
  logout: () => Promise<void>
}

export interface GoogleOAuthResponse {
  credential: string
  select_by: string
}

// 🔥 FIXED: Extract functions that handle YOUR API format
export function extractUserFromResponse(response: LoginResponse): User | null {
  console.log('🔍 Extracting user from response:', response)
  
  // Format 1: { success: true, data: { id, name, email, role, ... } }
  // YOUR API FORMAT - user is directly in data
  if ('data' in response && response.data && typeof response.data === 'object') {
    // Check if data has user properties directly
    if ('id' in response.data && 'email' in response.data && 'role' in response.data) {
      console.log('✅ Found user directly in response.data (YOUR API FORMAT)')
      return response.data as User
    }
    
    // Or check if data contains a user object
    if ('user' in response.data && response.data.user) {
      console.log('✅ Found user in response.data.user')
      return response.data.user as User
    }
  }
  
  // Format 2: { user: {...}, token: "..." } - Simple format
  if ('user' in response && response.user) {
    console.log('✅ Found user in response.user')
    return response.user as User
  }
  
  console.error('❌ Could not extract user from response')
  return null
}

export function extractTokenFromResponse(response: LoginResponse): string | null {
  console.log('🔍 Extracting token from response')
  
  // Check if token is at root level first (common in login responses)
  if ('token' in response && typeof response.token === 'string') {
    console.log('✅ Found token in response.token')
    return response.token
  }
  
  // Check nested in data
  if ('data' in response && response.data && typeof response.data === 'object') {
    if ('token' in response.data && typeof response.data.token === 'string') {
      console.log('✅ Found token in response.data.token')
      return response.data.token
    }
  }
  
  // For your API: token might be separate from user data
  // Check localStorage as fallback (login endpoint might return it separately)
  if (typeof window !== 'undefined') {
    const storedToken = localStorage.getItem('wisdomwave_token')
    if (storedToken) {
      console.log('✅ Using token from localStorage')
      return storedToken
    }
  }
  
  console.warn('⚠️ Could not extract token from response')
  return null
}

export function extractRefreshTokenFromResponse(response: LoginResponse): string | null {
  // Check if refreshToken is at root level
  if ('refreshToken' in response && response.refreshToken) {
    return response.refreshToken as string
  }
  
  // Check nested in data
  if ('data' in response && response.data && typeof response.data === 'object') {
    if ('refreshToken' in response.data && response.data.refreshToken) {
      return response.data.refreshToken as string
    }
  }
  
  return null
}