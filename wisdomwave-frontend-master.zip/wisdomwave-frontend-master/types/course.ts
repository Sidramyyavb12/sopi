export interface Instructor {
  id: string
  name: string
  bio: string
  image: string
  rating: number
  studentsCount: number
  experience?: string
  company?: string
}

export interface Course {
  id: string
  title: string
  description: string
  fullDescription?: string
  imageUrl: string
  level: 'Beginner' | 'Intermediate' | 'Advanced'
  rating: number
  enrolledCount: string
  duration: string
  totalHours?: string
  price: number
  originalPrice?: number
  instructor: Instructor
  learningPaths?: string[]
  skills: string[]
  curriculum?: string[]
  projects?: string[]
  prerequisites?: string
  hasCertificate: boolean
  hasProctoring?: boolean
  language: string
  subtitles?: string[]
  features?: string[]
  category: string
  subcategory: string
  tags: string[]
  lastUpdated: string
  completionRate: number
  jobPlacementRate?: number
  progress?: number
  nextSession?: string
}

export interface EnrollmentData {
  learningPath: string
  paymentMethod: string
}

export interface CourseFilters {
  category?: string
  level?: string
  price?: {
    min: number
    max: number
  }
  rating?: number
  duration?: string
  hasCertificate?: boolean
  featured?: boolean
}

export interface CourseSearchParams {
  query?: string
  filters?: CourseFilters
  sortBy?: 'popularity' | 'rating' | 'price' | 'newest'
  limit?: number
  offset?: number
}

export interface DashboardCourse extends Course {
  progress: number
  nextSession: string
  lastAccessed?: string
  completedLessons?: number
  totalLessons?: number
}

export interface UpcomingSession {
  id: string
  courseId: string
  courseName: string
  instructorName: string
  scheduledTime: string
  duration: number
  type: 'live' | 'recorded' | 'qa'
  meetingLink?: string
}

export interface CourseNote {
  id: string
  courseId: string
  title: string
  content: string
  createdAt: string
  tags?: string[]
}