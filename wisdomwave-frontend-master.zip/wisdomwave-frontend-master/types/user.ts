import { Course, DashboardCourse, UpcomingSession, CourseNote } from './course'

// 🔥 FIX: Make User interface consistent with auth.ts
export interface User {
  id: number  // Changed from string to number to match API
  email: string
  name: string
  role: 'LEARNER' | 'INSTRUCTOR' | 'ADMIN'
  avatar?: string
  bio?: string
  createdAt: string
  updatedAt: string
  
  // Additional fields - FIXED: Removed | null
  phoneNumber?: string
  location?: string
  timezone?: string
  isActive?: boolean
  isEmailVerified?: boolean
  lastLogin?: string
  
  // Learner specific fields
  totalHoursLearned?: number
  certificatesEarned?: number
  learningStreak?: number
  
  // Instructor specific fields
  instructorRating?: number
  studentsCount?: number
  totalEarnings?: number
}

// Alias for backwards compatibility (in case UserProfile is used elsewhere)
export type UserProfile = User

export interface UserPreferences {
  emailNotifications: boolean
  smsNotifications: boolean
  darkMode: boolean
  language: string
  learningReminders: boolean
}

export interface LearnerDashboard {
  user: User  // Changed from UserProfile to User
  enrolledCourses: DashboardCourse[]
  upcomingSessions: UpcomingSession[]
  notes: CourseNote[]
  achievements: Achievement[]
  learningStreak: number
  totalHoursLearned: number
  certificatesEarned: number
}

export interface InstructorDashboard {
  user: User  // Changed from UserProfile to User
  stats: InstructorStats[]
  courses: InstructorCourse[]
  recentEnrollments: RecentEnrollment[]
  upcomingSessions: UpcomingSession[]
  earnings: EarningsData
}

export interface InstructorStats {
  title: string
  value: string
  icon: string
  color: string
  change?: string
  changeType?: 'increase' | 'decrease'
}

export interface InstructorCourse {
  id: string
  title: string
  students: number
  rating: number
  status: 'Active' | 'Draft' | 'Paused'
  revenue: number
  lastUpdated: string
}

export interface RecentEnrollment {
  id: string
  studentName: string
  studentAvatar: string
  courseName: string
  enrolledAt: string
  amount: number
}

export interface EarningsData {
  totalEarnings: number
  thisMonth: number
  lastMonth: number
  pendingPayouts: number
  nextPayoutDate: string
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  earnedAt: string
  category: 'learning' | 'completion' | 'streak' | 'social'
}

export interface ContactFormData {
  name: string
  email: string
  course: string
  message: string
}